//====================================================================
/**
 * Name: ACE_TableHeaderRowCellController.js
 * Description: Client side controller of the Table plugin.
 * This contains the various event handlers and the function called
 * for searching.
 *
 * Confidential & Proprietary, 2017 Tier1CRM Inc.
 * Property of Tier1CRM Inc.
 * This document shall not be duplicated, transmitted or used in whole
 * or in part without written permission from Tier1CRM.
 */
//====================================================================
({
    /**
     * It sets the parameters for sorting event and trigger the event to be handled.
     * 
     * @param {object} component - The component itself.
     */  
	sortColumn: function(component, event) 
	{
		// find the next sort direction to be applied
		const SORT_CLASSES       = component.get("v.sortClasses");
		const CURRENT_SORT_CLASS = component.get("v.currentSortClass");

		const NEXT_SORT_CLASS_INDEX = 
			(SORT_CLASSES.indexOf(CURRENT_SORT_CLASS) + 1) % 
			SORT_CLASSES.length;
		const NEXT_SORT_CLASS = SORT_CLASSES[NEXT_SORT_CLASS_INDEX];

		// throw sort event

		var sortColumnEvent = component.getEvent("onSortColumn");
		sortColumnEvent.setParams({
			label	  	  : component.get("v.label"),
			isSortRemoved : NEXT_SORT_CLASS == "",
			isAscending   : NEXT_SORT_CLASS == "ascendingSort"
		});
		sortColumnEvent.fire();

		// update displayed sort icon
		
		component.set("v.currentSortClass", NEXT_SORT_CLASS);
	},

	/**
	 * clear the sort functionality
	 * 
	 * @param {Aura.component} component - The component itself.
	 */
	clearSort: function(component)
	{
		component.set("v.currentSortClass", "");
	}
})