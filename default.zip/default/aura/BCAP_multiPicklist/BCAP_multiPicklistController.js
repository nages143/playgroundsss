({
    doInit: function(component, event) {
        var prevVal = component.get("v.fieldValue");
        component.set("v.fieldValue", prevVal);
           
    },
    handleMultiPicklistSelection : function(component, event, helper) {
        let selectedValues = [];
        let selections = event.getParam("userSelection");
        for(let selection of selections){
            selectedValues.push(selection.value);
        }
        component.set("v.fieldValue", selectedValues.join(";"));
        
        var pubsub = component.find('pubsub');
        let fieldDetails = {name: event.getParam("name"), userSelection: selectedValues};
        pubsub.fireEvent('bcapFormfieldChange', fieldDetails);
    },
    handlePubsubReady: function(component) {
        var pubsub = component.find('pubsub');
        var callback = $A.getCallback(function(fieldDetails) {
            let combobox = component.find('combobox');
            //toggle display
           console.log("field details", JSON.stringify(fieldDetails));
            let displayCriteria = component.get('v.displayCriteria');
            if(displayCriteria){
                let statement = displayCriteria.split("=")
                if(fieldDetails.name === statement[0]){
                    let ruleValue = statement[1].split(",");
                    console.log("should happen", fieldDetails.userSelection.some(val => ruleValue.includes(val)));
                    combobox.setIsHidden(!fieldDetails.userSelection.some(val => ruleValue.includes(val)));
                }
            }
            //filter dependent list
            console.log("this field", component.get('v.fieldName'),", changed field: ", fieldDetails.name, ", controlling field name: ", combobox.getControllingFieldName());
            if(combobox.getControllingFieldName() === fieldDetails.name){
                combobox.setControllingFieldValue(fieldDetails.userSelection.join(';'));
            }
        });
        pubsub.registerListener('bcapFormfieldChange', callback);
    },
    handleDestroy: function(component) {
        var pubsub = component.find('pubsub');
        pubsub.unregisterAllListeners();
    }
})