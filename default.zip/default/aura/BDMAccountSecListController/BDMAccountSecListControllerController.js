({
  doInit: function(component, event, helper) {
    	//helper.getColumnDefinitions(component, event);
    	//helper.getSecurityFillingDetails(component, event);
 component.set("v.Columns", [
      {
        label: "Filing Type",
        fieldName: "BNK_Sec_Filing_Type__c",
        type: "text",
        initialWidth: 180
      },
      {
        label: "Period End",
        fieldName: "BNK_period_end_mod_date__c",
        type: "text",
        initialWidth: 180
      },
      {
        label: "Filing Date",
        fieldName: "BNK_Filing_mod_date__c",
        type: "text",
        initialWidth: 180
      },
      {
        label: "SEC Filing Report",
        type: "button",
        initialWidth: 180,
        typeAttributes: {
          label: "View",
          name: "View",
          title: "View",
          disabled: false,
          iconPosition: "center"
        }
      }
    ]);

   var action = component.get("c.getSecDetails");
    
     
    action.setParams({
      recordId: component.get("v.recordId")
    });
      
      var delay = 1000;
 var timer = component.get('v.timer');
 window.setTimeout(
 $A.getCallback(function() {
 if (component.isValid()) {
            action.setCallback(this, function(data) {              
                      var state = data.getState();
                      if (state === "SUCCESS") {
                          if (data.getReturnValue() != null ) {
                                component.set("v.Account", data.getReturnValue());
                                component.set("v.loaded", true);
                                component.set("v.enableInfiniteLoading", true);
                                 var returnValue;
                                 returnValue = data.getReturnValue(); 
                             
                                 if ( returnValue.length > 0) {
                                  component.set("v.noRecords", false);
                                  console.log("Data loaded total records.. = ", returnValue.length);
                                }
                          }
                      }
                    });
                    $A.enqueueAction(action);
                }}),
  		delay);
 	component.set('v.timer', timer);
	},
 
        // function automatic called by aura:waiting event  
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for displaying loading spinner 
        component.set("v.spinner", true); 
    },
     
    // function automatic called by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hiding loading spinner    
        component.set("v.spinner", false);
    },
  viewRecord: function(component, event, helper) {
    var recURL = event.getParam("row").BNK_Sec_URL__c;
    window.open(recURL);
  }
});