({
    getColumnDefinitions: function(cmp, event) {
        console.log("inside helper...");
        var columns = [
            {label:"Filing Type", fieldName:"BNK_Sec_Filing_Type__c", type:"text",initialWidth : 100},
            {label:"Period End", fieldName:"BNK_period_end_mod_date__c", type:"text",initialWidth : 200},                                    
            {label:"Filing Date", fieldName:"BNK_Filing_mod_date__c", type:"text",initialWidth : 200},            
            {type:"button",initialWidth : 500,  typeAttributes: {
                label: 'View',
                name: 'View',
                title: 'View',
                disabled: false,                
                iconPosition: 'left'                
            }}
        ];
        
        cmp.set('v.columns', columns);
        //console.log(cmp.get('v.columns'));
    },
    
      getAccountsHelper : function(component, event, helper) {
            var action = component.get("c.getSecDetails");
        var returnValue;
        action.setParams({
          recordId: component.get("v.recordId")
        });
        action.setCallback(this, function(data) {
          var state = data.getState();
          if (state === "SUCCESS") {
              if ( data.getReturnValue() != null ) {
                    component.set("v.Account", data.getReturnValue());
                    component.set("v.loaded", true);
                    component.set("v.enableInfiniteLoading", true);
                     returnValue = data.getReturnValue();  
                    if ( returnValue.length > 0) {
                      //component.set("v.noRecords", false);
                      console.log("Data loaded total records.. = ", returnValue.length);
                    }
              }
          }
        });
		$A.enqueueAction(action);
	},
    
    getSecurityFillingDetails : function(component, event ) {
        
        var action = component.get("c.getSecDetails");        
        action.setParams({
            recordId: component.get("v.recordId")
        });
        action.setCallback(this, function(data) {
            var state = data.getState();
            if (state === "SUCCESS") {
                if ( data.getReturnValue() != null ) {
                    component.set("v.Account", data.getReturnValue());
                    component.set("v.loaded", true);
                    //component.set("v.enableInfiniteLoading", true);
                    var returnValue = data.getReturnValue();  
                    if ( returnValue.length > 0) {
                        component.set("v.noRecords", false);
                        console.log("Data loaded total records.. = ", returnValue.length);
                    }
                }
            }
        });
        $A.enqueueAction(action);       
    },
})