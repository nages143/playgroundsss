({
    getAccountCovlist : function(component, event, sortField) {
        var userId = $A.get("$SObjectType.CurrentUser.Id");
        var action = component.get("c.getAcctCovList");
        action.setParams({'uId': userId});
       	action.setCallback(this, function(actionResult) {
        var state = actionResult.getState();
        if(state === "SUCCESS") {
        	console.log("Data is" + JSON.stringify(actionResult.getReturnValue()));
        	var records = actionResult.getReturnValue();
        	records.forEach(function(record){
        		record.linkName = '/lightning/r/Account/'+record.id+'/view';
         	});
        	component.set('v.data', records);
        	this.sortData(component, component.get("v.sortedBy"), component.get("v.sortedDirection"));    
         }
		});
          $A.enqueueAction(action);
    },
    
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.data");
        var reverse = sortDirection !== 'asc';
        if (fieldName == 'linkName') {
            data.sort(this.sortBy('name', reverse));
        } else {
	        data.sort(this.sortBy(fieldName, reverse));            
        }
        cmp.set("v.data", data);
    },
    
	sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    },
    
    
    getColumnDefinitions: function(cmp, event) {
        console.log("inside helper");
        var columns = [
            {label: 'Account', fieldName: 'linkName', type: 'url', typeAttributes: {label: {fieldName: 'name' }, target: '_blank'}, sortable: true},
            {label: 'Role', fieldName: 'role', type: 'text', sortable: true},
            {label: 'Industry', fieldName: 'industry', type: 'text', sortable: true},
            {label: 'Vertical', fieldName: 'vertical', type: 'text', sortable: true},
            {label: 'Tier', fieldName: 'tier', type: 'text', sortable: true}
        ];
        
        cmp.set('v.columns', columns);
        console.log(cmp.get('v.columns'));
    },
    
    sortHelper: function(component, event, sortFieldName) {
      var currentDir = component.get("v.arrowDirection");
 
      if (currentDir == 'arrowdown') {
         // set the arrowDirection attribute for conditionally rendred arrow sign  
         component.set("v.arrowDirection", 'arrowup');
         // set the isAsc flag to true for sort in Assending order.  
         component.set("v.isAsc", true);
      } else {
         component.set("v.arrowDirection", 'arrowdown');
         component.set("v.isAsc", false);
      }
      // call the onLoad function for call server side method with pass sortFieldName 
      this.getAccountCovlist(component, event, sortFieldName);
   },
    
    
    
})