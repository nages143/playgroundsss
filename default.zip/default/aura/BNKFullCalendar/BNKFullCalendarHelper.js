({
	getResponse: function(component) {
        var userId = $A.get("$SObjectType.CurrentUser.Id");
		var action = component.get("c.getEvents");
        action.setParams({userId: userId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var eventArr = [];
                
                result.forEach(function(key) {
                  eventArr.push({
                        'id':key.Id,
                        'start':moment(key.StartDateTime__c).format(),
                        'end':moment(key.EndDateTime__c).format(),
                        'title': key.BNK_Account_ID__r.Name + " | " + key.Subject__c
                    });
                });
                this.loadCalendar(component, eventArr);
                
            } else if (state === "INCOMPLETE") {
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    
    loadCalendar :function(component, data){   
        var m = moment();
        //console.log(data);
        
        var ele = component.find('calendar').getElement();
        $(ele).fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay,listWeek'
            },
            defaultDate: m.format(),
            editable: true,
            navLinks: true, // can click day/week names to navigate views
            weekNumbers: false,
            weekNumbersWithinDays: true,
            editable: true,
            eventLimit: true,
            events:data,
            timezone: 'local',
            timeZone: 'local',
            
            eventClick: function(calEvent) {
                var meetingId = calEvent["id"];
                if (meetingId !== null) {
					window.open("/lightning/r/BNK_Event__c/" + meetingId + "/view", '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes');
                }
          },
            
            
        eventMouseover: function(calEvent, jsEvent) {
            var tooltip = '<div class="tooltipevent" style="width:100px;height:100px;background:#ccc;position:absolute;z-index:10001;">' + calEvent.title + '</div>';
            $("body").append(tooltip);
            $(this).mouseover(function(e) {
                $(this).css('z-index', 10000);
                $('.tooltipevent').fadeIn('500');
                $('.tooltipevent').fadeTo('10', 1.9);
            }).mousemove(function(e) {
                $('.tooltipevent').css('top', e.pageY + 10);
                $('.tooltipevent').css('left', e.pageX -20);
            });
        },

        eventMouseout: function(calEvent, jsEvent) {
             $(this).css('z-index', 8);
             $('.tooltipevent').remove();
        },        
            
        });
        
    }
});