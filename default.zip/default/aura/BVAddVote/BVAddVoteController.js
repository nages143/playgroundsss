({
    init: function (component, event, helper) {
        
        var action = component.get("c.getUserType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var userType = response.getReturnValue();
                if(userType.includes('Admin')) {
                    component.set("v.isAdminUser", true);
                    component.set("v.userType","Admin");
                }  
                if(userType.includes('Pilot')){
                    component.set("v.isPilotUser", true);
                    component.set("v.userType","Data Team");
                }
                
                if(userType.includes('ClientStrategy')) {
                    component.set("v.isClientStrategyUser", true);
                    component.set("v.userType","Client Strategy");
                }
                if(userType.includes('BusinessManagement')) {
                    component.set("v.isBusinessMgmtUser", true);
                    component.set("v.userType","Business Management");
                }
                if(userType.includes('NAM')) 
                    component.set("v.userRegion", "NAM");
                if(userType.includes('EU')) 
                    component.set("v.userRegion", "EU");
                
                component.set("v.userInitiated", true);
                var isPilotUser = component.get("v.isPilotUser");
                var isAdminUser = component.get("v.isAdminUser");
                if(isPilotUser || isAdminUser){
                    component.set("v.hasAccess" , true);
                    var url = new URL(window.location.href);
                    var voteId = url.searchParams.get("Id");
                    var editMode= url.searchParams.get("editMode");
                    if(voteId != null) {
                        component.set("v.isClone",true);   
                        if(editMode){
                            helper.getVoteDetailsData(component, voteId, true, false,true);
                            component.set("v.pageTitle","Vote Details");
                        } 
                        else{
                            helper.getVoteDetailsData(component, voteId, false, false,true);
                            component.set("v.pageTitle","Add Vote");
                        }
                        
                    }
                    else {
                        component.set("v.isClone",false);
                        component.set("v.mainVoteId" , ""); 
                        component.set("v.isVoteSaved",false);
                        component.set("v.selectedLookUpRecord",null);
                        component.set("v.voteDetails",null);
                        component.set("v.editMode",false);
                        component.set("v.pageTitle","Add Vote");
                        component.set("v.initiated",true);
                    }
                }                
                else {
                    component.set("v.insufficientAccessPermissionsError", 
                                 "Insufficient access permissions. Contact system administrator for further assistance");
                    component.set("v.hasAccess" , false);
                }
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    handleComponentEvent: function(component, event, helper) {
        var mainVoteId = event.getParam("mainVoteId");
        var isVoteSaved = event.getParam("isVoteSaved");
        var selectedLookUpRecord = component.get("v.selectedLookUpRecord");
        var voteDetails = component.get("v.voteDetails");
        var editMode = component.get("v.editMode");
        var isClone = component.get("v.isClone");
        
        if(isClone) {
            if(!editMode){
                var voteDetailsForClone = [];
                for(var index=0; index< voteDetails.length;index++){
                    var accountLevel = voteDetails[index]["accountLevel"];
                    helper.getExternalId(component,accountLevel, mainVoteId, index, voteDetailsForClone, voteDetails.length);
                }
            }
        }
        if(isVoteSaved) { 
            var voteDetailsId = component.find("voteDetailsId");
            $A.util.removeClass(voteDetailsId, 'disableTable');
        }  
        component.set("v.mainVoteId" , mainVoteId); 
        helper.getVoteDetailsData(component, mainVoteId, editMode, isVoteSaved,false);
        
    },
    
    saveVoteDetails: function(component, event, helper){
        var appEvent = $A.get("e.c:BV_saveVoteDetailsEvent");
        appEvent.fire();
    },
    
    submitToCSorBM : function(component, event, helper){
        var identifier = event.getSource().getLocalId();
        var status = '';
        var voteType = '';
        if(identifier === "submitToCS") {
            component.set("v.submittedToCS", true);
            status = 'Submitted to CS';
            voteType = 'Account Level';
        }
        if(identifier === "submitToBM") {
            component.set("v.submittedToBM", true);
            status = 'Submitted to BM';
            voteType = 'Individual Level';
        }
        var action = component.get("c.updateVoteStatus");
        action.setParams({"voteId":component.get("v.mainVoteId"),
                          "status": status,
                          "voteType": voteType
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                if(response.getReturnValue().includes('Error')){
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Failed!");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                }
                else{
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", status+"!");
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                    var brokerVote = component.get("v.brokerVote");
                    var userRegion = component.get("v.userRegion");
                    
                    if(voteType === 'Account Level'){
                        if(userRegion === 'EU')
                            brokerVote.BCAP_Account_Level_Status_EU__c = status;
                        if(userRegion === 'NAM')
                            brokerVote.BCAP_Account_Level_Status_US__c = status;
                        component.set("v.brokerVote",brokerVote);
                    }
                    if(voteType === 'Individual Level'){
                        if(userRegion === 'EU')
                            brokerVote.BCAP_Individual_Level_Status_EU__c = status;
                        if(userRegion === 'NAM')
                            brokerVote.BCAP_Individual_Level_Status_US__c = status;
                        component.set("v.brokerVote",brokerVote);
                    }
                    component.set("v.statusInitiated", false);
                    component.set("v.statusInitiated", true);
                }
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    normalizeData1 : function(component, event, helper){
        component.set("v.normalizedPressed",true);
        component.set("v.normalizedDone",false);
        var voteId = component.get("v.mainVoteId");
        var action = component.get("c.normalizeData");
        if(!voteId.includes("Error")){
            action.setParams({"voteId" : voteId});
            action.setCallback(this, function(response){
                var state = response.getState();
                console.log("State: " + state); 
                console.log("Value: " + response.getReturnValue());   
                
                if (response.getReturnValue()) {
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Data normalized successfully!");
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                    helper.resetGridHelper(component, event);
                    component.set("v.normalizedDone", true);
                }
                else{
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Failed to normalize data!");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "10000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();
                }
                component.set("v.normalizedPressed",false);
            });
            $A.enqueueAction(action);  
        }
    },
    changeZIndex: function(component, event, helper){
        var flag = event.getParam("flag"); 
        if(flag) {
            var voteDetailsId = component.find("voteMainRowId");
            $A.util.removeClass(voteDetailsId, 'zindexLarge');
            $A.util.addClass(voteDetailsId, 'zindexSmall');
            
            var voteDetailsGridId = component.find("voteDetailsGridId");
            $A.util.removeClass(voteDetailsGridId, 'overflowauto');
            $A.util.addClass(voteDetailsGridId, 'overflowhidden');
        }
        else{
            var voteDetailsId = component.find("voteMainRowId");
            $A.util.addClass(voteDetailsId, 'zindexLarge');
            $A.util.removeClass(voteDetailsId, 'zindexSmall');
            
            var voteDetailsGridId = component.find("voteDetailsGridId");
            $A.util.addClass(voteDetailsGridId, 'overflowauto');
            $A.util.removeClass(voteDetailsGridId, 'overflowhidden');
        }
    },
    changeToInProgress: function(component, event, helper){
        var hasAtleastOneAccount = event.getParam("hasAtleastOneAccount");
        var hasAtleastOneIndividual = event.getParam("hasAtleastOneIndividual");
        var brokerVote = component.get("v.brokerVote");
        var userRegion = component.get("v.userRegion");
        
        if(hasAtleastOneAccount){
            component.set("v.hasAtleastOneAccount",true);
            if(userRegion === 'EU' && brokerVote.BCAP_Account_Level_Status_EU__c=='Not Started'){
                brokerVote.BCAP_Account_Level_Status_EU__c = 'In Progress';
            }
            if(userRegion === 'NAM' && brokerVote.BCAP_Account_Level_Status_US__c=='Not Started'){
                brokerVote.BCAP_Account_Level_Status_US__c = 'In Progress';
            }
        }
        if(hasAtleastOneIndividual){
            component.set("v.hasAtleastOneIndividual",true);
            if(userRegion === 'EU' && brokerVote.BCAP_Individual_Level_Status_EU__c=='Not Started'){
                brokerVote.BCAP_Individual_Level_Status_EU__c = 'In Progress';
            }
            if(userRegion === 'NAM' && brokerVote.BCAP_Individual_Level_Status_US__c=='Not Started'){
                brokerVote.BCAP_Individual_Level_Status_US__c = 'In Progress';
            }
        }      
        component.set("v.brokerVote",brokerVote);
        component.set("v.statusInitiated", false);
        component.set("v.statusInitiated", true);
    },
    resetGrid: function(component, event, helper) {  
        helper.resetGridHelper(component, event);
    }
})