({
    getExternalId : function(component, accountLevel, mainVoteId, index, voteDetailsForClone, totalAccountLevels){
        var action1 = component.get("c.bvGUID");
        var id = null;
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                id = response.getReturnValue();
                accountLevel["BCAP_External_ID__c"] = id; 
                accountLevel["BCAP_Vote__c"] = mainVoteId;
                accountLevel["Id"] = null;
                accountLevel["CreatedById"] = null;
                accountLevel["CreatedDate"] = null;
                accountLevel["IsDeleted"] = null;
                accountLevel["LastModifiedById"] = null;
                accountLevel["LastModifiedDate"] = null;
                accountLevel["LastReferencedDate"] = null;
                accountLevel["LastViewedDate"] = null;
                accountLevel["Name"] = null;
                //accountLevel["OwnerId"] = null;
                accountLevel["SystemModstamp"] = null;
                accountLevel["BCAP_Is_Submitted_to_CS__c"] = false;
                
                var voteDetail = {};
                voteDetail["accountLevel"] = accountLevel;
                voteDetail["individualLevels"] = [];
                voteDetailsForClone.push(voteDetail);
                component.set("v.voteDetailsForClone", voteDetailsForClone);
                
                var voteDetailsCloneIndex = component.get("v.voteDetailsCloneIndex");
                voteDetailsCloneIndex += 1;
                component.set("v.voteDetailsCloneIndex", voteDetailsCloneIndex);
                
                
                if(component.get("v.isClone") && !component.get("v.editMode") && voteDetailsCloneIndex === totalAccountLevels) {
                    component.set("v.voteDetails", voteDetailsForClone);
                    component.set("v.voteDetailsInitiated", true);
                }
                console.log(voteDetailsForClone);
                
            }
        });
        $A.enqueueAction(action1);          
    },
    
    getVoteDetailsData: function(component, voteId, editMode, isVoteSaved,initialClone){
        component.set("v.showLoadingSpinner",true);
        
        var action = component.get("c.getVoteDetailsDataWithJSON"); 
        var isClone = component.get("v.isClone");
        var userRegion = component.get("v.userRegion");
        action.setParams({
            "voteId" : voteId
        });
        action.setCallback(this, function(response) {
            component.set("v.showLoadingSpinner",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().includes("Error")) {
                    
                }
                else{
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    var brokerVoteResponse = JSON.parse(response.getReturnValue());
                    var brokerVote = brokerVoteResponse["vote"];
                    component.set("v.brokerVote",brokerVote);
                    component.set("v.mainVoteId",voteId);
                    component.set("v.voteDetails",brokerVoteResponse["accountLevels"]);
                    component.set("v.accountCaptures", brokerVoteResponse["accountCaptures"]);
                    component.set("v.individualCaptures", brokerVoteResponse["individualCaptures"]);
                    component.set("v.selectedLookUpRecord" ,{"Name":brokerVote.BCAP_Buying_Centre__r.Name,
                                                             "Id": brokerVote.BCAP_Buying_Centre__c,
                                                            "AccountNumber":brokerVote.BCAP_Buying_Centre__r.AccountNumber});
                    var hasAtleastOneAccount = false;
                    var hasAtleastOneIndividual = false;
                    var accountLevels = brokerVoteResponse['accountLevels'];
                    var count = 0;
                    
                    for(var index=0;index<accountLevels.length;index++){
                        var acc = accountLevels[index];
                        if(acc !== undefined) {
                            hasAtleastOneAccount = true;
                            count += 1;
                        }
                        var individuals = acc['individualLevels'];
                        for(var index1=0;index1<individuals.length;index1++){
                            var ind = individuals[index1];
                            if(ind !== undefined) {
                                hasAtleastOneIndividual = true;
                                count += 1;
                                break;
                            }
                        }
                        if(count == 2) 
                            break;
                    }
                    
                    component.set("v.hasAtleastOneAccount",hasAtleastOneAccount);
                    component.set("v.hasAtleastOneIndividual",hasAtleastOneIndividual);
                    if(userRegion === 'EU') {            
                        if(brokerVote.BCAP_Account_Level_Status_EU__c==='Submitted to CS' ||
                           brokerVote.BCAP_Account_Level_Status_EU__c==='Ready for Flash' ||
                           brokerVote.BCAP_Account_Level_Status_EU__c==='Flash Published' )
                            component.set("v.submittedToCS", true);
                        
                        if(brokerVote.BCAP_Individual_Level_Status_EU__c==='Submitted to BM' ||
                           brokerVote.BCAP_Individual_Level_Status_EU__c==='Published')
                            component.set("v.submittedToBM", true);
                        
                        component.set("v.normalizedDone", brokerVote.BCAP_Individual_Level_Status_EU__c==='Normalized');
                    }
                    if(userRegion === 'NAM') {            
                        if(brokerVote.BCAP_Account_Level_Status_US__c==='Submitted to CS' ||
                           brokerVote.BCAP_Account_Level_Status_US__c==='Ready for Flash' ||
                           brokerVote.BCAP_Account_Level_Status_US__c==='Flash Published' )
                            component.set("v.submittedToCS", true);
                        
                        if(brokerVote.BCAP_Individual_Level_Status_US__c==='Submitted to BM' ||
                           brokerVote.BCAP_Individual_Level_Status_US__c==='Published')
                            component.set("v.submittedToBM", true);
                        
                        component.set("v.normalizedDone", brokerVote.BCAP_Individual_Level_Status_US__c==='Normalized');
                    }
                    if(editMode) {
                        component.set("v.voteDetailsInitiated",true);
                        component.set("v.editMode",true); 
                    }
                    else{
                        if(isClone && isVoteSaved){
                            component.set("v.voteDetailsInitiated",true);
                        }
                        var voteDetailsId = component.find("voteDetailsId");
                        $A.util.addClass(voteDetailsId, 'disableTable');
                    }
                    if(isVoteSaved) {
                        component.set("v.isVoteSaved",true);
                        component.set("v.voteDetailsInitiated",true);
                        var voteDetailsId = component.find("voteDetailsId");
                        $A.util.removeClass(voteDetailsId, 'disableTable');
                    }
                    if(initialClone) {
                        component.set("v.initiated",true);
                        if(editMode)
                        	component.set("v.statusInitiated",true);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    resetGridHelper: function(component, event) {
        var action = component.get("c.getVoteDetailsDataWithJSON"); 
        var voteId = component.get("v.mainVoteId");
        action.setParams({
            "voteId" : voteId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().includes("Error")) {
                }
                else{
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    var brokerVoteResponse = JSON.parse(response.getReturnValue());
                    component.set("v.voteDetails",brokerVoteResponse["accountLevels"]);
                    component.set("v.accountCaptures", brokerVoteResponse["accountCaptures"]);
                    component.set("v.individualCaptures", brokerVoteResponse["individualCaptures"]);

                    var hasAtleastOneAccount = false;
                    var hasAtleastOneIndividual = false;
                    var accountLevels = brokerVoteResponse['accountLevels'];
                    var count = 0;
                    for(var index=0;index<accountLevels.length;index++){
                        var acc = accountLevels[index];
                        if(acc !== undefined) {
                            hasAtleastOneAccount = true;
                            count += 1;
                        }
                        var individuals = acc['individualLevels'];
                        for(var index=0;index<individuals.length;index++){
                            var ind = individuals[index];
                            if(ind !== undefined) {
                                hasAtleastOneIndividual = true;
                                count += 1;
                                break;
                            }
                        }
                        if(count == 2) 
                            break;
                    }
                    
                    component.set("v.hasAtleastOneAccount",hasAtleastOneAccount);
                    component.set("v.hasAtleastOneIndividual",hasAtleastOneIndividual);
                    component.set("v.voteDetailsInitiated",false);
                    component.set("v.voteDetailsInitiated",true);
                    
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Grid Reset!");
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);     
}
})