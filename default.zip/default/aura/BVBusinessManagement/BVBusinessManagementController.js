({
	init :function (component, event, helper){
        var action = component.get("c.getUserType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var userType = response.getReturnValue();
                if(userType.includes('Admin')) {
                    component.set("v.isAdminUser", true);
                    component.set("v.userType","Admin");
                }
                if(userType.includes('Pilot')){
                    component.set("v.isPilotUser", true);
                    component.set("v.userType","Data Team");
                }
                    
                if(userType.includes('ClientStrategy')) {
                    component.set("v.isClientStrategyUser", true);
                    component.set("v.userType","Client Strategy");
                }
                if(userType.includes('BusinessManagement')) {
                    component.set("v.isBusinessMgmtUser", true);
                    component.set("v.userType","Business Management");
                }
                if(userType.includes('NAM')) {
                    component.set("v.userRegion", "NAM");
                    component.set("v.selectedRegion", "NAM");
                }
                if(userType.includes('EU')) {
                    component.set("v.userRegion", "EU");
                    component.set("v.selectedRegion", "EU");
                }
                if(userType.includes('BMGlobal')) {
                    component.set("v.userRegion", "Global");
                    component.set("v.selectedRegion", "Global");
                }       
                var isBusinessMgmtUser = component.get("v.isBusinessMgmtUser");
                var isAdminUser = component.get("v.isAdminUser");
                if(isBusinessMgmtUser || isAdminUser){
                    component.set("v.hasAccess" , true);
                    helper.initVoteData(component, event, "Init");
                }                
                else {
                    component.set("v.insufficientAccessPermissionsError", 
                                 "Insufficient access permissions. Contact system administrator for further assistance");
                    component.set("v.hasAccess" , false);
                }
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    resetGrid: function(component, event, helper) {
         helper.initVoteData(component, event, "Reset");
    },
    saveVoteDetails: function(component, event, helper){
        component.set("v.showLoadingSpinner",true);
        component.set("v.savePressed",true);
        var voteId = component.get("v.mainVoteId");
        var action = component.get("c.saveBMViewJSON");
		var formattedJSON = helper.formatJSON(component, event);
        action.setParams({
            "params" : JSON.stringify(formattedJSON)
        });
        action.setCallback(this, function(response){
            component.set("v.showLoadingSpinner",false);
            var state = response.getState();
            console.log("State: " + state); 
            console.log("Value: " + response.getReturnValue()); 
            component.set("v.savePressed",false);
            helper.initVoteData(component, event, "Init");
            if (response.getReturnValue()) {
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Data saved successfully!");
                appEvent.setParam("type", "success");
                appEvent.setParam("duration", "3000");                     
                appEvent.setParam("mode", "dismissible");
                appEvent.fire(); 

            }
            else{
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Failed to save data!");
                appEvent.setParam("type", "error");
                appEvent.setParam("duration", "10000");                     
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();
            }
        });
        $A.enqueueAction(action);  
       
    },
    resubmitToBV: function(component, event, helper) {
        component.set("v.resubmittedToBV",true);
        var status = 'Resubmit To BV';
        var voteType ='Individual Level';
        helper.updateBVStatus(component, event, status, voteType);
    },
    publishVote: function(component, event, helper) {
        var status = 'Published';
        var voteType ='Individual Level';
        helper.updateBVStatus(component, event, status, voteType);
    },
    normalize: function(component, event, helper) {
        component.set("v.showLoadingSpinner",true);
        component.set("v.normalizedPressed",true);
        var voteId = component.get("v.mainVoteId");
        var action = component.get("c.normalizeData");
        
        action.setParams({
            "voteId" : voteId
        });
        action.setCallback(this, function(response){
            component.set("v.showLoadingSpinner",false);
            var state = response.getState();
            console.log("State: " + state); 
            console.log("Value: " + response.getReturnValue());   
            if (response.getReturnValue()) {
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Data normalized successfully!");
                appEvent.setParam("type", "success");
                appEvent.setParam("duration", "3000");                     
                appEvent.setParam("mode", "dismissible");
                appEvent.fire(); 
                helper.initVoteData(component, event, "Normalize");
            }
            else{
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Failed to normalize data!");
                appEvent.setParam("type", "error");
                appEvent.setParam("duration", "10000");                     
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();
            }
            component.set("v.normalizedPressed",false);
        });
        $A.enqueueAction(action);  
       
    }
})