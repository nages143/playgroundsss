({
    initVoteData:  function(component, event, reason) {
        var url = new URL(window.location.href);
        var voteId = url.searchParams.get("Id");
        var userRegion = component.get("v.userRegion");
        if(reason == "Reset") {
            component.set("v.resetPressed",true);
        }
        component.set("v.pageTitle","Vote Details");
        
        if(voteId != null) {
            component.set("v.showLoadingSpinner",true);
            var action = component.get("c.getBMViewJSON"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                component.set("v.showLoadingSpinner",false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    if(response.getReturnValue().includes("Error")) {
                        
                    }
                    else{
                        console.log("From server: " + JSON.stringify(response.getReturnValue()));
                        var bvResponse = JSON.parse(response.getReturnValue());
                        var allocMethodology = JSON.parse(bvResponse["allocMethodology"]).allocationMethods;
                        component.set("v.brokerVote", bvResponse);
                        component.set("v.mainVoteId", voteId);
                        component.set("v.bcId", bvResponse["bcId"]);
                        component.set("v.bcName", bvResponse["bcName"]);
                        component.set("v.tiers", bvResponse["tiers"]);
                        component.set("v.voteFrequency", bvResponse["voteFrequency"]);
                        component.set("v.votePeriod", bvResponse["votePeriod"]);
                        component.set("v.region", bvResponse[""]);
                        component.set("v.payment", bvResponse["payment"]);
                        component.set("v.clientDetail", bvResponse["clientDetail"]);
                        component.set("v.allocMethodology", allocMethodology);
                        
                        component.set("v.allocationMethodsWithLists", JSON.parse(JSON.stringify(component.get("v.allocMethodology"))));
                        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
                        if(allocationMethodsWithLists != undefined) {
                            for(var index=0; index < allocationMethodsWithLists.length; index++) {
                                var rules = allocationMethodsWithLists[index].BCAP_Rule__c.split("\n");
                                var scores = allocationMethodsWithLists[index].BCAP_Score__c.split("\n");
                                var data = [];
                                for(var i=0;i<rules.length;i++) {
                                    var row = {'Rule': rules[i], 'Score': scores[i]};
                                    data.push(row);
                                }
                                allocationMethodsWithLists[index].Rule_Score_List = data;
                            }
                            component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
                        }
                        
                        component.set("v.votingEntities", bvResponse["votingEntities"]);
                        component.set("v.allDetails", bvResponse["allDetails"]);
                        component.set("v.sectorContacts", bvResponse["sectorContacts"]);
                        component.set("v.pclNonpclValues", bvResponse["pclNonPclValues"]);
                        component.set("v.leadAnalystSummary", bvResponse["leadAnalystSummary"]);
                        component.set("v.individualView", bvResponse["individualViews"]);
                        component.set("v.individualCaptures", bvResponse["individualCaptures"]);
                        
                        if(userRegion === 'EU'){
                            if(bvResponse["vote"].BCAP_Individual_Level_Status_EU__c === 'In Progress' ) {
                                component.set("v.inProgress", true);
                            }
                            if(bvResponse["vote"].BCAP_Individual_Level_Status_EU__c === 'Published' ) {
                                component.set("v.fullVotePublished", true);
                            }
                        }
                        if(userRegion === 'NAM'){
                            if(bvResponse["vote"].BCAP_Individual_Level_Status_US__c === 'In Progress' ) {
                                component.set("v.inProgress", true);
                            }
                            if(bvResponse["vote"].BCAP_Individual_Level_Status_US__c === 'Published' ) {
                                component.set("v.fullVotePublished", true);
                            }
                        }
                        
                        if(reason == "Reset") {
                            component.set("v.dataLoaded",false);
                            component.set("v.dataLoaded",true);
                            component.set("v.resetPressed",false);
                            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                            appEvent.setParam("message", "Data reset!");
                            appEvent.setParam("type", "success");
                            appEvent.setParam("duration", "3000");                     
                            appEvent.setParam("mode", "dismissible");
                            appEvent.fire(); 
                        }
                        else if(reason == "Normalize"){
                            component.set("v.dataLoaded",false);
                            component.set("v.dataLoaded",true);
                        }
                            else if(reason =="Init"){
                                this.initDocuments(component,event);
                                component.set("v.dataLoaded",false);
                                component.set("v.dataLoaded",true);
                               // component.set("v.statusInitiated",false);
                                //component.set("v.statusInitiated",true);
                            }
                    }
                }
            });
            $A.enqueueAction(action);
        }
    },
    initDocuments: function(component, event) {
        var voteId = component.get("v.mainVoteId");
        if(voteId != null) {
            var action = component.get("c.getDocuments"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                var result = response.getReturnValue();
                component.set("v.listOfDocuments", result);                
                component.set("v.totalDocuments", result.length);
                component.set("v.dataLoaded",true);
                component.set("v.statusInitiated",true);
            });
            $A.enqueueAction(action);
        }
    },
    updateBVStatus: function(component, event, status, voteType) {
        
        var action = component.get("c.updateVoteStatus");
        action.setParams({"voteId":component.get("v.mainVoteId"),
                          "status": status,
                          "voteType": voteType
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                if(response.getReturnValue().includes('Error')){
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Failed!");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                }
                else{
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    if(status == 'Resubmit To BV') {
                        appEvent.setParam("message", "Re-submitted to BV!");   
                        status = 'In Progress';
                        component.set("v.resubmittedToBV", true);
                        component.set("v.inProgress", true);
                    }
                    if(status == 'Published') {
                        appEvent.setParam("message", "Full vote published!"); 
                        component.set("v.fullVotePublished", true);
                    }
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                    
                    var brokerVote = component.get("v.brokerVote.vote");
                    var userRegion = component.get("v.userRegion");
                    
                    if(userRegion === 'EU')
                        brokerVote.BCAP_Individual_Level_Status_EU__c = status;
                    if(userRegion === 'NAM')
                        brokerVote.BCAP_Individual_Level_Status_US__c = status;
                    
                    component.set("v.brokerVote.vote",brokerVote);
                    component.set("v.statusInitiated", false);
                    component.set("v.statusInitiated", true);
                }
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    formatJSON : function(component, event, status, voteType) {
        var allDetails = component.get("v.allDetails");
        var records = [];
        for(var i=0;i< allDetails.length; i++) {
            var record = {"Id":allDetails[i].Id,
                          "BCAP_Rank__c" : allDetails[i].BCAP_Rank__c,
                          "BCAP_Notes__c" : allDetails[i].BCAP_Notes__c};
            records.push(record);
        }
        var formattedJSON = {"individualLevels" : records};
        return formattedJSON;
    }
})