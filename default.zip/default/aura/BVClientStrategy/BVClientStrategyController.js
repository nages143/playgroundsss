({
    init :function (component, event, helper){
        var action = component.get("c.getUserType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var userType = response.getReturnValue();
                if(userType.includes('Admin')) {
                    component.set("v.isAdminUser", true);
                    component.set("v.userType","Admin");
                }
                if(userType.includes('Pilot')){
                    component.set("v.isPilotUser", true);
                    component.set("v.userType","Data Team");
                }
                    
                if(userType.includes('ClientStrategy')) {
                    component.set("v.isClientStrategyUser", true);
                    component.set("v.userType","Client Strategy");
                }
                if(userType.includes('BusinessManagement')) {
                    component.set("v.isBusinessMgmtUser", true);
                    component.set("v.userType","Business Management");
                }
                if(userType.includes('NAM')) 
                    component.set("v.userRegion", "NAM");
                if(userType.includes('EU')) 
                    component.set("v.userRegion", "EU");
                
                var isClientStrategyUser = component.get("v.isClientStrategyUser");
                var isAdminUser = component.get("v.isAdminUser");
                if(isClientStrategyUser || isAdminUser){
                    component.set("v.hasAccess" , true);
                     helper.initVoteData(component, event);
                }                
                else {
                    component.set("v.insufficientAccessPermissionsError", 
                                 "Insufficient access permissions. Contact system administrator for further assistance");
                    component.set("v.hasAccess" , false);
                }
                component.set("v.userInitiated", true);
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    saveChanges : function(component, event, helper) {
        var  contentPaymentForLatestVote = component.get("v.contentPaymentForLatestVote");
        var contentPaymentAnnualised = component.get("v.contentPaymentAnnualised");
        var annualContentPaymentVsTarget = component.get("v.annualContentPaymentVsTarget");
        var contentPaymentPreviousFYTotal = component.get("v.contentPaymentPreviousFYTotal");
        var contentPaymentCurrentYTDTotal = component.get("v.contentPaymentCurrentYTDTotal");
        var unbundledContentTargetCurrentFY = component.get("v.unbundledContentTargetCurrentFY");
        var AMNotes = component.get("v.AMNotes");
        var voteId = component.get("v.mainVoteId");
        
        var buttonId = event.getSource().getLocalId();
        
        var params = {'contentPaymentForLatestVote':contentPaymentForLatestVote,
                      'contentPaymentAnnualised':contentPaymentAnnualised,
                      'annualContentPaymentVsTarget':annualContentPaymentVsTarget,
                      'contentPaymentPreviousFYTotal':contentPaymentPreviousFYTotal,
                      'contentPaymentCurrentYTDTotal':contentPaymentCurrentYTDTotal,
                      'unbundledContentTargetCurrentFY':unbundledContentTargetCurrentFY,
                      'AMNotes':AMNotes,
                      'voteId':voteId};
        
        var saveAction = component.get("c.saveClientStrategyDataWithJSON");
        saveAction.setParams({
            'params': JSON.stringify(params)                                 
        });
        saveAction.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                //alert('Broker Vote saved');
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var brokerVoteId = response.getReturnValue();
                if(!response.getReturnValue().includes("Error")){
                    if(buttonId ==="saveButton"){
                        var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                        appEvent.setParam("message", $A.get("$Label.c.brokerVoteClientStrategyDataSaveSuccess"));
                        appEvent.setParam("type", "success");
                        appEvent.setParam("duration", "3000");
                        appEvent.setParam("mode", "dismissible");
                        appEvent.fire();
                    }
                    if(buttonId ==="previewButton"){
                        //helper.getVoteData(component, event);
                        component.set("v.showPreviewDialog", true);
                    }
                }
                else {
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message",  $A.get("$Label.c.brokerVoteClientStrategyDataSaveError"));
                    appEvent.setParam("type", "error");
                    appEvent.setParam("mode", "sticky");
                    appEvent.fire();
                }
            }                                
        });
        $A.enqueueAction(saveAction);
        
    },
    
    resubmitToBV: function(component, event, helper) {
        component.set("v.resubmittedToBV",true);
        var status = 'Resubmit To BV';
        var voteType ='Account Level';
        var action = component.get("c.updateVoteStatus");
        action.setParams({"voteId":component.get("v.mainVoteId"),
                          "status": status,
                          "voteType": voteType
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                if(response.getReturnValue().includes('Error')){
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Failed!");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                }
                else{
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Re-submitted to BV!");
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                    component.set("v.submittedToCS", false);
                    
                    var brokerVote = component.get("v.brokerVote");
                    var userRegion = component.get("v.userRegion");
                    status = 'In Progress';
                    if(userRegion === 'EU')
                        brokerVote.BCAP_Account_Level_Status_EU__c = status;
                    if(userRegion === 'NAM')
                        brokerVote.BCAP_Account_Level_Status_US__c = status;
                    
                    component.set("v.brokerVote",brokerVote);
                    component.set("v.statusInitiated", false);
                    component.set("v.statusInitiated", true);
                }
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    saveGraphCode: function(component, event, helper) {
        var code= event.getParam("graphcode");
        component.set("v.graphcode", code);
    },
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Preview Flash Email') {
            if(actionType === 'No') {
                helper.closeModel(component, event);
            }
            if(actionType === 'Yes') {
                helper.publishFlashEmail(component, event);
            }
        }
    }
})