({
    initVoteData:  function(component, event) {
        var url = new URL(window.location.href);
		var voteId = url.searchParams.get("Id");
   		var userRegion = component.get("v.userRegion");
        
        component.set("v.pageTitle","Vote Details");
        
        if(voteId != null) {
			component.set("v.isClone",true);            
            var action = component.get("c.getVoteDetailsDataWithJSON"); 
			action.setParams({
            	"voteId" : voteId
          	});
        	action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().includes("Error")) {
                   
                }
                else{
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    var brokerVoteResponse = JSON.parse(response.getReturnValue());
                    var brokerVote = brokerVoteResponse["vote"];
                    component.set("v.brokerVote",brokerVote);
                    component.set("v.mainVoteId",voteId);
                    component.set("v.isVoteSaved",event.getParam("isVoteSaved"));
					component.set("v.selectedLookUpRecord" ,{"Name":brokerVote.BCAP_Buying_Centre__r.Name,
                                                             "Id": brokerVote.BCAP_Buying_Centre__c,
                                                             "AccountNumber":brokerVote.BCAP_Buying_Centre__r.AccountNumber});                    component.set("v.voteDetails",event.getParam("voteDetails"));
                    component.set("v.editMode",false);
                    component.set("v.voteDetails",brokerVoteResponse["accountLevels"]);
                    component.set("v.accountCaptures", brokerVoteResponse["accountCaptures"]);
                    component.set("v.individualCaptures", brokerVoteResponse["individualCaptures"]);
                    component.set("v.contentPaymentForLatestVote",brokerVote.BCAP_Content_Payment_for_Latest_Vote__c);
                    component.set("v.contentPaymentAnnualised",brokerVote.BCAP_Content_Payment_Annualised__c);
                    component.set("v.annualContentPaymentVsTarget",brokerVote.BCAP_Annual_Content_Payment_Vs_Target__c);
                    component.set("v.contentPaymentPreviousFYTotal",brokerVote.BCAP_Content_Payment_Previous_FY_Total__c); 
                    component.set("v.contentPaymentCurrentYTDTotal",brokerVote.BCAP_Content_Payment_Current_YTD_Total__c); 
                    component.set("v.unbundledContentTargetCurrentFY",brokerVote.BCAP_Unbundled_Content_Target_Current_FY__c); 
                    component.set("v.AMNotes",brokerVote.BCAP_AM_Notes__c);
                    
                    if(userRegion === 'EU'){
                        if(brokerVote.BCAP_Account_Level_Status_EU__c === 'Submitted to CS' ) {
                            component.set("v.resubmittedToBV", false);
                            component.set("v.submittedToCS", true);
                        }
                        else{
                            component.set("v.resubmittedToBV", true);
                        }
                        if(brokerVote.BCAP_Account_Level_Status_EU__c === 'Flash Published' ) {
                            component.set("v.flashPublished", true);
                        }
                    }
                    if(userRegion === 'NAM'){
                        if(brokerVote.BCAP_Account_Level_Status_US__c === 'Submitted to CS'  ) {
                            component.set("v.resubmittedToBV", false);
                            component.set("v.submittedToCS", true);
                        }
                        else{
                            component.set("v.resubmittedToBV", true);
                        }
                         if(brokerVote.BCAP_Account_Level_Status_US__c === 'Flash Published' ) {
                            component.set("v.flashPublished", true);
                        }
                    }
                    this.initDocuments(component,event);
                }
            }
        });
        $A.enqueueAction(action);
        }
    },
      initDocuments: function(component, event) {
        var voteId = component.get("v.mainVoteId");
        if(voteId != null) {
            var action = component.get("c.getDocuments"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                var result = response.getReturnValue();
                component.set("v.listOfDocuments", result);                
                component.set("v.totalDocuments", result.length);
                component.set("v.dataLoaded",true);
                component.set("v.statusInitiated",true);
            });
            $A.enqueueAction(action);
        }
    },
    getVoteData: function (component, event) {
        
            var url = new URL(window.location.href);
            var voteId = url.searchParams.get("Id");
            if(voteId != null) {
                var action = component.get("c.getVoteDetailsDataWithJSON"); 
                action.setParams({
                    "voteId" : voteId
                });
                action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var brokerVoteResponse = JSON.parse(response.getReturnValue());
                    var vote = brokerVoteResponse["vote"];
                    var voteDetails = brokerVoteResponse["accountLevels"];
                    var flashDetails = brokerVoteResponse["flashDetails"];
                    flashDetails = JSON.parse(flashDetails); 
                    var ranks = brokerVoteResponse["ranks"];
                    var trailingVoteRanks = brokerVoteResponse["trallingVoteRanks"];
                    
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
        		
                    var keyRank = []
                    var addRank = []
                    for (var i = 0; i < ranks.length; i++) {
                    	var rank = ranks[i];
                        rank['overallRank'] = parseInt(rank['overallRank'] );
                        rank['preOverallRank'] = parseInt(rank['preOverallRank'] );
                        if(rank["rankType"] === "Key Rank")
                            keyRank.push(rank);
                        else 
                            addRank.push(rank);
                	}
                    
                    var accountManager = {};
                    var wallet = {};
                    var share = {};
                    var clientTier = {};
                    
                    if(flashDetails != null) {
                        if (flashDetails["clientTier"] !=null) {
                            if(flashDetails["clientTier"][0] != null) {
                                var clientTier0 = flashDetails["clientTier"][0];
                                clientTier[clientTier0['region']] = clientTier0['tier'];
                            }
                            if(flashDetails["clientTier"][1] != null) {
                                var clientTier1 = flashDetails["clientTier"][1];
                                clientTier[clientTier1['region']] = clientTier1['tier'];
                            }
                        }
                        if (flashDetails["coverage"] !=null) {
                            if(flashDetails["coverage"][0] != null) {
                                var coverage0 = flashDetails["coverage"][0];
                                accountManager[coverage0['region']] = coverage0['accountManager'];
                            }
                            if(flashDetails["coverage"][1] != null) {
                                var coverage1 = flashDetails["coverage"][1];
                                accountManager[coverage1['region']] = coverage1['accountManager'];
                            }
                        }   
                        if (flashDetails["mcLaganData"] !=null) {
                            if(flashDetails["mcLaganData"][0] != null) {
                                var mcLaganData0 = flashDetails["mcLaganData"][0];
                                wallet[mcLaganData0['region']] = ((parseFloat(mcLaganData0['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData0['region']] = ((parseFloat(mcLaganData0['share'])) * 100).toFixed(2) + '%';
                            }
                            if(flashDetails["mcLaganData"][1] != null) {
                                var mcLaganData1 = flashDetails["mcLaganData"][1];
                                wallet[mcLaganData1['region']] = ((parseFloat(mcLaganData1['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData1['region']] = ((parseFloat(mcLaganData1['share'])) * 100).toFixed(2) + '%';
                            }
                            if(flashDetails["mcLaganData"][2] != null) {
                                var mcLaganData2 = flashDetails["mcLaganData"][2];
                                wallet[mcLaganData2['region']] = ((parseFloat(mcLaganData2['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData2['region']] = ((parseFloat(mcLaganData2['share'])) * 100).toFixed(2) + '%';
                            }
                        }
                    }
                    var url = new URL(window.location.href);
        			var urlString = encodeURI(url);
        			//var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
        			//redirectUrl = redirectUrl + '/BVLanding.app';
                    
                    var redirectUrl = 'http://teams.barclays.intranet/sites/emeaequitiesclientstrategy/Shared%20Documents/Forms/AllItems.aspx?RootFolder=%2fsites%2femeaequitiesclientstrategy%2fShared%20Documents%2fClient%20Vote%20Files&FolderCTID=0x0120006C987036CAB3164D99A9F56BC9FADDF5';
                    
                    component.set("v.vote",vote);                
                    component.set("v.voteDetails",voteDetails);
                    component.set("v.accountManager",accountManager);
                    component.set("v.wallet",wallet);
                    component.set("v.share",share);
                    component.set("v.clientTier",clientTier);
                    component.set("v.keyRank",keyRank);
                    component.set("v.additionalRank",addRank);
                    component.set("v.BVUrl",redirectUrl);
                    component.set("v.trailingVoteRanks",trailingVoteRanks);
                    component.set("v.showPreviewDialog", true);
                }
            });
            $A.enqueueAction(action);
            }
	},
    saveEmailData: function(component, event, output, graphData) {
        
        var id = component.get("v.brokerVote").Id;
        var externalId = component.get("v.brokerVote").BCAP_External_Id__c;
        var graphcode = component.get("v.graphcode");
        var params = {
            "voteId": id,
            "externalId": externalId,
            "code": output,
            "graphCode":graphcode
        }
        var action = component.get("c.saveVoteMessage");
        action.setParams({
            "params": JSON.stringify(params)
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", 'Flash email published!');
                appEvent.setParam("type", "success");
                appEvent.setParam("duration", "5000");
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();
                
                component.set("v.showPreviewDialog", false);
                
                var brokerVote = component.get("v.brokerVote");
                var userRegion = component.get("v.userRegion");
                if(userRegion === 'EU')
                    brokerVote.BCAP_Account_Level_Status_EU__c = 'Flash Published';
                if(userRegion === 'NAM')
                    brokerVote.BCAP_Account_Level_Status_US__c = 'Flash Published';
                
                component.set("v.brokerVote",brokerVote);
                component.set("v.statusInitiated", false);
                component.set("v.statusInitiated", true);
                component.set("v.resubmittedToBV",false);
                component.set("v.submittedToCS",false);
                component.set("v.flashPublished",true);
            }
            else{
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", 'Error while publishing flash email!');
                appEvent.setParam("type", "error");
                appEvent.setParam("duration", "5000");
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    publishFlashEmail : function(component, event){
        var markup = document.getElementById('flashEmailContent');
		var output = markup.outerHTML;
		//console.log(output);
        
        var markup2 = document.getElementById('graphData');
		var graphData = markup2.outerHTML;
        //console.log(graphData);
        
        var markup3 = document.getElementById('graphDataOuterDiv');
		var graphDataOuterDiv = markup3.outerHTML;
		//console.log(graphDataOuterDiv);
        
        output = output.replace(graphDataOuterDiv, '<img src=\"cid:image1\" />');
        //console.log(output);
        
        this.saveEmailData(component, event, output, graphData);
        
        /*var element = document.createElement('a');
      	element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(output));
      	element.setAttribute('download', 'previewEmail.html');
      	element.style.display = 'none';
      	document.body.appendChild(element);
      	element.click();
      	document.body.removeChild(element);*/
    },
    closeModel: function(component, event) {
      component.set("v.showPreviewDialog", false);
   },
})