({
	init:function (component, evt, helper){
		var action = component.get("c.getUserType");
		action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var userType = response.getReturnValue();
                if(userType.includes('Admin')) {
                    component.set("v.isAdminUser", true);
                    component.set("v.userType","Admin");
                }
                if(userType.includes('Pilot')){
                    component.set("v.isPilotUser", true);
                    component.set("v.userType","Data Team");
                }
                    
                if(userType.includes('ClientStrategy')) {
                    component.set("v.isClientStrategyUser", true);
                    component.set("v.userType","Client Strategy");
                }
                if(userType.includes('BusinessManagement')) {
                    component.set("v.isBusinessMgmtUser", true);
                    component.set("v.userType","Business Management");
                }
                if(userType.includes('BMGlobal')) {
                    component.set("v.isGlobalBusinessMgmtUser", true);
                }
                if(userType.includes('NAM')) 
                    component.set("v.userRegion", "NAM");
                if(userType.includes('EU')) 
                    component.set("v.userRegion", "EU");
                
                var isPilotUser = component.get("v.isPilotUser");
                var isClientStrategyUser = component.get("v.isClientStrategyUser");
                var isBusinessMgmtUser = component.get("v.isBusinessMgmtUser");
                var isAdminUser = component.get("v.isAdminUser");
                if(isPilotUser || isClientStrategyUser  || isBusinessMgmtUser || isAdminUser){
                    component.set("v.hasAccess" , true);
                }                
                else {
                    component.set("v.insufficientAccessPermissionsError", 
                                 "Insufficient access permissions. Contact system administrator for further assistance");
                    component.set("v.hasAccess" , false);
                }
                component.set("v.userInitiated",true);
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    }
})