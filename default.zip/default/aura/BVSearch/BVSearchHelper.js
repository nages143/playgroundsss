({
    getSearchData : function (component, event, helper){
        
        var action = component.get("c.searchBrokerVotes");
        
        var buyingCenter = component.get("v.selectedLookUpRecord");
        var votePeriod = component.get("v.selectedLookUpPeriodRecord");
        var scorecardMonthFromId = component.find('scorecardMonthFromId').get('v.value');
        var scorecardYearFromId = component.find('scorecardYearFromId').get('v.value');
        
        var scorecardMonthToId = component.find('scorecardMonthToId').get('v.value');
        var scorecardYearToId = component.find('scorecardYearToId').get('v.value');
        
        var voteStatus = component.get('v.voteStatus');
        if(voteStatus=="") 
            voteStatus = null;
        
        var voteCycleId = component.get('v.voteCycleValue');
        if(voteCycleId=="") 
            voteCycleId = null;
        
        var tier = component.get('v.tier');
        if(tier=="") 
            tier = null;
        
        var functionVal = component.get('v.function');
        if(functionVal=="") 
            functionVal = null;
        
        var barclaysIndividual = component.get('v.selectedEmployeeRecord').Id;
        var clientContact = component.get('v.selectedClientContactRecord').Id;
        var votingTeam = component.get('v.votingTeam');
        if(votingTeam=="") 
            votingTeam = null;
        
        var sector = component.get('v.sector');
        if(sector=="") 
            sector = null;
        
        var startDate = null;
        var endDate = null;
        var months = {"Jan":'01',"Feb":'02',"Mar":'03',"Apr":'04',"May":'05',"Jun":'06',"Jul":'07',
                          "Aug":'08',"Sep":'09',"Oct":'10',"Nov":'11',"Dec":'12'};
        if(scorecardMonthFromId != "Select" && scorecardYearFromId != "Select" &&
          scorecardMonthFromId != undefined && scorecardYearFromId != undefined){
            startDate =scorecardYearFromId+ "-" + months[scorecardMonthFromId]+ "-" + "01";
        } 
        if(scorecardMonthToId != "Select" && scorecardYearToId != "Select" &&
          scorecardMonthToId != undefined && scorecardYearToId != undefined) {
            var daysOfMonth = {"Jan":31,"Feb":28,"Mar":31,"Apr":30,"May":31,"Jun":30,"Jul":31,
                               "Aug":31,"Sep":30,"Oct":31,"Nov":30,"Dec":31};
            if((scorecardYearToId % 100 === 0) ? (scorecardYearToId % 400 === 0) : (scorecardYearToId % 4 === 0)) {
                daysOfMonth["feb"] = 29;
            }
            endDate = scorecardYearToId + "-" + months[scorecardMonthToId]  + "-" + daysOfMonth[scorecardMonthToId];
        }
        component.set("v.fetchedData" ,false);
        
        var params = {"buyingCenter": buyingCenter.Id,
                      "votePeriod": votePeriod.Id,
                      "startDate": startDate,
                      "endDate": endDate,
                      "voteIds": "",
                      "reportType": "BV_Vote_Details",
                      "voteCycleId": voteCycleId,
                      "voteStatus":voteStatus,
                      "tier":tier,
                      "functionVal":functionVal,
                      "votingTeam":votingTeam,
                      "sector":sector,
                      "barclaysIndividual":barclaysIndividual,
                      "clientContact":clientContact
                     }; 
        
        action.setParams({
            'params': JSON.stringify(params)
        });
        
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var storeResponse = response.getReturnValue();
                // set searchResult list with return value from server.
                component.set("v.listOfBrokerVotes", storeResponse);
                component.set("v.fetchedData" ,true);
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    exportReport : function (component, event, helper, reportType){
        
        var action = component.get("c.exportReport");        
        var buyingCenter = component.get("v.selectedLookUpRecord");
        var votePeriod = component.get("v.selectedLookUpPeriodRecord");
        var scorecardMonthFromId = component.find('scorecardMonthFromId').get('v.value');
        var scorecardYearFromId = component.find('scorecardYearFromId').get('v.value');
        
        var scorecardMonthToId = component.find('scorecardMonthToId').get('v.value');
        var scorecardYearToId = component.find('scorecardYearToId').get('v.value');
        
        var voteCycleId = component.get('v.voteCycleValue');
        var voteStatusId = component.get('v.voteStatus');
        
        var startDate = null;
        var endDate = null;
        var months = {"Jan":'01',"Feb":'02',"Mar":'03',"Apr":'04',"May":'05',"Jun":'06',"Jul":'07',
                          "Aug":'08',"Sep":'09',"Oct":'10',"Nov":'11',"Dec":'12'};
        if(scorecardMonthFromId != "Select" && scorecardYearFromId != "Select"){
            startDate =scorecardYearFromId+ "-" + months[scorecardMonthFromId]+ "-" + "01";
        } 
        if(scorecardMonthToId != "Select" && scorecardYearToId != "Select") {
            var daysOfMonth = {"Jan":31,"Feb":28,"Mar":31,"Apr":30,"May":31,"Jun":30,"Jul":31,
                               "Aug":31,"Sep":30,"Oct":31,"Nov":30,"Dec":31};
            if((scorecardYearToId % 100 === 0) ? (scorecardYearToId % 400 === 0) : (scorecardYearToId % 4 === 0)) {
                daysOfMonth["feb"] = 29;
            }
            endDate = scorecardYearToId + "-" + months[scorecardMonthToId]  + "-" + daysOfMonth[scorecardMonthToId];
        }
        //component.set("v.fetchedData" ,false);
        
        var params = {"buyingCenter": buyingCenter,
                      "votePeriod": votePeriod,
                      "startDate": startDate,
                      "endDate": endDate,
                      "voteIds": "",
                      "reportType": reportType,
                     "voteCycleId": voteCycleId}; 
        
        action.setParams({
            'params': JSON.stringify(params)
        });
        
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + response.getReturnValue());
                var storeResponse = response.getReturnValue();
                //component.set("v.fetchedData" ,true);
                window.open(storeResponse);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        if(buyingCenter.Name==undefined && votePeriod.Name == undefined && startDate==null && endDate==null && voteCycleId==undefined && voteStatusId==undefined){
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message",  "Please select atleast one filter!");
            appEvent.setParam("type", "error");
            appEvent.setParam("mode", "dismissible");
            appEvent.setParam("duration", "3000");
            appEvent.fire();
           // component.set("v.fetchedData" ,true);
        }
        else{
             $A.enqueueAction(action);
        }
       
    },
    getAccountLevelStatuses: function (component, event){
        var action1 = component.get("c.getAccountLevelStatus");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var voteStatuses = [];
                console.log("From server returnVals: " + JSON.stringify(response.getReturnValue()));
                var returnVals = response.getReturnValue();
                voteStatuses.push({'label' :'Select' , 'value':null});
                for(var i=0;i<returnVals.length; i++){
                    voteStatuses.push({'label' :'Acc. - '+returnVals[i] , 'value':'Acc. - '+returnVals[i]});
                } 
                component.set("v.voteStatuses", voteStatuses);
                this.getIndividualLevelStatuses(component, event);
            }
        });
        $A.enqueueAction(action1);
    },
    getIndividualLevelStatuses: function (component, event){
        var action1 = component.get("c.getIndividualLevelStatus");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var voteStatuses = component.get("v.voteStatuses");
                console.log("From server returnVals: " + JSON.stringify(response.getReturnValue()));
                var returnVals = response.getReturnValue();
                for(var i=0;i<returnVals.length; i++){
                    voteStatuses.push({'label' :'Ind. - '+returnVals[i] , 'value':'Ind. - '+returnVals[i]});
                } 
                component.set("v.voteStatuses", voteStatuses);
            }
        });
        $A.enqueueAction(action1);
    },
    getVoteCycles : function (component, event, helper){
        
        var action = component.get("c.getVoteCycle");
        var params = {"act": "Search"}; 
        action.setParams({
                "act" : "Search"
         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("getVoteCycle From server: " + JSON.stringify(response.getReturnValue()));
                var cycleData = [{"label": "Select","value": null}];
                var storeResponse = response.getReturnValue();
                
                for(var i = 0; i < storeResponse.length; i++) {
                   		cycleData.push({"label": storeResponse[i].Name,"value": storeResponse[i].Id});
                }
                // set searchResult list with return value from server.
                console.log('storeResponse ' + storeResponse);
                console.log("getVoteCycle From server after: " + JSON.stringify(response.getReturnValue()));
                component.set("v.voteCycles", cycleData);
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    getFunction: function (component, event, helper){
        var action1 = component.get("c.getFunctions");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfFunctions = [];
                console.log("From server functionValues: " + JSON.stringify(response.getReturnValue()));
                var functionValues = response.getReturnValue();
                listOfFunctions.push({'label' :'Select' , 'value':null});
                for(var i=0;i<functionValues.length; i++){
                    listOfFunctions.push({'label' :functionValues[i] , 'value':functionValues[i]});
                } 
                component.set("v.functions", listOfFunctions);
                //component.find("fieldIdFunction").set("v.value", listOfFunctions[0].value);
            }
        });
        $A.enqueueAction(action1);
    },
    getSectors:function (component, event, helper){
        var action1 = component.get("c.getSector");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfSector = [];
                console.log("From server sector: " + JSON.stringify(response.getReturnValue()));
                var sector = response.getReturnValue();
                listOfSector.push({'label' :'Select' , 'value':null});
                for(var i=0;i<sector.length; i++){
                    listOfSector.push({'label' :sector[i] , 'value':sector[i]});
                } 
                component.set("v.sectors", listOfSector);
                //component.find("fieldIdSector").set("v.value", listOfSector[0].value);
            }
        }); 
        $A.enqueueAction(action1);
    }
    
})