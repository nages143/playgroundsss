({
    init:function (component, evt, helper){
		var userType = component.get("v.isAdminUser") + " "+
            component.get("v.isPilotUser") + " "+
            component.get("v.isClientStrategyUser");
        
        if(userType==='') {
            /*var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "You don't have any access to this page!");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "3000");
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();*/
                }
        else{
            component.set("v.canAccess",true);
            helper.getAccountLevelStatuses(component, event);
            helper.getVoteCycles(component, event, helper);
            helper.getFunction(component, event, helper);
            helper.getSectors(component, event, helper);
            helper.getSearchData(component, event, helper);
        }
        
        var exportOptions = component.get("v.exportOptions");
        component.find("exportOptions").set("v.value", exportOptions[0].value);
        var expandFiltersFlag = component.get("v.expandFiltersFlag");
        component.set("v.expandFiltersFlag", !expandFiltersFlag);
        var action = component.get("c.expandFilters");  
         $A.enqueueAction(action);
    },
    initDates:function (component, evt, helper) {
        var months=[{"label": "Select","value": "Select"},{"label": "Jan","value": "Jan"},{"label": "Feb","value": "Feb"},{"label": "Mar","value": "Mar"},
                    {"label": "Apr","value": "Apr"},{"label": "May","value": "May"},{"label": "Jun","value": "Jun"},
                    {"label": "Jul","value": "Jul"},{"label": "Aug","value": "Aug"},{"label": "Sep","value": "Sep"},
                    {"label": "Oct","value": "Oct"},{"label": "Nov","value": "Nov"},{"label": "Dec","value": "Dec"}
                   ];
        var years = [{"label": "Select","value": "Select"}];
        var startYear = parseInt($A.get("$Label.c.brokerVotePeriodStartYear"));
        var endYear = parseInt($A.get("$Label.c.brokerVotePeriodEndYear"));
        for(var index=startYear; index <= endYear; index++) {
        	var year = {"label": ""+index, "value": ""+index};
        	years.push(year);
        }
        component.set('v.months',months);
        component.set('v.years',years);
        
        component.find('scorecardMonthFromId').set('v.value', months[0].value);
        component.find('scorecardYearFromId').set('v.value', years[0].value);
        component.find('scorecardMonthToId').set('v.value', months[0].value);
        component.find('scorecardYearToId').set('v.value', years[0].value);
        
        component.set("v.clear",0);
    },
    
    handleClick: function (component, event, helper) {
        helper.getSearchData(component, event, helper);
	},
    
    handleExportReportClick: function (component, event, helper) {
        var reportType = component.find("exportOptions").get("v.value");
        if(reportType!=undefined)
        	helper.exportReport(component, event, helper,reportType);
        else{
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message",  "Please select report type!");
            appEvent.setParam("type", "error");
            appEvent.setParam("mode", "dismissible");
            appEvent.setParam("duration", "3000");
            appEvent.fire();
        }
	},
  
    handleComponentEvent : function(component, event, helper) {
       var selectedAccountGetFromEvent = event.getParam("recordByEvent");
       
        component.set("v.selectedLookUpRecord" , selectedAccountGetFromEvent); 
        component.set("v.bcNameToDisplay",selectedAccountGetFromEvent.Name +" - "+selectedAccountGetFromEvent.AccountNumber);
    },
    handleClear : function(component, event, helper) {
        component.set("v.listOfSearchRecords", []);
        component.set("v.listOfVPSearchRecords", []);
        component.set("v.lstSelectedRecords", []);
        component.set("v.lstVPSelectedRecords", []);
        
        component.set("v.voteCycleRecord", {});
        component.set("v.listOfBrokerVotes", null);
        component.set("v.fetchedData", false);
        component.set("v.bcNameToDisplay", "");
        
        component.set("v.selectedEmployeeRecord", {});
        component.set("v.selectedClientContactRecord", {});
        
        var clear = component.get("v.clear");
        component.set("v.clear", 1-clear);
        
        var months = component.get('v.months');
        var years = component.get('v.years');
              
        component.find('scorecardMonthFromId').set('v.value', months[0].value);
        component.find('scorecardYearFromId').set('v.value', years[0].value);
        component.find('scorecardMonthToId').set('v.value', months[0].value);
        component.find('scorecardYearToId').set('v.value', years[0].value);
        
        if(component.get("v.isBusinessMgmtUser") != true) {
        	var voteStatuses = component.get("v.voteStatuses");
        	component.find("voteStatusId").set("v.value", voteStatuses[0].value);
        	component.set("v.voteStatus", "");
        }
        
        var expandFiltersFlag = component.get("v.expandFiltersFlag");
        if(expandFiltersFlag) {
            
        	var voteCycles = component.get("v.voteCycles");
        	component.find("voteCycleId").set("v.value", voteCycles[0].value);
            component.set("v.voteCycleValue", "");
            
            //var tiers = component.get("v.tiers");
        	//component.find("tierId").set("v.value", tiers[0].value);
            //component.set("v.tier", "");
            
            var functions = component.get("v.functions");
        	component.find("functionId").set("v.value", functions[0].value);
            component.set("v.function", "");
            
            //var votingTeams = component.get("v.votingTeams");
        	//component.find("votingTeamId").set("v.value", votingTeams[0].value);
            //component.set("v.votingTeam", "");
            
            var sectors = component.get("v.sectors");
        	component.find("sectorId").set("v.value", sectors[0].value);
            component.set("v.sector", "");
        }
        else {
            component.set("v.voteCycleValue", "");
            component.set("v.tier", "");
            component.set("v.function", "");
            component.set("v.votingTeam", "");
            component.set("v.sector", "");
        }
        
        helper.getSearchData(component, event, helper);
        
    },
    clearVotePeriodField: function(component, event, helper) {
        component.set("v.selectedLookUpPeriodRecord",{});
    },
    clearBuyingCenterField: function(component, event, helper) {
        component.set("v.selectedLookUpRecord",{});
    },
    
    handleMonthYearChange : function(component, event, helper) {
        var sourceId;
        var targetId;
        if(event.getSource().getLocalId() === "scorecardMonthFromId"){
            sourceId = component.find('scorecardMonthFromId');	
            targetId = component.find('scorecardYearFromId');	
        }
        else if(event.getSource().getLocalId() === "scorecardYearFromId"){
            sourceId = component.find('scorecardYearFromId');	
            targetId = component.find('scorecardMonthFromId');	
        }
        else if(event.getSource().getLocalId() === "scorecardYearToId"){
            sourceId = component.find('scorecardYearToId');	
            targetId = component.find('scorecardMonthToId');	
        }
        else if(event.getSource().getLocalId() === "scorecardMonthToId"){
            sourceId = component.find('scorecardMonthToId');	
            targetId = component.find('scorecardYearToId');	
        }
        
        
        if(sourceId.get('v.value') != 'Select'){
            if(targetId.get('v.value') === 'Select'){
            	$A.util.addClass(targetId, 'dateValidation');
            }
            else{
                $A.util.removeClass(targetId, 'dateValidation');
            }
            $A.util.removeClass(sourceId, 'dateValidation');
        }
        else{
            if(targetId.get('v.value') != 'Select'){
            	$A.util.addClass(sourceId, 'dateValidation');
            }
            else{
                $A.util.removeClass(sourceId, 'dateValidation');
                $A.util.removeClass(targetId, 'dateValidation');
            }
        }
    },
    
    downloadVotes : function(component, event, helper) {
        var reportType = "BV_Vote_Vote_Details";
        helper.exportReport(component, event, helper,reportType);
    },
    expandFilters : function(component, event, helper) {
        var expandFiltersFlag = component.get("v.expandFiltersFlag");
        component.set("v.expandFiltersFlag", !expandFiltersFlag);
        var exportOptions = component.get("v.exportOptions");
        component.find("exportOptions")[0].set("v.value", exportOptions[0].value);
        component.find("exportOptions")[1].set("v.value", exportOptions[0].value);
        
        if(component.get("v.isBusinessMgmtUser") != true) {
        	component.find("voteStatusId").set("v.value", component.get("v.voteStatus"));    
        }
        
        component.find("voteCycleId").set("v.value", component.get("v.voteCycleValue"));
        component.find("tierId").set("v.value", component.get("v.tier"));
        component.find("functionId").set("v.value", component.get("v.function"));
        component.find("votingTeamId").set("v.value", component.get("v.votingTeam"));
        component.find("sectorId").set("v.value", component.get("v.sector"));
        
    },
    handleComboboxValueChange: function(component, event, helper) {
        if(event.getSource().getLocalId() === "voteStatusId"){
            var val = component.find('voteStatusId').get("v.value");
            component.set("v.voteStatus", val);
        }
        if(event.getSource().getLocalId() === "voteCycleId"){
            var val = component.find('voteCycleId').get("v.value");
            component.set("v.voteCycleValue", val);
        }
        if(event.getSource().getLocalId() === "tierId"){
            var val = component.find('tierId').get("v.value");
            component.set("v.tier", val);
        }
        if(event.getSource().getLocalId() === "functionId"){
            var val = component.find('functionId').get("v.value");
            component.set("v.function", val);
        }
        if(event.getSource().getLocalId() === "votingTeamId"){
            var val = component.find('votingTeamId').get("v.value");
            component.set("v.votingTeam", val);
        }
        if(event.getSource().getLocalId() === "sectorId"){
            var val = component.find('sectorId').get("v.value");
            component.set("v.sector", val);
        }
        
    }
    
})