({
	init : function(component, event, helper) {
        var listOfBrokerVotes = component.get("v.listOfBrokerVotes");
        var pageSize = component.get("v.pageSize");
        var totalSize = listOfBrokerVotes.length;
        
        component.set("v.totalSize", totalSize);  
        component.set("v.start",0);	
		component.set("v.end",pageSize-1);
        component.set("v.totalPages",Math.ceil( totalSize / pageSize));
        component.set("v.pageNumber",1);
        
        var paginationList = [];        
		for(var i=0; i< pageSize; i++) {
			paginationList.push(listOfBrokerVotes[i]);
		}
		component.set("v.paginationList", paginationList);
        
		console.log(paginationList);
        
    },
    first : function(component, event, helper) {
		var votesList = component.get("v.listOfBrokerVotes");
		var pageSize = component.get("v.pageSize");
		var paginationList = [];
		for(var i=0; i< pageSize; i++)
		{
			paginationList.push(votesList[i]);
		}
        component.set("v.start",0);
        component.set("v.end",pageSize-1);
        component.set("v.pageNumber",1);
		component.set("v.paginationList", paginationList);
	},

	last : function(component, event, helper) {
		var votesList = component.get("v.listOfBrokerVotes");
        var end = component.get("v.end");
		var start = component.get("v.start");
        var pageNumber = component.get("v.pageNumber");
		var pageSize = component.get("v.pageSize");
		var totalSize = component.get("v.totalSize");
		var paginationList = [];
		for(var i=totalSize-pageSize; i< totalSize; i++) {
			paginationList.push(votesList[i]);
		}
        pageNumber = Math.ceil(totalSize / pageSize);
        component.set("v.start",(pageNumber*pageSize)-pageSize-1);
        component.set("v.end",(pageNumber*pageSize)-1);
        component.set("v.pageNumber", pageNumber);
		component.set("v.paginationList", paginationList);
	},

	next : function(component, event, helper) {
		var votesList = component.get("v.listOfBrokerVotes");
		var end = component.get("v.end");
		var start = component.get("v.start");
        var pageNumber = component.get("v.pageNumber");
		var pageSize = component.get("v.pageSize");
        var paginationList = [];
		var counter = 0;
		for(var i=end+1; i<end+pageSize+1; i++) {
			if(votesList.length > end) {
				paginationList.push(votesList[i]);
				counter ++ ;
			}
		}
		start = start + counter;
		end = end + counter;
        pageNumber = pageNumber + 1;
		component.set("v.start",start);
        component.set("v.end",end);
        component.set("v.pageNumber", pageNumber);
		component.set("v.paginationList", paginationList);
	},

	previous : function(component, event, helper) {
		var votesList = component.get("v.listOfBrokerVotes");
		var end = component.get("v.end");
        var start = component.get("v.start");
        var pageNumber = component.get("v.pageNumber");
		var pageSize = component.get("v.pageSize");
		var paginationList = [];
		var counter = 0;
        for(var i= start-pageSize; i < start ; i++) {
			if(i > -1) {
				paginationList.push(votesList[i]);
				counter ++;
			}
			else {
				start++;
			}
		}
		start = start - counter;
		end = end - counter;
        pageNumber = pageNumber - 1;
		component.set("v.start",start);
		component.set("v.end",end);
        component.set("v.pageNumber",pageNumber);
		component.set("v.paginationList", paginationList);
	},
    
    handleClone: function(component, event, helper) {
        
        var brokerVoteId = event.getSource().get("v.value");
        var url = new URL(window.location.href);
        var urlString = encodeURI(url);
        var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
        window.open(redirectUrl+"/BVAddVote.app?Id="+brokerVoteId, '_parent');
    },
    
    handleDelete:  function(component, event, helper) {
        
        var voteId = event.getSource().get("v.value");
		component.set("v.voteIdToDelete", voteId);   
        
        component.set("v.showDeleteDialog", true);
          
    },
   
   
	redirectToEditPage  : function(component, event, helper) {
        
       	var ctarget = event.currentTarget;
    	var brokerVoteId = ctarget.dataset.value;
        var url = new URL(window.location.href);
        var urlString = encodeURI(url);
        var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
        var isAdminUser = component.get("v.isAdminUser");
        var isPilotUser = component.get("v.isPilotUser");
        var isClientStrategyUser = component.get("v.isClientStrategyUser");
        var isBusinessMgmtUser = component.get("v.isBusinessMgmtUser");
        if(isClientStrategyUser && !isAdminUser && !isPilotUser && !isBusinessMgmtUser){
        	window.open(redirectUrl+"/BVClientStrategy.app?Id="+brokerVoteId, '_parent');
        }
        else if(!isClientStrategyUser && !isAdminUser && !isPilotUser && isBusinessMgmtUser){
        	window.open(redirectUrl+"/BVBusinessManagement.app?Id="+brokerVoteId, '_parent');
        }
        else if(isAdminUser || isPilotUser){
        	window.open(redirectUrl+"/BVAddVote.app?editMode=true&Id="+brokerVoteId, '_parent');
        }
    },  
    
    handleDownloadReportClick: function (component, event, helper) {
        var compEvent = component.getEvent("downloadVotesEvent");
        compEvent.fire();
    },
    
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Delete Vote') {
            if(actionType === 'No') {
                helper.closeDeleteModel(component, event);
            }
            if(actionType === 'Yes') {
                helper.deleteVote(component, event);
            }
        }
         if(dialogType === 'View Flashed Email') {
            if(actionType === 'No') {
                helper.closePreviewModel(component, event);
            }
        }
    },
    openFlashPreview:function (component, event, helper) {
        
        var ctarget = event.currentTarget;
    	var brokerVoteId = ctarget.dataset.value;
        
        component.set("v.voteIdForFlashEmailPreview", brokerVoteId);
        component.set("v.showPreviewDialog", true);
    }
})