({
	closeDeleteModel: function(component, event) {
      component.set("v.showDeleteDialog", false);
   },
 
   deleteVote: function(component, event) {
      	component.set("v.showDeleteDialog", false);
     	var action = component.get("c.deleteBrokerVote");
       var voteId =component.get("v.voteIdToDelete");   
       action.setParams({
            "voteId" : voteId
        });
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                
                var success = JSON.stringify(response.getReturnValue());
                if(success) {
               		var listOfBrokerVotes = component.get("v.listOfBrokerVotes");
                	var deletedVoteIndex = listOfBrokerVotes.map(vote => { return vote.Id; }).indexOf(voteId);
             
                	listOfBrokerVotes.splice(deletedVoteIndex, 1);
                	console.log(listOfBrokerVotes);
                    //alert("Broker Vote Deleted.");
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", $A.get("$Label.c.brokerVoteDeleteSuccess"));
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();
                    
                	var callInit = component.get('c.init');
        			$A.enqueueAction(callInit);
                }
                else {
                    //alert("An unexpected error has occurred while deleting broker vote.");
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message",  $A.get("$Label.c.brokerVoteDeleteError"));
                    appEvent.setParam("type", "error");
                    appEvent.setParam("mode", "sticky");
                    appEvent.fire();
                }
            }
        });
        $A.enqueueAction(action); 
   },
    closePreviewModel: function(component, event) {
      component.set("v.showPreviewDialog", false);
   },
})