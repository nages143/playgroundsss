({
    initCloneData: function (component, event, helper) {
        var isClone=component.get("v.isClone");
        var editMode=component.get("v.editMode");
        var brokerVote = component.get("v.brokerVote");
        var mainVoteId= component.get("v.mainVoteId");
        var selectedLookUpRecord= component.get("v.selectedLookUpRecord");
        var clientStrategyScreen= component.get("v.clientStrategyScreen");
        
        if(isClone){ 
            component.set("v.bcNameToDisplay",brokerVote.BCAP_Buying_Centre__r.Name+" - "+brokerVote.BCAP_Buying_Centre__r.AccountNumber);
            if(editMode || clientStrategyScreen) {
                component.set("v.voteCycleRecord",{"Name":brokerVote.BCAP_Vote_Cycle__r.Name,
                                                   "Id": brokerVote.BCAP_Vote_Cycle__c,
                                                   "BCAP_Start_Month__c": brokerVote.BCAP_Vote_Cycle__r.BCAP_Start_Month__c});
                component.set("v.selectedLookUpPeriodRecord",{"Name":brokerVote.BCAP_Vote_Period__r.Name,
                                                              "Id": brokerVote.BCAP_Vote_Period__c,
                                                              "BCAP_Start_Month__c": brokerVote.BCAP_Vote_Period__r.BCAP_Start_Month__c,
                                                              "BCAP_End_Month__c": brokerVote.BCAP_Vote_Period__r.BCAP_End_Month__c});
                component.set("v.selectedLookUpRecord",{"Name":brokerVote.BCAP_Buying_Centre__r.Name,
                                                        "AccountNumber": brokerVote.BCAP_Buying_Centre__r.AccountNumber,
                                                        "Id": brokerVote.BCAP_Buying_Centre__c});
                if(brokerVote.BCAP_Received_Date__c!=null) {
                    var receivedDate = new Date(brokerVote.BCAP_Received_Date__c);
                    var monthDigit = receivedDate.getMonth() + 1;
                    if (monthDigit <= 9) {
                        monthDigit = '0' + monthDigit;
                    }
                    component.set('v.receivedDate', receivedDate.getFullYear() + "-" + monthDigit + "-" + receivedDate.getDate());
                }
                component.find("selectType").set("v.value",brokerVote.BCAP_Vote_Type__c);
                component.set("v.startDate",brokerVote.BCAP_Vote_Period__r.BCAP_Start_Month__c);
                component.set("v.endDate", brokerVote.BCAP_Vote_Period__r.BCAP_End_Month__c);
                component.set("v.scorecardDate", brokerVote.BCAP_Vote_Cycle__r.BCAP_Start_Month__c);
                component.find("voteCycleId").set("v.value",brokerVote.BCAP_Vote_Cycle__c);
                component.find("clientDetailsId").set("v.value",brokerVote.BCAP_Client_Details__c);
                helper.populateDates(component, event,brokerVote.BCAP_Vote_Period_Start__c,
                                     brokerVote.BCAP_Vote_Period_End__c, 
                                     brokerVote.BCAP_Scorecard_Date__c); 
                
                component.set("v.enableUpload", true);
                var buyingCenterId = component.find("buyingCenterId");
                $A.util.addClass(buyingCenterId, 'disableRow');
                helper.initDocuments(component, event);  
                helper.initAllocationMethod(component, event);
            }
            else{
                var buyingCenterId = component.find("buyingCenterId");
                $A.util.addClass(buyingCenterId, 'disableRow');
                component.set("v.documentLabel","Docs (0)");
            }
            if(clientStrategyScreen) {
                var mainVoteRowId1 = component.find("mainVoteRow1");
                $A.util.addClass(mainVoteRowId1, 'disableRow');
                var mainVoteRowId2 = component.find("mainVoteRow2");
                $A.util.addClass(mainVoteRowId2, 'disableRow');
            }
            component.set("v.parentInitialized",true);
        }
        else {
            component.set("v.isClone",false);
            component.set("v.documentLabel","Docs (0)");
        }
    },
    initType: function (component, event, helper) {
        var action = component.get("c.getBrokerVoteType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var types = [];
                var res = response.getReturnValue();
                for(var index=0; index < res.length; index++) {
                    var type = {"label": res[index], "value": res[index]};
                    types.push(type);
                    
                }
                component.set("v.type",types);
                var isClone = component.get("v.isClone");
                //if(!isClone) {
                //	component.find('selectType').set('v.value',types[0].value);
                //}
            }
        });
        $A.enqueueAction(action);
    },
    initToday: function(component, event, helper) {
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        var dateDigit  = today.getDate()
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        if (dateDigit <= 9) {
            dateDigit = '0' + dateDigit;
        }
        //component.set('v.receivedDate', today.getFullYear() + "-" + monthDigit + "-" + dateDigit);
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + dateDigit);
    },
    
    initDates: function(component, event, helper) {
        var months=[{"label": "Jan","value": "Jan"},{"label": "Feb","value": "Feb"},{"label": "Mar","value": "Mar"},
                    {"label": "Apr","value": "Apr"},{"label": "May","value": "May"},{"label": "Jun","value": "Jun"},
                    {"label": "Jul","value": "Jul"},{"label": "Aug","value": "Aug"},{"label": "Sep","value": "Sep"},
                    {"label": "Oct","value": "Oct"},{"label": "Nov","value": "Nov"},{"label": "Dec","value": "Dec"}
                   ];
        var years = [];
        var today = new Date(component.get("v.today"));
        var startYr = parseInt($A.get("$Label.c.brokerVotePeriodStartYear"));
        var endYr = parseInt(today.getFullYear());
        for(var index=startYr; index <= endYr; index++) {
            var year = {"label": ""+index, "value": ""+index};
            years.push(year);
        }
        component.set('v.months',months);
        component.set('v.years',years);
        
        component.find('startMonth').set('v.options',months);
        component.find('startYear').set('v.options',years);
        component.find('endMonth').set('v.options',months);
        component.find('endYear').set('v.options',years);
        component.find('scorecardMonth').set('v.options',months);
        component.find('scorecardYear').set('v.options',years);
        
        //component.find('startMonth').set('v.value',months[0].value);
        //component.find('startYear').set('v.value',years[0].value);
        //component.find('endMonth').set('v.value',months[0].value);
        //component.find('endYear').set('v.value',years[0].value);
        component.find('scorecardMonth').set('v.value',months[today.getMonth()].value);
        component.find('scorecardYear').set('v.value',today.getFullYear().toString());
        
    },
    
    handleComponentEvent : function(component, event, helper) {
        var period = event.getParam("recordByEvent");
       // var cycle = event.getParam("voteCycle");
        var startDate = event.getParam("startDate");
        var endDate = event.getParam("endDate");
      //  var scorecardDate = event.getParam("scorecardDate");
        
        component.set("v.selectedRecord" , period); 
        component.set("v.startDate",startDate);
        component.set("v.endDate",endDate);
       // component.set("v.scorecardDate",scorecardDate);
        //helper.populateDates(component, event, period.BCAP_Start_Date__c, period.BCAP_End_Date__c, cycle.BCAP_Start_Date__c); 
    },
    handleComponentEvent2 : function(component, event, helper) {
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        
        component.set("v.selectedRecord" , selectedAccountGetFromEvent); 
        component.set("v.bcNameToDisplay",selectedAccountGetFromEvent.Name +" - "+selectedAccountGetFromEvent.AccountNumber);
    },
    
    handleClick: function (component, event, helper) {
        
        var isValid = helper.validateFields(component, event);
        
        if(isValid) {
            var buyingCenter = component.get("v.selectedLookUpRecord");
            var votePeriod = component.get("v.selectedLookUpPeriodRecord");
            var action = component.get("c.duplicateBVCheck");
            
            var voteCycle = component.find('voteCycleId').get('v.value');
            
            console.log('voteCycle on Save - '+ voteCycle);
            
            action.setParams({
                "buyingCenter": buyingCenter.Id,
                "votePeriod": votePeriod.Id,
                "voteId":component.get("v.mainVoteId")
            });
            
            var duplicateCheckPromise = helper.duplicateBVCheck(component, action);
            
            var voteToSave = helper.formatJSON(component,event);
            
            //console.log(component.get("v.voteToSave"));
            duplicateCheckPromise.then($A.getCallback(function() {
                helper.saveBrokerVoteData(component, event, voteToSave);
            }));
            
        } 
    },
    
    clearVotePeriodFields: function(component, event, helper) {
        component.set("v.selectedLookUpPeriodRecord",null)
        component.set("v.startDate","");
        component.set("v.endDate","");
        component.set("v.scorecardDate","");  
        
        var months = component.get('v.months');
        var years = component.get('v.years');
        /*component.find('startMonth').set('v.value',months[0].value);
       component.find('startYear').set('v.value',years[0].value);
       component.find('endMonth').set('v.value',months[0].value);
       component.find('endYear').set('v.value',years[0].value);
       component.find('scorecardMonth').set('v.value',months[0].value);
       component.find('scorecardYear').set('v.value',years[0].value);*/
        
    },
    clearBuyingCenterField: function(component, event, helper) {
        component.set("v.bcNameToDisplay", "");
    },
    
    handleUpload  : function(component, event, helper) {      
        var brokerVoteId = component.get("v.mainVoteId");
        window.open($A.get("$Label.c.brokerVoteDocumentUploadURL")+brokerVoteId,
                    '_blank');
    },  
    handleDeleteDocument: function(component, event, helper) {      
        
        component.set("v.showDeleteDialog", false);
        var action = component.get("c.deleteDocument");
        var fileId = event.getSource().get("v.value");
        action.setParams({
            "fileId" : fileId
        });
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                
                var success = response.getReturnValue();
                if(success) {
                    helper.initDocuments(component,event);
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", $A.get("$Label.c.brokerVoteDocumentDeleteSuccess"));
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();
                }
                else {
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message",  $A.get("$Label.c.brokerVoteDocumentDeleteError"));
                    appEvent.setParam("type", "error");
                    appEvent.setParam("mode", "sticky");
                    appEvent.fire();
                }
            }
        });
        $A.enqueueAction(action); 
        
        
    },
    handleViewDocument: function(component, event, helper) {      
        var fileId =  event.getSource().get("v.value");
        if(fileId !== "") {
            var url = $A.get("$Label.c.PSGetActiveStoreURI") + fileId;
            var win = window.open(url, '_blank');
        }
        
    },
    
    handleMonthChange: function(component, event, helper){
        var selectedStartMonth = event.getParam("value");
        var today = new Date(component.get("v.receivedDate"));
        var months = component.get("v.months");
        var disableCurrentYear = false;
        for(var index=0; index<12;index++) {
            var m = months[index];
            if(m.value === selectedStartMonth) {
                if(today.getMonth() < index ){
                    disableCurrentYear = true;
                    break;
                }
            }
        }
        var years = [];
        var startYr = parseInt($A.get("$Label.c.brokerVotePeriodStartYear"));
        if(disableCurrentYear) {
            var endYr = parseInt(today.getFullYear())-1;
        }
        else{
            var endYr = parseInt(today.getFullYear());
        }
        for(var index=startYr; index <= endYr; index++) {
            var year = {"label": ""+index, "value": ""+index};
            years.push(year);
        }
        if(event.getSource().getLocalId() === "startMonth")
            component.find('startYear').set('v.options',years);
        else if(event.getSource().getLocalId() === "endMonth")
            component.find('endYear').set('v.options',years);
            else if(event.getSource().getLocalId() === "scorecardMonth")
                component.find('scorecardYear').set('v.options',years);
    },
    
    initVoteCycle: function(component, event, helper){
        helper.getVoteCycle(component, event, helper);
    },
    showAllocMethodDialog:function(component, event, helper){
        component.set("v.showAllocMethodDialog", true);
    },
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Allocation Method') {
            if(actionType === 'No') {
                helper.closeModel(component, event);
            }
            if(actionType === 'Yes') {
                helper.updateAllocationMethod(component, event);
            }
        }
        if(dialogType === 'Allocation Method Read Only') {
            if(actionType === 'No') {
                helper.closeModel(component, event);
            }
        }
    }
})