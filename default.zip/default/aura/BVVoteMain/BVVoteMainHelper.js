({
    duplicateBVCheck : function(component, action, callback) {
        return new Promise(function(resolve, reject) {
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    if(response.getReturnValue()) {
                        
                        var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                        appEvent.setParam("message", $A.get("$Label.c.brokerVoteDuplicate"));
                        appEvent.setParam("type", "error");
                        appEvent.setParam("duration", "5000");
                        appEvent.setParam("mode", "dismissible");
                        appEvent.fire();
                        component.set("v.isDuplicate", true);
                        
                    }
                    else {
                        component.set("v.isDuplicate", false);
                    }
                    resolve(response.getReturnValue());
                }
                else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            reject(Error("Error message: " + errors[0].message));
                        }
                    }
                    else {
                        reject(Error("Unknown error"));
                    }
                }
            });
            $A.enqueueAction(action);
        });
    },
    
    saveBrokerVoteData : function(component, event, voteToSave) {
       
        var isDuplicate = component.get("v.isDuplicate");
        if(!isDuplicate) {
            component.set("v.showLoadingSpinner",true);
            var saveAction = component.get("c.saveBrokerVoteDataWithJSON");
            saveAction.setParams({
                'params': JSON.stringify(voteToSave)
            });
            console.log(voteToSave);
            saveAction.setCallback(this, function(response) {
                component.set("v.showLoadingSpinner",false);
                var state = response.getState();
                if (state === "SUCCESS") {
                    //alert('Broker Vote saved');
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    var brokerVoteId = response.getReturnValue();
                    if(!response.getReturnValue().includes("Error")){
                        
                        var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                        appEvent.setParam("message", $A.get("$Label.c.brokerVoteSaveSuccess"));
                        appEvent.setParam("type", "success");
                        appEvent.setParam("duration", "3000");
                        appEvent.setParam("mode", "dismissible");
                        appEvent.fire();
                        
                        component.set("v.mainVoteId", brokerVoteId);
                        component.set("v.isVoteSaved", true);
                        component.set("v.enableUpload", true);
                        
                        var url = new URL(window.location.href);
                        var urlString = encodeURI(url);
                        var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
                        var voteId = url.searchParams.get("Id");
                        var editMode= url.searchParams.get("editMode");
                        
                        if(editMode == null) {
                            window.open(redirectUrl+"/BVAddVote.app?editMode=true&Id="+brokerVoteId, '_parent');
                        }
                        else{
                          //  var mainVoteEvent = component.getEvent("oMainVoteSaveEvent");
                           // mainVoteEvent.setParams({"mainVoteId":brokerVoteId,
                         //                            "isVoteSaved":true
                          //                          });
                          //  mainVoteEvent.fire();
                        }
                    }
                    else {
                        
                        var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                        appEvent.setParam("message", $A.get("$Label.c.brokerVoteSaveError"));
                        appEvent.setParam("type", "error");
                        appEvent.setParam("duration", "3000");
                        appEvent.setParam("mode", "dismissible");
                        appEvent.fire();
                    }
                }                                
            });
            $A.enqueueAction(saveAction);
        }
    },
    populateDates: function(component, event, startDate, endDate, scorecardDate) {
        
        var months = component.get('v.months');
        if(startDate != null) {
            var periodStartDate = new Date(startDate);
            var monthDigit = periodStartDate.getMonth();
            component.find('startMonth').set('v.value',months[monthDigit].value);
            component.find('startYear').set('v.value',""+periodStartDate.getFullYear());
        }
        if(endDate != null) {
            var periodEndDate = new Date(endDate);
            monthDigit = periodEndDate.getMonth();
            component.find('endMonth').set('v.value',months[monthDigit].value);
            component.find('endYear').set('v.value',""+periodEndDate.getFullYear());
        }
        if(scorecardDate != null) {
            var scorecardDt = new Date(scorecardDate);
            monthDigit = scorecardDt.getMonth();
            component.find('scorecardMonth').set('v.value',months[monthDigit].value);
            component.find('scorecardYear').set('v.value',""+scorecardDt.getFullYear());
        }
    },
    
    validateFields: function(component, event) {
        var isValid = false;
        var errorField = "";
        if(component.get("v.selectedLookUpRecord") != null) {
            if(component.find("ReceivedOnDateId").get('v.value') !=null){
                if(component.find("selectType").get('v.value')  != null) {
                    if(component.get("v.selectedLookUpPeriodRecord") != null){
                        if(component.find("startMonth").get('v.value')  != null &&component.find("startYear").get('v.value')  != null ){
                            if(component.find("endMonth").get('v.value')  != null &&component.find("endYear").get('v.value')  != null ){
                                if(component.find("scorecardMonth").get('v.value')  != null &&component.find("scorecardYear").get('v.value')  != null ){
                                    if(component.find('voteCycleId').get('v.value')  != null &&component.find('voteCycleId').get('v.value') != 'undefined' &&component.find('voteCycleId').get('v.value') != 'Select' ) {
                                    	isValid = true;
                                    }else { isValid = false; errorField="Vote Cycle";}
                                }else { isValid = false; errorField="Scorecard-Month or Scorecard-Year";}
                            }else { isValid = false; errorField="End-Month or End-Year";}   
                        }else { isValid = false; errorField="Start-Month or Start-Year";}
                    }else { isValid = false; errorField="Vote Period";}
                }else { isValid = false; errorField="Type";}
            }else { isValid = false; errorField="Received On";}
        }else { isValid = false; errorField="Buying Centre";}
        
        if(!isValid) {
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message", 'Please fill mandatory fields: '+errorField);
            appEvent.setParam("type", "error");
            appEvent.setParam("duration", "3000");
            appEvent.setParam("mode", "dismissible");
            appEvent.fire();
        }
        return isValid;
    },
    
    formatJSON: function(component, event) { 
        var buyingCenter = component.get("v.selectedLookUpRecord");
        var votePeriod = component.get("v.selectedLookUpPeriodRecord");
        var receivedOn = component.find("ReceivedOnDateId").get("v.value");
        var selectType = component.find('selectType').get('v.value');
        var voteCycleRecord = component.find('voteCycleId').get('v.value');
        var clientDetails = component.find('clientDetailsId').get('v.value');
        
        var startMonth = component.find('startMonth').get('v.value');
        var startYear = component.find('startYear').get('v.value');
        var endMonth = component.find('endMonth').get('v.value');
        var endYear = component.find('endYear').get('v.value');
        var scorecardMonth = component.find('scorecardMonth').get('v.value');
        var scorecardYear = component.find('scorecardYear').get('v.value');
        
        var months = {"Jan":'01',"Feb":'02',"Mar":'03',"Apr":'04',"May":'05',"Jun":'06',"Jul":'07',
                      "Aug":'08',"Sep":'09',"Oct":'10',"Nov":'11',"Dec":'12'};
        var daysOfMonth = {"Jan":31,"Feb":28,"Mar":31,"Apr":30,"May":31,"Jun":30,"Jul":31,
                           "Aug":31,"Sep":30,"Oct":31,"Nov":30,"Dec":31};
        if((endYear % 100 === 0) ? (endYear % 400 === 0) : (endYear % 4 === 0)) {
            daysOfMonth["feb"] = 29;
        }
        var startDate = startYear + "-" + months[startMonth] + "-" + "01";
        var endDate = endYear + "-" + months[endMonth]  + "-" + daysOfMonth[endMonth];
        var scorecardDate =scorecardYear+ "-" + months[scorecardMonth]+ "-" + "01";
        if(!component.get("v.isClone"))
            var mainVoteId = component.get("v.mainVoteId");
        
        if(component.get("v.editMode"))
            var mainVoteId = component.get("v.mainVoteId");
        
        var url = new URL(window.location.href);
        var voteId = url.searchParams.get("Id");
        var editMode= url.searchParams.get("editMode");
        
        if(editMode == null && voteId == null) {
        	var voteToSave = {'BCAP_Vote_Type__c':selectType,
                          'BCAP_Buying_Centre__c': buyingCenter.Id,
                          'BCAP_Vote_Period__c': votePeriod.Id,
                          'BCAP_Vote_Cycle__c': voteCycleRecord,
                          'BCAP_Received_Date__c':receivedOn,
                          'BCAP_Vote_Period_Start__c': startDate,
                          'BCAP_Vote_Period_End__c': endDate,
                          'BCAP_Scorecard_Date__c':scorecardDate,
                          'BCAP_Client_Details__c':clientDetails
                          };    
        }
        else{
            var voteToSave = {'BCAP_Vote_Type__c':selectType,
                          'BCAP_Buying_Centre__c': buyingCenter.Id,
                          'BCAP_Vote_Period__c': votePeriod.Id,
                          'BCAP_Vote_Cycle__c': voteCycleRecord,
                          'BCAP_Received_Date__c':receivedOn,
                          'BCAP_Vote_Period_Start__c': startDate,
                          'BCAP_Vote_Period_End__c': endDate,
                          'BCAP_Scorecard_Date__c':scorecardDate,
                          'BCAP_Client_Details__c':clientDetails,
                          'Id': mainVoteId
                         };
        }
        
        var votes = [];
        votes.push(voteToSave)
        component.set("v.voteToSave", votes[0]);
        return {"vote": voteToSave};
    },
    initDocuments: function(component, event) {
        var voteId = component.get("v.mainVoteId");
        if(voteId != null) {
            var action = component.get("c.getDocuments"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                var result = response.getReturnValue();
                component.set("v.listOfDocuments", result);
                component.set("v.totalDocuments", result.length);
                component.set("v.documentLabel","Docs ("+result.length+")");
                component.set("v.documentViewUrl",$A.get("$Label.c.brokerVoteGetActiveStoreURI"));
            });
            $A.enqueueAction(action);
        }
    },
    initAllocationMethod: function(component, event) {
        var voteId = component.get("v.mainVoteId");
        if(voteId != null) {
            var action = component.get("c.getAllocationMethod"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                var result = JSON.parse(response.getReturnValue());
                component.set("v.allocationMethods", result.allocationMethods);
                
                component.set("v.allocationMethodsWithLists", JSON.parse(JSON.stringify(component.get("v.allocationMethods"))));
                var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
                if(allocationMethodsWithLists != undefined) {
                    for(var index=0; index < allocationMethodsWithLists.length; index++) {
                        var rules = allocationMethodsWithLists[index].BCAP_Rule__c.split("\n");
                        var scores = allocationMethodsWithLists[index].BCAP_Score__c.split("\n");
                        var data = [];
                        for(var i=0;i<rules.length;i++) {
                            var row = {'Rule': rules[i], 'Score': scores[i]};
                            data.push(row);
                        }
                        allocationMethodsWithLists[index].Rule_Score_List = data;
                    }
                    component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
                    component.set("v.previousAllocationMethods", JSON.parse(JSON.stringify(allocationMethodsWithLists)));
                }
            });
            $A.enqueueAction(action);
        }
    },
    getVoteCycle: function(component, event) {
        var action = component.get("c.getVoteCycle");
        
        // Create a callback that is executed after 
        // the server-side action returns
         var params = {"act": "Add"}; 
        
        action.setParams({
            'params': JSON.stringify(params)
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("getVoteCycle From server: " + JSON.stringify(response.getReturnValue()));
                //var cycleData = [{"label": "Select","value": "Select"}];
                var storeResponse = response.getReturnValue();
                for(var i = 0; i < storeResponse.length; i++) {
                    storeResponse[i].label = storeResponse[i].Name;
                    storeResponse[i].value = storeResponse[i].Id;
                    //cycleData.push(storeResponse[i]);
                }
                // set searchResult list with return value from server.
                console.log('storeResponse ' + storeResponse);
                console.log("getVoteCycle From server after: " + JSON.stringify(response.getReturnValue()));
                component.set("v.voteCycle", storeResponse);
                
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    updateAllocationMethod:function(component, event){
        
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        for(var index=0; index < allocationMethodsWithLists.length; index++) {
            var allocMethodList = allocationMethodsWithLists[index].Rule_Score_List;
            var rule = '';
            var score = '';
            for(var j=0;j<allocMethodList.length; j++) {
             	rule = rule + allocMethodList[j].Rule;
                score = score + allocMethodList[j].Score;
                if(j < allocMethodList.length-1) {
                    rule = rule + '\n';
                    score = score + '\n';
                }
            }
            allocationMethodsWithLists[index].BCAP_Rule__c = rule;
            allocationMethodsWithLists[index].BCAP_Score__c = score;
        }
       	component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
        component.set("v.allocationMethods", JSON.parse(JSON.stringify(component.get("v.allocationMethodsWithLists"))));
        
        var allocationMethods = component.get("v.allocationMethods");
        for(var index=0; index < allocationMethods.length; index++) {   
            if(allocationMethods[index].Rule_Score_List) {
                delete allocationMethods[index].Rule_Score_List;
            }
        }
        var params = '{"allocationMethods":'+JSON.stringify(allocationMethods)+'}';
        var action = component.get("c.saveAllocationMethod");
        action.setParams({
            "params": params
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                /*var previousAllocationMethods = [];
                for(var i=0;i<allocationMethodsWithLists.length;i++) {
                    previousAllocationMethods.push({"BCAP_Function__c": allocationMethodsWithLists[i].BCAP_Function__c,
                                                    "BCAP_Region__c": allocationMethodsWithLists[i].BCAP_Region__c,
                                                    "BCAP_Rule__c": allocationMethodsWithLists[i].BCAP_Rule__c,
                                                    "BCAP_Score__c":allocationMethodsWithLists[i].BCAP_Score__c,
                                                    "BCAP_Vote__c":allocationMethodsWithLists[i].BCAP_Vote__c,
                                                    "BCAP_Is_Deleted__c":allocationMethodsWithLists[i].BCAP_Is_Deleted__c,
                                                    "Rule_Score_List":allocationMethodsWithLists[i].Rule_Score_List
                                                   });
                }*/
                component.set("v.previousAllocationMethods",JSON.parse(JSON.stringify(component.get("v.allocationMethodsWithLists"))));
                component.set("v.showAllocMethodDialog", false);
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Allocation method updated!");
                appEvent.setParam("type", "success");
                appEvent.setParam("duration", "3000");
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    closeModel:function(component, event, helper){
        var previousAllocationMethods = component.get("v.previousAllocationMethods");
        /*var allocationMethodsWithLists = [];
        for(var i=0;i<previousAllocationMethods.length;i++) {
            allocationMethodsWithLists.push({"BCAP_Function__c": previousAllocationMethods[i].BCAP_Function__c,
                                             "BCAP_Region__c": previousAllocationMethods[i].BCAP_Region__c,
                                             "BCAP_Rule__c": previousAllocationMethods[i].BCAP_Rule__c,
                                             "BCAP_Score__c":previousAllocationMethods[i].BCAP_Score__c,
                                             "BCAP_Vote__c":previousAllocationMethods[i].BCAP_Vote__c,
                                             "BCAP_Is_Deleted__c":previousAllocationMethods[i].BCAP_Is_Deleted__c,
                                             "Rule_Score_List":previousAllocationMethods[i].Rule_Score_List});
        }*/
        component.set("v.allocationMethodsWithLists",JSON.parse(JSON.stringify(component.get("v.previousAllocationMethods"))));
        component.set("v.showAllocMethodDialog", false);
        
    }
})