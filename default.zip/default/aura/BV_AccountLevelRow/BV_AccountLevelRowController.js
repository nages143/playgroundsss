({
    customInit : function(cmp, event, helper){
        //var subRows = JSON.parse(JSON.stringify(cmp.get("v.individualLevelRecords")));
        //cmp.set("v.individualLevelRecords",subRows);
        var listOfRegion = [];
        var action1 = cmp.get("c.getRegion");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server region: " + JSON.stringify(response.getReturnValue()));
                var regions = response.getReturnValue();
                listOfRegion.push({'label' :'Select' , 'value':null});
                for(var i=0;i<regions.length; i++){
                    listOfRegion.push({'label' :regions[i] , 'value':regions[i]});
                } 
                cmp.set("v.region", listOfRegion);
                var region2 = cmp.get("v.region");
                console.log("region");
                console.log(region2);
                
            }  
        }); 
        var action2 = cmp.get("c.getClientRegion");
        action2.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var listOfRegion = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue())); 
                var regions = response.getReturnValue();
                listOfRegion.push({'label' :'Select' , 'value':null});
                for(var i=0;i<regions.length; i++){
                    listOfRegion.push({'label' :regions[i] , 'value':regions[i]});
                } 
                cmp.set("v.clientRegion", listOfRegion);
                console.log("clientRegion"+ cmp.get("v.clientRegion"));
                
            }
        });
        
        
        var action3 = cmp.get("c.getAssetClass");
        action3.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var assetClassList = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue())); 
                var assetClass = response.getReturnValue();
                assetClassList.push({'label' :'Select' , 'value':null});
                for(var i=0;i<assetClass.length; i++){
                    assetClassList.push({'label' :assetClass[i] , 'value':assetClass[i]});
                } 
                cmp.set("v.assetClass", assetClassList);
                console.log("assetClass"+ cmp.get("v.assetClass"));
            }
        });
        
        var action4 = cmp.get("c.getIndividualRowTypes");
        action4.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var tableOptions = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var options = response.getReturnValue();
                tableOptions.push({'label' :'Select' , 'value':null});
                for(var i=0;i<options.length; i++){
                    tableOptions.push({'label' :options[i] , 'value':options[i]});
                } 
                cmp.set("v.tableOptions", tableOptions);
                console.log("Table options"+ cmp.get("v.tableOptions"));
            }
        });
        
        var action5 = cmp.get("c.getRank");
        action5.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfRank = [];
                console.log("From server region: " + JSON.stringify(response.getReturnValue()));
                var ranks = response.getReturnValue();
                listOfRank.push({'label' :'Select' , 'value':null});
                for(var i=0;i<ranks.length; i++){
                    listOfRank.push({'label' :ranks[i] , 'value':ranks[i]});
                } 
                cmp.set("v.rank", listOfRank);
                var region2 = cmp.get("v.rank");
            }
        }); 
        
        var action6 = cmp.get("c.getRelativeRank");
        action6.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfDataRelativeRank = [];
                console.log("From server region: " + JSON.stringify(response.getReturnValue()));
                var dataRelativeRank = response.getReturnValue();
                listOfDataRelativeRank.push({'label' :'Select' , 'value':null});
                for(var i=0;i<dataRelativeRank.length; i++){
                    listOfDataRelativeRank.push({'label' :dataRelativeRank[i] , 'value':dataRelativeRank[i]});
                } 
                cmp.set("v.dataRelativeRank", listOfDataRelativeRank);
            }
        });	
        
        var action7 = cmp.get("c.getContentRank");
        action7.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfRankR = [];
                console.log("From server region: " + JSON.stringify(response.getReturnValue()));
                var rankr = response.getReturnValue();
                listOfRankR.push({'label' :'Select' , 'value':null});
                for(var i=0;i<rankr.length; i++){
                    listOfRankR.push({'label' :rankr[i] , 'value':rankr[i]});
                } 
                cmp.set("v.contentRank", listOfRankR);
            }
        });	
        
        var action8 = cmp.get("c.getServices");
        action8.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var serviceList = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue())); 
                var service = response.getReturnValue();
                serviceList.push({'label' :'Select' , 'value':null});
                for(var i=0;i<service.length; i++){
                    serviceList.push({'label' :service[i] , 'value':service[i]});
                } 
                cmp.set("v.service", serviceList);
                console.log("service"+ cmp.get("v.service"));
            }
        });   
        
        
        var action9 = cmp.get("c.getVotingTeamTierOptions");
        action9.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var votingTeamTierOptions = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var options = response.getReturnValue();
                votingTeamTierOptions.push({'label' :'Select' , 'value':null});
                for(var i=0;i<options.length; i++){
                    votingTeamTierOptions.push({'label' :options[i] , 'value':options[i]});
                } 
                cmp.set("v.votingTeamTierOptions", votingTeamTierOptions);
                console.log("voting Team Tier Options"+ cmp.get("v.votingTeamTierOptions"));
            }
        });
        var action10 = cmp.get("c.getResearchFlags");
        action10.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var researchFlags = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var options = response.getReturnValue();
                researchFlags.push({'label' :'Select' , 'value':null});
                for(var i=0;i<options.length; i++){
                    researchFlags.push({'label' :options[i] , 'value':options[i]});
                } 
                cmp.set("v.researchFlags", researchFlags);
                console.log("researchFlag Options"+ cmp.get("v.researchFlags"));
            }
        });
        var action11 = cmp.get("c.getOverallRankFlags");
        action11.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var overallRankFlags = []; 
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var options = response.getReturnValue();
                overallRankFlags.push({'label' :'Select' , 'value':null});
                for(var i=0;i<options.length; i++){
                    overallRankFlags.push({'label' :options[i] , 'value':options[i]});
                } 
                cmp.set("v.overallRankFlags", overallRankFlags);
                console.log("overallRankFlags Options"+ cmp.get("v.overallRankFlags"));
            }
        });
        
        $A.enqueueAction(action1);
        $A.enqueueAction(action2);
        $A.enqueueAction(action3);
        $A.enqueueAction(action4);
        $A.enqueueAction(action5);
        $A.enqueueAction(action6);
        $A.enqueueAction(action7);
        $A.enqueueAction(action8); 
        $A.enqueueAction(action9);
        $A.enqueueAction(action10);
        $A.enqueueAction(action11);
        
        /*var row = {};
        var individualLevelRecords = JSON.parse(JSON.stringify(cmp.get("v.individualLevelRecords")));
        var getIdPromise = helper.getExternalId(cmp);
        row.type = cmp.get("v.tableType");
        row.Parent_External_Id = cmp.get("v.Parent_External_Id");
        row.BCAP_Is_Deleted__c = false;
        getIdPromise.then(function(id){
           row.BCAP_External_ID__c = id; 
           individualLevelRecords.push(row);
           cmp.set("v.individualLevelRecords", individualLevelRecords);
        });*/
        
        /*     var account = JSON.parse(JSON.stringify(cmp.get("v.accountRecord")));
        cmp.set("v.selectedRegionLookUpRecord", account.BCAP_Client_Region__r);
        cmp.set("v.selectedAssetClassLookUpRecord", account.BCAP_Client_Asset_Class__r);
        cmp.set("v.selectedServiceLookUpRecord", account.BCAP_Client_Service__r);
  */                    
        var account = JSON.parse(JSON.stringify(cmp.get("v.accountRecord")));
        if(account.BCAP_Individual_Level__c == null || account.BCAP_Individual_Level__c == undefined){
            account.BCAP_Individual_Level__c = 'N';
            cmp.set("v.accountRecord", account);
        } 
        cmp.set("v.previousContentRankValue",account.BCAP_Content_Rank__c);
        console.log(account);
        
        var hasDataValues = false;
        if(account.BCAP_Data_AUM__c !== '' && account.BCAP_Data_AUM__c !== undefined && account.BCAP_Data_AUM__c !== null){
            hasDataValues = true;
        }
        else if(account.BCAP_Data_Wallet__c !== '' && account.BCAP_Data_Wallet__c !== undefined && account.BCAP_Data_Wallet__c !== null){
            hasDataValues = true;
        }
        else if(account.BCAP_Data_Payment__c !== '' && account.BCAP_Data_Payment__c !== undefined && account.BCAP_Data_Payment__c !== null){
            hasDataValues = true;
        }
        else if(account.BCAP_Data_Tier__c !== '' && account.BCAP_Data_Tier__c !== undefined && account.BCAP_Data_Tier__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Rank__c !== '' && account.BCAP_Data_Rank__c !== undefined && account.BCAP_Data_Rank__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Points__c !== '' && account.BCAP_Data_Points__c !== undefined && account.BCAP_Data_Points__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Market_Share__c !== '' && account.BCAP_Data_Market_Share__c !== undefined && account.BCAP_Data_Market_Share__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Wallet__c !== '' && account.BCAP_Data_Wallet__c !== undefined && account.BCAP_Data_Wallet__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Payment__c !== '' && account.BCAP_Data_Payment__c !== undefined && account.BCAP_Data_Payment__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Relative_Rank__c !== '' && account.BCAP_Data_Relative_Rank__c !== undefined && account.BCAP_Data_Relative_Rank__c !== null){
            hasDataValues = true;
         }
         else if(account.BCAP_Data_Grade__c !== '' && account.BCAP_Data_Grade__c !== undefined && account.BCAP_Data_Grade__c !== null){
            hasDataValues = true;
         }
         else{
            hasDataValues =false;
         }
        cmp.set("v.haveDataValues",hasDataValues);
        if(account.BCAP_Individual_Level_Basis__c !==null) {
            cmp.set("v.previousIndividualType", account.BCAP_Individual_Level_Basis__c);
        }
        
        var isSubmittedToCS = cmp.get("v.accountRecord.BCAP_Is_Submitted_to_CS__c");
        if(isSubmittedToCS) {
            var td;
            td = cmp.find("tdAccIdClone");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDelete");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdClientRegion");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdRegion");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdClientAssetClass");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdAssetClass");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdClientService");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdService");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdVotingTeam");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdVotingTeamTier");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdCurrency");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdOppAUM");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdOppWallet");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdOppPayment");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataTier");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataRank");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataPoints");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataMarketShare");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataWallet");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataPayment");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataRelativeRank");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataGrade");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdDataNotes");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdResearchFlag");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdTargetRank");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdRank");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdContentRank");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdVoteLevelNotes");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdIndLevelDetail");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdTypeOfIndLevel");$A.util.addClass(td, 'lock-account');
            td = cmp.find("tdAccIdInterpretationNotes");$A.util.addClass(td, 'lock-account');
        }
    },
    
    handleClick: function(component, event, helper){
        helper.handleChevronChange(component);
    },
    
    addIndividualRow: function(component, event, helper){
        var subRows = component.get("v.individualLevelRecords");
        var row = event.getParam("row");
        subRows.push(row);
        component.set("v.individualLevelRecords",subRows);
    },
    
    deleteIndividualRow : function(component, event, helper){
        var subRows = component.get("v.individualLevelRecords");
        var index = event.getSource().get("v.rowIndex");
        subRows[index].BCAP_Is_Deleted__c = true;
       	if(subRows[index].Id == undefined) 
        	subRows.splice(index, 1);
        component.set("v.individualLevelRecords",subRows);
    },
    
    addRow : function(component, event, helper) {
        var buttonIdentifier = event.getSource().getLocalId();
        helper.addAccountRow(buttonIdentifier, component, event);
    },
    
    deleteRow : function(component, event, helper){
        var index = component.get("v.accRowIndex");
        var appEvent = component.getEvent("deleteAccountLevelRow");
        appEvent.fire();
    },
    
    handleChildTableChange : function(component, event, helper){
        var inputCmpRowType = component.find("fieldIdIndividualRowType");
        var inputCmpNotes = component.find("fieldIdNotes");
        var notes = component.get("v.accountRecord.BCAP_Interpretation_Notes__c");
        var child = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
        var selectedOptionValue = event.getParam("value");
        var BCAP_External_ID__c = component.get("v.BCAP_External_ID__c");
        var subRows = component.get("v.individualLevelRecords");
        var matchFound = false;
        var haveRecords = false;
        
        //validation check
        if(selectedOptionValue != null){
            inputCmpRowType.setCustomValidity(""); 
            inputCmpRowType.reportValidity();
            if(helper.isEmpty(notes)){
                inputCmpNotes.setCustomValidity(" "); 
                inputCmpNotes.reportValidity();
            }
            if(!helper.isEmpty(notes)){
                inputCmpNotes.setCustomValidity(""); 
                inputCmpNotes.reportValidity();
            }
        }
        else if(selectedOptionValue == null){
            inputCmpRowType.setCustomValidity(" "); 
            inputCmpRowType.reportValidity();
        }
        
        for(var i=0; i<subRows.length; i++){
            if(subRows[i].Parent_External_Id == BCAP_External_ID__c) {
                haveRecords = true;
            }
            if(subRows[i].Parent_External_Id == BCAP_External_ID__c && subRows[i].type == component.get("v.accountRecord.BCAP_Individual_Level_Basis__c")){
                matchFound = true;
            }
        }
        var previousIndividualType = component.get("v.previousIndividualType");
        if(haveRecords) {
            for(var i=0; i<subRows.length; i++){
                subRows[i].type = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
            }
            component.set("v.individualLevelRecords", subRows);
        }
        if(!haveRecords){
            var row = {};
            var getIdPromise = helper.getExternalId(component);
            
            //row.BCAP_External_ID__c = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c") + "0";
            row.type = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
            row.Parent_External_Id = component.get("v.BCAP_External_ID__c");
            row.BCAP_Is_Deleted__c = false;
            getIdPromise.then(function(id){
                row.BCAP_External_ID__c = id; 
                subRows.push(row);
                component.set("v.individualLevelRecords", subRows);
            });
        }
        component.set("v.previousIndividualType", component.get("v.accountRecord.BCAP_Individual_Level_Basis__c"));
    },
    
    handleChildPresence : function(component, event, helper){
        var inputCmp = component.find("fieldIdHasIndividualRows");
        var inputCmpRowType = component.find("fieldIdIndividualRowType");
        var inputCmpNotes = component.find("fieldIdNotes");
        var notes = component.get("v.accountRecord.BCAP_Interpretation_Notes__c");
        var selectedOptionValue = event.getParam("value");
        var subRows = JSON.parse(JSON.stringify(component.get("v.individualLevelRecords")));
        if(selectedOptionValue == 'N'){
            //for validation
            component.set("v.accountRecord.BCAP_Individual_Level_Basis__c", null);
            inputCmpRowType.setCustomValidity(""); 
            inputCmpRowType.reportValidity();
            inputCmpNotes.setCustomValidity(""); 
            inputCmpNotes.reportValidity();
            
            var subRowsCopy = [];
            for(var i=0; i<subRows.length; i++){
                if(subRows[i].id == undefined){
                    continue;                
                }
                else{
                    subRowsCopy.push(subRows[i]);
                }
            }
            component.set("v.individualLevelRecords", subRowsCopy);
        } 
        if(selectedOptionValue == null){
            component.set("v.accountRecord.BCAP_Individual_Level_Basis__c", null);
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
        }
        if(selectedOptionValue == 'Y'){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
            inputCmpRowType.setCustomValidity(" "); 
            inputCmpRowType.reportValidity();
        }
    },
    
    save : function(component, event, helper){
        var appEvent = component.getEvent("getChildRecordsEvent");
        appEvent.setParam("childRecords", component.get("v.individualLevelRecords"));
    },
    
    checkAssetClassValidity : function(component, event, helper){
        helper.validateAssetClass(component);
    },
    
    checkRegionValidity : function(component, event, helper){
        helper.validateRegion(component);
    },
    
    checkServiceValidity : function(component, event, helper){
        helper.validateService(component);
    },
    
    checkContentRankValidity : function(component, event, helper){
        helper.validateContentRank(component);
    },
    
    checkNotesValidity : function(component, event, helper){
        var inputCmpNotes = component.find("fieldIdNotes");
        var notes = component.get("v.accountRecord.BCAP_Interpretation_Notes__c");
        var child = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
        if(child == null){
            inputCmpNotes.setCustomValidity(""); 
            inputCmpNotes.reportValidity();
        }
        if(!helper.isEmpty(notes)){
            inputCmpNotes.setCustomValidity(""); 
            inputCmpNotes.reportValidity();
        }
        else if(helper.isEmpty(notes) && child != null){
            inputCmpNotes.setCustomValidity(" "); 
            inputCmpNotes.reportValidity();
        }
        
    },
    
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
    },
    
    likenClose: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        
        component.set("v.isOpen", false);
    },
    
    handleRegionComponentEvent : function(component, event, helper){
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.accountRecord.BCAP_Client_Region__c" , selectedAccountGetFromEvent.Id); 
        helper.validateRegion(component);
    },
    
    handleAssetClassComponentEvent : function(component, event, helper){
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.accountRecord.BCAP_Client_Asset_Class__c" , selectedAccountGetFromEvent.Id); 
        helper.validateAssetClass(component);
    } ,
    
    handleServiceComponentEvent : function(component, event, helper){
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.accountRecord.BCAP_Client_Service__c" , selectedAccountGetFromEvent.Id); 
        helper.validateService(component);
    },
    
    handleVotingTeamComponentEvent : function(component, event, helper){
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.accountRecord.BCAP_Voting_Team_Lookup__c" , selectedAccountGetFromEvent.Id); 
        //helper.validateService(component);
    },
    
    handleContentRankComponentEvent : function(component, event, helper){
        var preVal = component.get("v.previousContentRankValue");
        var selectedValue  = event.getParam("value");
        component.set("v.previousContentRankValue", selectedValue);
        if(selectedValue === 'Key Rank' || selectedValue === 'Key Rank US' || selectedValue === 'Key Rank UK'){
            var compEvent = component.getEvent("contentRankChangeEvent");
            compEvent.setParams({"contentRankValue":selectedValue,
                                 "accountLevelIndex": component.get("v.accRowIndex"),
                                 "previousContentRankValue": preVal
                                });
            compEvent.fire();
        }
    },
    handleDataChange: function(component, event, helper){
        var enteredValue = event.getParam("value");
        var haveDataValues = component.get("v.haveDataValues");
        var account = JSON.parse(JSON.stringify(component.get("v.accountRecord")));
        var hasDataValues = false;
        if(account.BCAP_Data_AUM__c !== '' && account.BCAP_Data_AUM__c !== undefined && account.BCAP_Data_AUM__c !== null){
            hasDataValues = true;
        }
        else if(account.BCAP_Data_Wallet__c !== '' && account.BCAP_Data_Wallet__c !== undefined && account.BCAP_Data_Wallet__c !== null){
            hasDataValues = true;
        }
            else if(account.BCAP_Data_Payment__c !== '' && account.BCAP_Data_Payment__c !== undefined && account.BCAP_Data_Payment__c !== null){
                hasDataValues = true;
            }
                else if(account.BCAP_Data_Tier__c !== '' && account.BCAP_Data_Tier__c !== undefined && account.BCAP_Data_Tier__c !== null){
                    hasDataValues = true;
                }
                    else if(account.BCAP_Data_Rank__c !== '' && account.BCAP_Data_Rank__c !== undefined && account.BCAP_Data_Rank__c !== null){
                        hasDataValues = true;
                    }
                        else if(account.BCAP_Data_Points__c !== '' && account.BCAP_Data_Points__c !== undefined && account.BCAP_Data_Points__c !== null){
                            hasDataValues = true;
                        }
                            else if(account.BCAP_Data_Market_Share__c !== '' && account.BCAP_Data_Market_Share__c !== undefined && account.BCAP_Data_Market_Share__c !== null){
                                hasDataValues = true;
                            }
                                else if(account.BCAP_Data_Wallet__c !== '' && account.BCAP_Data_Wallet__c !== undefined && account.BCAP_Data_Wallet__c !== null){
                                    hasDataValues = true;
                                }
                                    else if(account.BCAP_Data_Payment__c !== '' && account.BCAP_Data_Payment__c !== undefined && account.BCAP_Data_Payment__c !== null){
                                        hasDataValues = true;
                                    }
                                        else if(account.BCAP_Data_Relative_Rank__c !== '' && account.BCAP_Data_Relative_Rank__c !== undefined && account.BCAP_Data_Relative_Rank__c !== null){
                                            hasDataValues = true;
                                        }
                                            else if(account.BCAP_Data_Grade__c !== '' && account.BCAP_Data_Grade__c !== undefined && account.BCAP_Data_Grade__c !== null){
                                                hasDataValues = true;
                                            }
                                                else{
                                                    hasDataValues =false;
                                                }
        component.set("v.haveDataValues",hasDataValues);
    },
    controlVisibility : function(component, event, helper){
        var accountCaptures = event.getParam("accountCaptures"); 
        var individualCaptures = event.getParam("individualCaptures"); 
        component.set("v.accountCaptures",accountCaptures);
        component.set("v.individualCaptures",individualCaptures);
    },
    addNewIndividualRow : function(component, event, helper) {
        var row = {};
        var getIdPromise = helper.getExternalId(component);
        //row.BCAP_External_ID__c = component.get("v.tableType") + (component.get("v.rowIndex") + 1);
        row.type = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
        row.Parent_External_Id = component.get("v.BCAP_External_ID__c");
        row.BCAP_Is_Deleted__c = false;
        row.BCAP_Sector__c = 'Select';
        getIdPromise.then(function(id){
            row.BCAP_External_ID__c = id; 
            var subRows = component.get("v.individualLevelRecords");
            subRows.push(row);
            component.set("v.individualLevelRecords",subRows);
        });
    },
    handleCurrencyChange : function(component, event, helper) {
    },
    handleVotingTeamTierChange : function(component, event, helper) {
    }
    
})