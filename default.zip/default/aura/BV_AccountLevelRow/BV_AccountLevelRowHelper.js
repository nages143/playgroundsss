({
    handleChevronChange : function(component) {
        var showChild = component.get("v.showChild");
        var i = component.get("v.individualLevelRecords");
        var j = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c ");
        component.set("v.showChild",!showChild); 
        
        var accountCaptures = component.get("v.accountCaptures");
        var individualCaptures = component.get("v.individualCaptures");
        
        var subRows = JSON.parse(JSON.stringify(component.get("v.individualLevelRecords")));
        var BCAP_Individual_Level_Basis__c = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
        var count = 0;
        var tableType = 0;
        var allDeleted = false;
        for(var i in subRows){
            if(subRows[i].BCAP_Is_Deleted__c){
                count++;
            }
            if(subRows[i].type == BCAP_Individual_Level_Basis__c){
                tableType++;
            }
        }
        if(count == tableType){
            allDeleted = true;
        }
        if(component.get("v.showChild") && (subRows.length == 0 || allDeleted)){
            var row = {};
            //row.BCAP_External_ID__c = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c") + "0";
            var getIdPromise = this.getExternalId(component);
            row.type = component.get("v.accountRecord.BCAP_Individual_Level_Basis__c");
            row.Parent_External_Id = component.get("v.BCAP_External_ID__c");
            row.BCAP_Is_Deleted__c = false;
            getIdPromise.then(function(id){
                row.BCAP_External_ID__c = id; 
                component.set("v.individualLevelRecords",row);
            });
            
        }
    },
    
    addAccountRow : function(buttonIdentifier, component, event){
        var appEvent = component.getEvent("addAccountLevelRow");
        var row;
       // var lastRowIndex = component.get("v.lastRowIndex");
        if(buttonIdentifier == 'terminal'){
            row = {}; 
        }
        else if(buttonIdentifier == 'nonTerminal'){
            row = JSON.parse(JSON.stringify(component.get("v.accountRecord")));
        }
        
        //row.BCAP_External_ID__c = "Acc" + (lastRowIndex + 1);
        //row.BCAP_External_ID__c = helper.getExternalId(component);
        var getIdPromise = this.getExternalId(component);
        row.Id = null;
        
        //row.CreatedDate = null;
     //   row.IsDeleted = null;
      //  row.LastModifiedById = null;
      //  row.LastModifiedDate = null;
      //  row.LastReferencedDate = null;
      //  row.LastViewedDate = null;
      //  row.Name = null;
        //row.OwnerId = null;
    //    row.SystemModstamp = null;
        row.type = 'Account';
        row.Parent_External_Id = null;
        row.BCAP_Is_Deleted__c = false;
        if(row.BCAP_Content_Rank__c == 'Key Rank') {
            row.BCAP_Content_Rank__c = '';
        }
        getIdPromise.then(function(id){
            row.BCAP_External_ID__c = id; 
            appEvent.setParam("row", row);
            appEvent.fire();
        });
        
    },
    
    getExternalId : function(component){
        return new Promise((function(resolve, reject){
            var action1 = component.get("c.bvGUID");
            var id = null;
            action1.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    id = response.getReturnValue();
                    resolve(id)
                }
                else{
                    reject(null)
                }
            });
            $A.enqueueAction(action1);          
        }));
    },
    
    //setIndividualRows : function(cmp){
    //  	var subRows = cmp.get("v.individualLevelRecords");
    //    var formattedRows = JSON.parse(JSON.stringify(subRows));
    //    cmp.set("v.individualLevelRecords",formattedRows);  
    //}
    
    isEmpty : function(value){
        return (!value || value == "");
    },
    
    handleValidityCheck : function(component, selectedClientEntity, selectedBarclaysEntity, inputCmp, selectedBarclaysFieldString){
        if((!this.isEmpty(selectedBarclaysEntity) && this.isEmpty(selectedClientEntity)) ){
            //inputCmpCAS.setCustomValidity("Required"); 
            //inputCmpCAS.reportValidity();
            component.set(selectedBarclaysFieldString, null);
        }
        if(this.isEmpty(selectedBarclaysEntity) && !this.isEmpty(selectedClientEntity)){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
        }
        if(!this.isEmpty(selectedBarclaysEntity) && !this.isEmpty(selectedClientEntity)){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        }
        if(this.isEmpty(selectedBarclaysEntity) && this.isEmpty(selectedClientEntity)){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        }
    },
    
    validateRegion : function(component){
        var inputCmp = component.find("fieldIdRegion");
        var selectedClientRegion = component.get("v.accountRecord.BCAP_Client_Region__c");
        var selectedRegion = component.get("v.accountRecord.BCAP_Region__c");
        this.handleValidityCheck(component, selectedClientRegion, selectedRegion, inputCmp, "v.accountRecord.BCAP_Region__c");
    },
    
    validateAssetClass : function(component){
        var inputCmpAC = component.find("fieldIdAC");
        var selectedClientAssetClass = component.get("v.accountRecord.BCAP_Client_Asset_Class__c");
        var selectedAssetClass = component.get("v.accountRecord.BCAP_Asset_Class__c");
        this.handleValidityCheck(component, selectedClientAssetClass, selectedAssetClass, inputCmpAC, "v.accountRecord.BCAP_Asset_Class__c");
    },
    
    validateService : function(component){
        var inputCmp = component.find("fieldIdService");
        var selectedClientService = component.get("v.accountRecord.BCAP_Client_Service__c");
        var selectedService = component.get("v.accountRecord.BCAP_Service__c");
        this.handleValidityCheck(component, selectedClientService, selectedService, inputCmp, "v.accountRecord.BCAP_Service__c");
    },
})