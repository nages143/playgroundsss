({
    init : function(component, event, helper) {
        
        var actions = [
            { label: 'Delete', name: 'delete' }
        ];
        var columns = [];
            
            
        var readOnly = component.get("v.readOnly");
        if(!readOnly) {
            columns.push({label: 'Rule', fieldName:'Rule', type: 'text', editable:'true'});
            columns.push({label: 'Score', fieldName:'Score' , type: 'text', editable:'true'});
            columns.push({type: 'action', typeAttributes: { rowActions: actions}});
        }
        else {
            columns.push({label: 'Rule', fieldName:'Rule', type: 'text'});
            columns.push({label: 'Score', fieldName:'Score' , type: 'text'});
        }
        component.set('v.columns', columns);
        component.set("v.dataUpdated", true);
        
        var allocationMethodMap = new Map();
        
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        if(allocationMethodsWithLists != undefined) {
            for(var index=0; index < allocationMethodsWithLists.length; index++) {
                allocationMethodMap.set(allocationMethodsWithLists[index].BCAP_Region__c, true);
            }
        }

        var action = component.get("c.getAllocationMethodRegions");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
               
                var regions = [];
                var res = JSON.parse(response.getReturnValue());
                for(var index=0; index < res.length; index++) {
                    var region = {"label": res[index].label, "value": res[index].apiName};
                    if(component.get("v.readOnly") == true) {
                        var region = res[index].apiName;
                        if(allocationMethodMap.get(region) == true) {
                            region = {"label": res[index].label, "value": region
                                      ,"allocationAvailable": true};
                        } else {
                            region = {"label": res[index].label, "value": region
                                      ,"allocationAvailable": false};
                        }
                    } 
                    regions.push(region);
                }
                component.set("v.regions",regions);
                helper.getFunctions(component, event);
               
            }
        });
        $A.enqueueAction(action);
    },
    addAllocMethod : function(component, event, helper) {
        var region = event.getSource().get('v.value');
        var mainVoteId = component.get("v.mainVoteId");
        
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        var allocMethod = {"BCAP_Region__c": region, "BCAP_Vote__c": mainVoteId,
                           "BCAP_Is_Deleted__c":false, "Rule_Score_List": []};
        allocationMethodsWithLists.push(allocMethod);
        console.log('addAllocMethod Called'); 
        component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
    } ,
    deleteAllocMethod: function(component, event, helper) {
        var delIndex = event.getSource().get('v.value');
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        for(var index=0; index < allocationMethodsWithLists.length; index++) {
            if(delIndex == index) {
                if(allocationMethodsWithLists[index].Id != undefined)
                    allocationMethodsWithLists[index].BCAP_Is_Deleted__c = true;
                else
                    allocationMethodsWithLists.splice(index,1);
            }
        }
        component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
    },
    handleRowAction: function(component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');

        switch (action.name) {
            case 'delete':
                var rows = component.get("v.currentProcessingAllocMethodList");
                var rowIndex = rows.indexOf(row);
                rows.splice(rowIndex, 1);
                component.set("v.currentProcessingAllocMethodList", rows);
                
                var currentTable = component.get('v.currentProcessingAllocMethod');
                var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
                allocationMethodsWithLists[currentTable].Rule_Score_List = rows;
                component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
        }
    },
    handleTableSeletion: function(component, event, helper) {
        var ctarget = event.currentTarget;
        var tableId = ctarget.dataset.value;
        component.set("v.currentProcessingAllocMethod", tableId);
        
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        var rows = allocationMethodsWithLists[tableId].Rule_Score_List;
        component.set("v.currentProcessingAllocMethodList", rows);
        
    },
    onSave: function(component, event, helper) {
        //var editedRecords =  component.find("dataTable").get("v.draftValues");
        //var totalRecordEdited = editedRecords.length;
        component.set("v.dataUpdated", false);
        var draftValues = event.getParam('draftValues');
        
        var currentTable = component.get('v.currentProcessingAllocMethod');
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        
        var rows = allocationMethodsWithLists[currentTable].Rule_Score_List;
        
        for(var index=0; index < draftValues.length; index++) {
            var rowId = draftValues[index].id.split("-")[1];
            if(draftValues[index].Rule) {
                rows[rowId].Rule = draftValues[index].Rule;
            }
            if(draftValues[index].Score) {
                rows[rowId].Score = draftValues[index].Score;
            }
        }
        allocationMethodsWithLists[currentTable].Rule_Score_List = rows;
        component.set("v.dataUpdated", true);
        component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
    },
    addNewRule: function(component, event, helper) {
        var tableId = event.getSource().get("v.value");
        component.set("v.currentProcessingAllocMethod", tableId);
        
        var currentTable = tableId;
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        
        var rows = allocationMethodsWithLists[currentTable].Rule_Score_List;
        
        rows.push({'Score':'', 'Rule': ''});
        
        allocationMethodsWithLists[currentTable].Rule_Score_List = rows;
        component.set("v.currentProcessingAllocMethodList", rows);
        component.set("v.dataUpdated", true);
        component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
    }
})