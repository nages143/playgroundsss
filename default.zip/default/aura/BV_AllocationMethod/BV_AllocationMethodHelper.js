({
	getFunctions : function(component, event, helper) {
		var action = component.get("c.getAllocationMethodFunctions");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var functions = [];
                var res = response.getReturnValue();
                for(var index=0; index < res.length; index++) {
                    var functionVal = {"label": res[index], "value": res[index]};
                    functions.push(functionVal);
                    
                }
                component.set("v.functions",functions);
                component.set("v.dataInitiated", true);
            }
        });
        $A.enqueueAction(action);
	}
})