({
    doInit:function (component, evt, helper){
        
       /* var fieldNames = ['BuyingCenter', 'VotePeriod', 'VotingTeam', 'ContactName', 'ContactEmail',
                         'PCL', 'Sector', 'EmployeeName', 'EmployeeEmail', 'Function', 'BillableInteractions',
                         'NonBillableInteractions', 'Comments', 'DataTier', 'DataRank', 'DataPoints', 
                          'DataPayment', 'DataRelativeRank', 'DataGrade', 'DataNotes', 'DataOtherQuantativeData',
                         'BarclaysRank', 'UsefulInformation'];*/
        var listOfBrokerVotes = component.get("v.allVotes.votes");
        component.set("v.listOfBrokerVotes", listOfBrokerVotes);
        var allocMethodology = JSON.parse(component.get("v.allVotes.allocMethodology"));
        if(allocMethodology)
            component.set("v.allocMethodology", allocMethodology.allocationMethods);
        
        component.set("v.allocationMethodsWithLists", JSON.parse(JSON.stringify(component.get("v.allocMethodology"))));
        var allocationMethodsWithLists = component.get("v.allocationMethodsWithLists");
        if(allocationMethodsWithLists != undefined) {
            for(var index=0; index < allocationMethodsWithLists.length; index++) {
                var rules = allocationMethodsWithLists[index].BCAP_Rule__c.split("\n");
                var scores = allocationMethodsWithLists[index].BCAP_Score__c.split("\n");
                var data = [];
                for(var i=0;i<rules.length;i++) {
                    var row = {'Rule': rules[i], 'Score': scores[i]};
                    data.push(row);
                }
                allocationMethodsWithLists[index].Rule_Score_List = data;
            }
            component.set("v.allocationMethodsWithLists", allocationMethodsWithLists);
        }
        
        var tiers = component.get("v.allVotes.tiers");
        component.set("v.tiers", tiers);
        var votingEntities = component.get("v.allVotes.votingEntities");
        component.set("v.votingEntities", votingEntities);
        var voteFrequency = component.get("v.allVotes.voteFrequency");
        component.set("v.voteFrequency", voteFrequency);
        
        var individualCaptures = component.get("v.allVotes.individualCaptures");
        component.set("v.individualCaptures", individualCaptures);
        
        var mainVote = component.get("v.allVotes.vote");
        component.set("v.vote", mainVote);
        var mainVoteId = component.get("v.allVotes.vote.Id");
        var columns = [];
        if(mainVoteId == null){
            columns.push({label: 'Vote Period', fieldName: 'VotePeriod', type: 'text', initialWidth: 120,cellAttributes: { class: { fieldName: 'highlightRow' }}});
            columns.push({label: 'Buying Center', fieldName: 'BuyingCenter', type: 'text',initialWidth: 450,cellAttributes: { class: { fieldName: 'highlightRow' }}});
            var dataTableId = component.find("dataTableId");
            $A.util.addClass(dataTableId, 'multipleVote');
        }
        else{
            component.set("v.isSingleVote", true);
            var dataTableId = component.find("dataTableId");
            $A.util.addClass(dataTableId, 'singleVote');
        }
        
        var isSingleVote = component.get("v.isSingleVote");
        
        columns.push({label: 'Voting Team', fieldName: 'VotingTeam', type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Contact Name', fieldName: 'ContactName', type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Contact Email', fieldName:'ContactEmail' , type: 'text',initialWidth: 300,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'PCL', fieldName:'PCL' , type: 'text',initialWidth: 100,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Sector', fieldName:'Sector' , type: 'text',initialWidth: 300,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Employee Name', fieldName:'EmployeeName' , type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Employee Email', fieldName: 'EmployeeEmail', type: 'text',initialWidth: 300,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Function', fieldName: 'Function', type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Billable Int.', fieldName: 'BillableInteractions', type: 'text',initialWidth: 120,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Non-Billable Int.', fieldName:'NonBillableInteractions' , type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        
        if((individualCaptures[0].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Tier', fieldName: 'DataTier', type: 'text',initialWidth: 100,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[1].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Rank', fieldName: 'DataRank', type: 'text',initialWidth: 100,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[2].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Points', fieldName: 'DataPoints', type: 'text',initialWidth: 110,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[3].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Payment', fieldName: 'DataPayment', type: 'text',initialWidth: 120,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[4].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Relative Rank', fieldName: 'DataRelativeRank', type: 'text',initialWidth: 150,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[5].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Grade', fieldName: 'DataGrade', type: 'text' ,initialWidth: 120,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[6].hasValue && isSingleVote) || !isSingleVote)
            columns.push({label: 'Data-Notes', fieldName:'DataNotes' , type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        if((individualCaptures[7].hasValue && isSingleVote) || !isSingleVote) 
            columns.push({label: 'Data-Other Quantative', fieldName:'DataOtherQuantativeData' , type: 'text',initialWidth: 200,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        
        columns.push({label: 'Barclays Rank', fieldName:'BarclaysRank' , type: 'text',initialWidth: 120,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        columns.push({label: 'Useful Information', fieldName:'UsefulInformation' , type: 'text',initialWidth: 300,cellAttributes: { class: { fieldName: 'highlightRow' }}});
        
        component.set('v.columns', columns);
        
        var data = [];
        for(var i=0;i<listOfBrokerVotes.length;i++) {
            var vote = listOfBrokerVotes[i];
            var row = {};
            
            if(mainVoteId == null){
                if(vote.BCAP_Vote__r.BCAP_Buying_Centre__r)
                    row['BuyingCenter']= vote.BCAP_Vote__r.BCAP_Buying_Centre__r.Name;
                if(vote.BCAP_Vote__r.BCAP_Vote_Period__r)
                    row['VotePeriod']= vote.BCAP_Vote__r.BCAP_Vote_Period__r.Name;
            }
            if(vote.BCAP_Parent__r && vote.BCAP_Parent__r.BCAP_Voting_Team_Lookup__r)
                row['VotingTeam']= vote.BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name;
            if(vote.BCAP_Contact__r)
                row['ContactName']= vote.BCAP_Contact__r.Name;
            if(vote.BCAP_Contact__r)
                row['ContactEmail']= vote.BCAP_Contact__r.Email;
            if(vote.BCAP_PCL__c)
                row['PCL']= vote.BCAP_PCL__c;
            if(vote.BCAP_Sector__c)
                row['Sector']= vote.BCAP_Sector__c;
            if(vote.BCAP_Employee__r)
                row['EmployeeName']= vote.BCAP_Employee__r.Name;
            if(vote.BCAP_Employee__r)
                row['EmployeeEmail']= vote.BCAP_Employee__r.T1C_Base__Email__c;
            if(vote.BCAP_Function__c)
                row['Function']= vote.BCAP_Function__c;
            var billHoursPresent = false;
            if(vote.BCAP_Billable_Hours__c){
                row['BillableInteractions']= ''+vote.BCAP_Billable_Hours__c;
                if(vote.BCAP_Billable_Hours__c == 0 && (vote.BCAP_Function__c=='Equity Research' || vote.BCAP_Function__c== 'Specialist Sales'))
                    billHoursPresent = true;
            }
            else if(vote.BCAP_Function__c=='Equity Research' || vote.BCAP_Function__c== 'Specialist Sales'){
                billHoursPresent = true;
            }
            if(vote.BCAP_Total_Hours_Ex_Corp_Access__c){
                row['NonBillableInteractions']= ''+vote.BCAP_Total_Hours_Ex_Corp_Access__c;
                if(vote.BCAP_Total_Hours_Ex_Corp_Access__c == 0 && billHoursPresent&&
                   (vote.BCAP_Function__c=='Equity Research' || vote.BCAP_Function__c== 'Specialist Sales'))
                    row['highlightRow'] = 'HighlightRow';
            }
            else if((vote.BCAP_Function__c=='Equity Research' || vote.BCAP_Function__c== 'Specialist Sales') &&
                    billHoursPresent){
                row['highlightRow'] = 'HighlightRow';
            }
            if((individualCaptures[0].hasValue && isSingleVote) || !isSingleVote)
                row['DataTier']= vote.BCAP_Data_Tier__c;
            if((individualCaptures[1].hasValue && isSingleVote) || !isSingleVote)
                row['DataRank']= vote.BCAP_Data_Rank__c;
            if((individualCaptures[2].hasValue && isSingleVote) || !isSingleVote)
                row['DataPoints']= ''+vote.BCAP_Data_Points__c;
            if((individualCaptures[3].hasValue && isSingleVote) || !isSingleVote)
                row['DataPayment']= ''+vote.BCAP_Data_Payment__c;
            if((individualCaptures[4].hasValue && isSingleVote) || !isSingleVote)
                row['DataRelativeRank']= vote.BCAP_Data_Relative_Rank__c;
            if((individualCaptures[5].hasValue && isSingleVote) || !isSingleVote)
                row['DataGrade']= vote.BCAP_Data_Grade__c;
            if((individualCaptures[6].hasValue && isSingleVote) || !isSingleVote)
                row['DataNotes']= vote.BCAP_Comments__c;            
            if((individualCaptures[7].hasValue && isSingleVote) || !isSingleVote)
                row['DataOtherQuantativeData']= vote.BCAP_Other_Quantative_Data__c;
            if(vote.BCAP_Rank__c)
                row['BarclaysRank']= vote.BCAP_Rank__c;
            if(vote.BCAP_Notes__c)
                row['UsefulInformation']= vote.BCAP_Notes__c;
           
            data.push(row);
        }
        console.log(data);
        component.set("v.data", data);
    },
    showAllocMethodDialog:function(component, event, helper){
        component.set("v.showAllocMethodDialog", true);
    },
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Allocation Method Read Only') {
            if(actionType === 'No') {
               	component.set("v.showAllocMethodDialog", false);
            }
        }
    },
})