({
	init:function (component, event, helper){
        component.set("v.clearBC", 0);
        component.set("v.clearEmp", 0);
        var userRegion = component.get("v.userRegion");
        if(userRegion == 'EU')
        	helper.getSectors(component, event);
        if(userRegion == 'NAM')
        	helper.getLeadAnalysts(component, event);
    },
    handleComponentEvent : function(component, event, helper) {
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.selectedLookUpRecord" , selectedAccountGetFromEvent); 
        component.set("v.bcNameToDisplay",selectedAccountGetFromEvent.Name +" - "+selectedAccountGetFromEvent.AccountNumber);
 		component.set("v.buyingCenterSelected", true);
        helper.getVotePeriodsForSelectedBC(component, event, selectedAccountGetFromEvent);
        helper.getVotingTeamsForSelectedBC(component, event, selectedAccountGetFromEvent);
    },
    clearBuyingCenterField: function(component, event, helper) {
        component.set("v.selectedLookUpRecord",{});
        component.set("v.buyingCenterSelected", false);
        component.set("v.votePeriods", []);
        component.set("v.votePeriod", null);
        component.set("v.votingTeams", []);
        component.set("v.votingTeam", null);
    },
    handleEmployeeComponentEvent:  function(component, event, helper) {
        var userRegion = component.get("v.userRegion");
        if(userRegion == 'EU'){
            var sectors = component.get("v.sectors");
            component.find("sectorId").set("v.value", sectors[0].value);
            component.set("v.sector",  sectors[0].value);
        }
        if(userRegion == 'NAM'){
            var leadAnalysts = component.get("v.leadAnalysts");
            component.find("leadAnalystId").set("v.value", leadAnalysts[0].value);
            component.set("v.leadAnalyst",  leadAnalysts[0].value);
        }
    },
    clearEmployeeField:  function(component, event, helper) {
        component.set("v.selectedEmployeeRecord", {});
    },
    handleClear : function(component, event, helper) {
        component.set("v.selectedLookUpRecord", {});
        component.set("v.bcNameToDisplay", "");
        component.set("v.buyingCenterSelected", false);
        
        component.set("v.votePeriods", []);
        component.set("v.votePeriod", null);
        component.set("v.votingTeams", []);
        component.set("v.votingTeam", null);

        var sectors = component.get("v.sectors");
        component.find("sectorId").set("v.value", sectors[0].value);
        component.set("v.sector",  sectors[0].value);
        
        component.set("v.selectedEmployeeRecord", {});
        
        var clearBC = component.get("v.clearBC");
        component.set("v.clearBC", 1-clearBC);  
        var clearEmp = component.get("v.clearEmp");
        component.set("v.clearEmp", 1-clearEmp);  
    },
    handleComboboxValueChange: function(component, event, helper) {
        if(event.getSource().getLocalId() === "votingTeamId"){
            var val = component.find('votingTeamId').get("v.value");
            component.set("v.votingTeam", val);
        }
         if(event.getSource().getLocalId() === "votePeriodId"){
            var val = component.find('votePeriodId').get("v.value");
            component.set("v.votePeriod", val);
        }
         if(event.getSource().getLocalId() === "sectorId"){
            var val = component.find('sectorId').get("v.value");
            component.set("v.sector", val);
             
             if(val!='all') {
                 component.set("v.selectedEmployeeRecord", {});
                 var clearEmp = component.get("v.clearEmp");
                 component.set("v.clearEmp", 1-clearEmp); 
             }
             
        }
        if(event.getSource().getLocalId() === "leadAnalystId"){
            var val = component.find('leadAnalystId').get("v.value");
            component.set("v.leadAnalyst", val);
             
             if(val!='all') {
                 component.set("v.selectedEmployeeRecord", {});
                 var clearEmp = component.get("v.clearEmp");
                 component.set("v.clearEmp", 1-clearEmp); 
             }
             
        }
    },
    handleGetDetails: function(component, event, helper) {
        var action = component.get("c.searchBrokerVotesByAnalyst");
        
        var buyingCenter = component.get("v.selectedLookUpRecord");
        var votePeriod = component.get("v.votePeriod");
        var barclaysIndividual = component.get('v.selectedEmployeeRecord').Id;
        var votingTeam = component.get('v.votingTeam');
        var sector = component.get('v.sector');
        var leadAnalyst = component.get('v.leadAnalyst');
            
        var params = {"buyingCenterId": buyingCenter.Id,
                      "votePeriodId": votePeriod,
                      "votingTeam":votingTeam,
                      "sector":sector,
                      "leadAnalyst" : leadAnalyst,
                      "barclaysIndividual":barclaysIndividual,
                     }; 
        
        action.setParams({
            'params': JSON.stringify(params)
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                var storeResponse = JSON.parse(response.getReturnValue());
                component.set("v.listOfBrokerVotes", storeResponse);
                var appEvent = $A.get("e.c:BV_AnalystSearchEvent");
                appEvent.setParam("listOfBrokerVotes", storeResponse);                     
                appEvent.fire();
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        if(buyingCenter.Name==undefined && 
            (votePeriod == undefined || votePeriod == null) && 
           	(barclaysIndividual==undefined || barclaysIndividual==null) &&
           	(votingTeam==undefined || votingTeam==null) &&
            (sector==undefined || sector==null) &&
            (leadAnalyst==undefined || leadAnalyst==null)){
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message",  "Please select atleast one filter!");
            appEvent.setParam("type", "error");
            appEvent.setParam("mode", "dismissible");
            appEvent.setParam("duration", "3000");
            appEvent.fire();
        }
        else{
             $A.enqueueAction(action);
        }
    }
})