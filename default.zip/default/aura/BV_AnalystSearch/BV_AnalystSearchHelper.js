({
	getSectors:function (component, event){
        var action1 = component.get("c.getSector");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfSector = [];
                console.log("From server sector: " + JSON.stringify(response.getReturnValue()));
                var sector = response.getReturnValue();
                listOfSector.push({'label' :'All' , 'value':'all'});
                for(var i=0;i<sector.length; i++){
                    listOfSector.push({'label' :sector[i] , 'value':sector[i]});
                } 
                component.find("sectorId").set("v.value",listOfSector[0].value);
                component.set("v.sectors", listOfSector);
                component.set("v.sector", listOfSector[0].value);
            }
        }); 
        $A.enqueueAction(action1);
    },
    getLeadAnalysts:function (component, event){
        var action1 = component.get("c.getBVAnalyst");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfLeadAnalysts = [];
                console.log("From server LeadAnalysts: " + JSON.stringify(response.getReturnValue()));
                var leadAnalyst = response.getReturnValue();
               // listOfLeadAnalysts.push({'label' :'All' , 'value':'all'});
                for(var i=0;i<leadAnalyst.length; i++){
                    listOfLeadAnalysts.push({'label' :leadAnalyst[i].BCAP_Primary_Employee__r.Name , 'value':leadAnalyst[i].BCAP_Primary_Employee__r.Id});
                } 
                component.find("leadAnalystId").set("v.value",listOfLeadAnalysts[0].value);
                component.set("v.leadAnalysts", listOfLeadAnalysts);
                component.set("v.leadAnalyst", listOfLeadAnalysts[0].value);
            }
        }); 
        $A.enqueueAction(action1);
    },
    getVotePeriodsForSelectedBC:function (component, event, selectedAccountGetFromEvent){
        var action1 = component.get("c.getVotePeriodsForSelectedBuyingCenter");
        action1.setParams({
            'selectedAccountId' : selectedAccountGetFromEvent.Id
        });
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfvotePeriods = [];
                console.log("From server : " + JSON.stringify(response.getReturnValue()));
                
                var votePeriods = response.getReturnValue();
                if(votePeriods.length) {
                    for(var i=0;i<votePeriods.length; i++){
                        if(i==0)
                            listOfvotePeriods.push({'label' :votePeriods[i].BCAP_Vote_Period__r.Name+' - Latest' , 'value':votePeriods[i].BCAP_Vote_Period__r.Id});
                        else
                        	listOfvotePeriods.push({'label' :votePeriods[i].BCAP_Vote_Period__r.Name , 'value':votePeriods[i].BCAP_Vote_Period__r.Id});
                    } 
                    component.find("votePeriodId").set("v.value",listOfvotePeriods[0].value);
                    component.set("v.votePeriods", listOfvotePeriods);
                    component.set("v.votePeriod", listOfvotePeriods[0].value);
                }
            }
        }); 
        $A.enqueueAction(action1);
    },
    getVotingTeamsForSelectedBC:function (component, event, selectedAccountGetFromEvent){
        var action1 = component.get("c.getVoteValues");
        action1.setParams({
            'bcId': selectedAccountGetFromEvent.Id,
            'type': 'Voting Team',
            'value': ''
        });
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfVotingTeams = [];
                console.log("From server : " + JSON.stringify(response.getReturnValue()));
                
                var votingTeams = response.getReturnValue();
                listOfVotingTeams.push({'label' :'All' , 'value':'all'});
                if(votingTeams.length) {
                    for(var i=0;i<votingTeams.length; i++){
                        listOfVotingTeams.push({'label' :votingTeams[i].Name , 'value':votingTeams[i].Id});
                    } 
                    component.find("votingTeamId").set("v.value",listOfVotingTeams[0].value);
                    component.set("v.votingTeams", listOfVotingTeams);
                    component.set("v.votingTeam", listOfVotingTeams[0].value);
                }
            }
        }); 
        $A.enqueueAction(action1);
    },
})