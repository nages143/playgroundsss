({
    init : function(component, event, helper) {
        var allDetails = component.get("v.allDetails");
        /*
        var votingTeam = allDetails[0].BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name;
        allDetails[0]['differentVotingTeam'] = true;
        
        for(var j=1;j<allDetails.length;j++) {
            if(votingTeam !== allDetails[j].BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name){
                allDetails[j]['differentVotingTeam'] = true;
                votingTeam = allDetails[j].BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name;
            }
        }
		*/
		
		var votingTeam = '';
		if(allDetails[0].BCAP_Parent__r.BCAP_Voting_Team_Lookup__c) {
        	votingTeam = allDetails[0].BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name;
        }
        allDetails[0]['differentVotingTeam'] = true;
        
        for(var j=1;j<allDetails.length;j++) {
        	var votingTeam1 = '';
        	if(allDetails[j].BCAP_Parent__r.BCAP_Voting_Team_Lookup__c) {
        		votingTeam1 = allDetails[j].BCAP_Parent__r.BCAP_Voting_Team_Lookup__r.Name;
        	}
            if(votingTeam !== votingTeam1){
                allDetails[j]['differentVotingTeam'] = true;
                votingTeam = votingTeam1;
            }
        }
       
        var selectedRegion = component.get("v.selectedRegion");
        var selectedRegionFullName= '';
        if(selectedRegion == 'EU'){
            selectedRegionFullName='Europe';
        }
        else if(selectedRegion == 'NAM'){
            selectedRegionFullName='Americas';
        }
        else{
            selectedRegionFullName='Global';    
        }
		component.set("v.selectedRegionFullName", selectedRegionFullName);
        
        //component.set("v.allDetails", allDetails);
        component.set("v.dataInitiated", true);
    },
    handleRegionChanged: function(component, event, helper) {
        var selectedRegion = event.getParam("selectedRegion");
        component.set("v.selectedRegion", selectedRegion);
        var selectedRegionFullName= '';
        if(selectedRegion == 'EU'){
            selectedRegionFullName='Europe';
        }
        else if(selectedRegion == 'NAM'){
            selectedRegionFullName='Americas';
        }
        else{
            selectedRegionFullName='Global';    
        }
		component.set("v.selectedRegionFullName", selectedRegionFullName);
        component.find("tabs").set("v.selectedTabId", "all");
    }
})