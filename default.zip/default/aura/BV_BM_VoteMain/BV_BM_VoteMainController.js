({
	init : function(component, event, helper) {
        var selectedRegion = component.get("v.selectedRegion");
		component.find("regionId").set("v.value",selectedRegion);
        var tiers = component.get("v.tiers");
        for(var i=0;i<tiers.length; i++) {
            if(tiers[i].BCAP_Region__c === 'US')
                tiers[i].BCAP_Region__c = 'NAM';
        }
        component.set("v.tiers", tiers);
        
        console.log(' component.get("v.totalDocuments") - '+component.get("v.totalDocuments"));
        if(component.get("v.totalDocuments") != null && component.get("v.totalDocuments") != '') {
            component.set("v.documentLabel","Docs (" + component.get("v.totalDocuments") + ")");
        } else {
            component.set("v.documentLabel","Docs (0)");
        }
        component.set("v.documentViewUrl",$A.get("$Label.c.brokerVoteGetActiveStoreURI"));	
        
	},
    handleRegionchanged:function(component, event, helper) {
        var region = component.find('regionId').get("v.value");
        component.set("v.selectedRegion", region);
        var appEvent = $A.get("e.c:BV_handleRegionchangedEvent");
        appEvent.setParam("selectedRegion", region);
        appEvent.fire();
    },
    showAllocMethodDialog:function(component, event, helper){
        var region = component.find('regionId').get("v.value");
        component.set("v.selectedRegion", region);
        component.set("v.showAllocMethodDialog", true);
    },
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Allocation Method Read Only') {
            if(actionType === 'No') {
               	component.set("v.showAllocMethodDialog", false);
            }
        }
    },
    handleViewDocument: function(component, event, helper) {      
        var fileId =  event.getSource().get("v.value");
        if(fileId !== "") {
            var url = $A.get("$Label.c.PSGetActiveStoreURI") + fileId;
            var win = window.open(url, '_blank');
        }
        
    }
})