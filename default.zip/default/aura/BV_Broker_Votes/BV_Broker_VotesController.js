({
    init: function (component, event, helper) {
        var action1 = component.get("c.getRegion");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
            }
        }); 
        var voteDetails = component.get("v.voteDetails");
        var accountLevelRows = component.get("v.accountLevelRows");
        if(voteDetails!=null && voteDetails.length == 0) {
            var row = {};
            var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
            var getIdPromise = helper.getExternalId(component);
            
            //row.BCAP_External_ID__c = "Acc0";
            //row.BCAP_External_ID__c = helper.getExternalId(component);
            row.type = 'Account';
            row.Parent_External_Id = null;
            //row.BCAP_Is_Deleted__c = false;
            getIdPromise.then(function(id){
                row.BCAP_External_ID__c = id; 
                accounts.push({'accountLevel':row,'individualLevels':[]});
                component.set("v.accountLevelRows", accounts);
            });
        }
        $A.enqueueAction(action1);
        var recordMap = {};
        var recordIdPromise1 = helper.getRecordTypeId('Account', component);
        recordIdPromise1.then(function(recordTypeId){
            recordMap["Account"] = recordTypeId;
            component.set("v.recordMap", recordMap);
        });
        var recordIdPromise2 = helper.getRecordTypeId('Overall detail only', component);
        recordIdPromise2.then(function(recordTypeId){
            recordMap["Overall detail only"] = recordTypeId;
            component.set("v.recordMap", recordMap);
        });
        var recordIdPromise3 = helper.getRecordTypeId('Sector / Industry detail', component);
        recordIdPromise3.then(function(recordTypeId){
            recordMap["Sector / Industry detail"] = recordTypeId;
            component.set("v.recordMap", recordMap);
        });
        var recordIdPromise4 = helper.getRecordTypeId('Voter detail', component);
        recordIdPromise4.then(function(recordTypeId){
            recordMap["Voter detail"] = recordTypeId;
            component.set("v.recordMap", recordMap);
        });
        var buyingCenter = JSON.parse(JSON.stringify(component.get("v.buyingCenter")));
        var voteDetails = JSON.parse(JSON.stringify(component.get("v.voteDetails")));
        var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
        var individualRows = JSON.parse(JSON.stringify(component.get("v.individualRows")));
        console.log(voteDetails);
        /* if(voteDetails){
            accounts = accounts.concat(voteDetails);
            for(var i=0; i<accounts.length; i++){
                accounts[i].type = 'Account';
                if(accounts[i].Vote_Details__r != undefined){
                   for(var j=0; j<accounts[i].Vote_Details__r.records.length; j++){
                    	accounts[i].Vote_Details__r.records[j].Parent_External_Id = accounts[i].BCAP_External_ID__c;
                    	accounts[i].Vote_Details__r.records[j].type = accounts[i].BCAP_Individual_Level_Basis__c;
                	} 
                }
            }
        }	*/
        if(voteDetails){
            component.set("v.contentRankValue", false);
            for(var i=0; i<voteDetails.length; i++){
                voteDetails[i].accountLevel.type = 'Account';
                if(voteDetails[i].accountLevel.BCAP_Content_Rank__c == 'Key Rank') {
                    component.set("v.contentRankValue", true);    
                }
                if(voteDetails[i].individualLevels != undefined){
                    for(var j=0; j<voteDetails[i].individualLevels.length; j++){
                        voteDetails[i].individualLevels[j].Parent_External_Id = voteDetails[i].accountLevel.BCAP_External_ID__c;
                        voteDetails[i].individualLevels[j].type = voteDetails[i].accountLevel.BCAP_Individual_Level_Basis__c;
                    } 
                }
            }
            component.set("v.accountLevelRows", voteDetails);
            accounts = accounts.concat(voteDetails);
        }
        var clientStrategyScreen = component.get("v.clientStrategyScreen");
        if(clientStrategyScreen) {
            var voteDetailsGridId = component.find("voteDetailsGrid");
            $A.util.addClass(voteDetailsGridId, 'disableGrid');
        }
        var accountCaptures = component.get("v.accountCaptures");
        var previousAccountCaptures = [];
        for(var i=0;i<accountCaptures.length;i++) {
            previousAccountCaptures.push({"isVisible": accountCaptures[i].isVisible,
                                          "hasValue": accountCaptures[i].hasValue,
                                          "colName": accountCaptures[i].colName});
        }
        component.set("v.previousAccountCaptures",previousAccountCaptures);
        var individualCaptures = component.get("v.individualCaptures");
        var previousIndividualCaptures = [];
        for(var i=0;i<individualCaptures.length;i++) {
            previousIndividualCaptures.push({"isVisible": individualCaptures[i].isVisible,
                                             "hasValue": individualCaptures[i].hasValue,
                                             "colName": individualCaptures[i].colName});
        }
        component.set("v.previousIndividualCaptures",previousIndividualCaptures);
    },
    
    addAccountRow: function(component, event, helper){
        var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
        var row = JSON.parse(JSON.stringify(event.getParam("row")));
        accounts.push({'accountLevel':row,'individualLevels':[]});
        component.set("v.accountLevelRows", accounts);
    },
    
    deleteAccountRow : function(component, event, helper){
        var accounts = component.get("v.accountLevelRows");
        //TODO: set row param in event
        //TODO: If SF ID does not exist then splice
        var index = event.getSource().get("v.accRowIndex");
        accounts[index].accountLevel.BCAP_Is_Deleted__c = true;
        if(accounts[index].individualLevels) {
            var indLevels = accounts[index].individualLevels;
            for(var indVoteIndex = 0; indVoteIndex< indLevels.length; indVoteIndex += 1) {
                indLevels[indVoteIndex].BCAP_Is_Deleted__c = true;
            }
        }
        if(accounts[index].accountLevel.Id == undefined)
        	accounts.splice(index, 1);
        component.set("v.accountLevelRows", accounts);
    },
    
    fetchChildrenRecords : function(component, event, helper){
        var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
        
        //Removing individual rows with BCAP_Individual_Level__c marked No
        for(var k=0; k<accounts.length; k++){
            if(accounts[k].accountLevel.BCAP_Individual_Level__c == 'N'){
                accounts[k].individualLevels = [];
            }
        }
        
        for (var j in accounts) {
            if(!accounts[j].accountLevel.BCAP_Is_Deleted__c || accounts[j].accountLevel.BCAP_Is_Deleted__c==undefined){
                accounts[j].accountLevel.BCAP_Vote__c = component.get("v.voteId");
            }
            else if(accounts[j].accountLevel.BCAP_Is_Deleted__c && accounts[j].accountLevel.Id==undefined){
                accounts[j].accountLevel.BCAP_Vote__c = null;
            }
            if(accounts[j].individualLevels.length && accounts[j].individualLevels.length>0){
                for(var k in accounts[j].individualLevels){
                    if(!accounts[j].individualLevels[k].BCAP_Is_Deleted__c  || accounts[j].individualLevels[k].BCAP_Is_Deleted__c==undefined){
                        accounts[j].individualLevels[k].BCAP_Vote__c = component.get("v.voteId");
                    }
                    else if(accounts[j].individualLevels[k].BCAP_Is_Deleted__c && accounts[j].individualLevels[k].Id==undefined) {
                        accounts[j].individualLevels[k].BCAP_Vote__c = null;
                    }
                }
            }
            if(accounts[j].individualLevels.length && accounts[j].individualLevels.length>0){
                for(var k in accounts[j].individualLevels){
                    if(accounts[j].individualLevels[k].BCAP_Is_Deleted__c && accounts[j].individualLevels[k].BCAP_Vote__c == null){
                        //Splice only if both account and individual levels are new and blank
                        accounts[j].individualLevels.splice(k,1);
                    } 
                }
            }
        }
        for(var j in accounts) {
            if(accounts[j].accountLevel.BCAP_Is_Deleted__c && accounts[j].accountLevel.BCAP_Vote__c == null){
                //Splice only if both account and individual levels are new and blank
                accounts.splice(j,1);
            } 
        }
        
        var voteId = component.get("v.voteId");
        var formattedJSON = helper.formatJson(accounts, voteId, component);
        console.log("Formatted Json : ", formattedJSON);
        console.log("Stringified Formatted Json : ", JSON.stringify(formattedJSON));
        if(helper.checkValidity(component)){
            helper.saveRecords(formattedJSON, component);
        }
    },
        
    checkContentRankValue: function(component, event, helper){
        var selectedValue = event.getParam("contentRankValue");
        var index =  event.getParam("accountLevelIndex");
        var preVal =  event.getParam("previousContentRankValue");
        var isKeyRankPresent = false;
        var accounts = component.get("v.accountLevelRows");
        for(var k=0; k<accounts.length; k++){
            var contentRank = accounts[k].accountLevel.BCAP_Content_Rank__c;
            var isDeleted = accounts[k].accountLevel.BCAP_Is_Deleted__c;
            if(k != index && !isDeleted) {
                if(contentRank == 'Key Rank' && selectedValue == 'Key Rank'){
                    isKeyRankPresent = true;
                    break;
                }
                if(contentRank == 'Key Rank' &&
                   (selectedValue == 'Key Rank US' || selectedValue == 'Key Rank UK')){
                    isKeyRankPresent = true;
                    break;
                }
                if(contentRank == 'Key Rank US' &&
                   (selectedValue == 'Key Rank US' || selectedValue == 'Key Rank')){
                    isKeyRankPresent = true;
                    break;
                }
                if(contentRank == 'Key Rank UK' &&
                   (selectedValue == 'Key Rank UK' || selectedValue == 'Key Rank')){
                    isKeyRankPresent = true;
                    break;
                }
                if((contentRank == 'Key Rank US' || contentRank == 'Key Rank UK') &&
                   selectedValue == 'Key Rank'){
                    isKeyRankPresent = true;
                    break;
                }
            }
            
        }
        if(isKeyRankPresent) {
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message", "Key Rank already selected!");
            appEvent.setParam("type", "error");
            appEvent.setParam("duration", "5000");                     
            appEvent.setParam("mode", "dismissible");
            appEvent.fire();
            var childrenAccounts = component.find("childrenAccounts");
            childrenAccounts[index].find("fieldIdContentRank").set("v.value",preVal);
            childrenAccounts[index].set("v.previousContentRankValue",preVal);
        }
    },
    showPerformanceMetricsDialog:function(component, event, helper){
        helper.updateHasValueForPerformanceMetrics(component);
        component.set("v.showOppMetricsDialog", true);
        var appEvent = $A.get("e.c:BV_changeZIndexEvent");
        appEvent.setParam("flag", true);
        appEvent.fire();
    },
        
    addNewAccountRow:function(component,event,helper){
        var row = {};
        var getIdPromise = helper.getExternalId(component);
        row.type = 'Account';
        row.BCAP_Is_Deleted__c = false;
        getIdPromise.then(function(id){
            row.BCAP_External_ID__c = id;
            var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
            accounts.push({'accountLevel':row,'individualLevels':[]});
            component.set("v.accountLevelRows", accounts);
        });
    },
    handleCustomDialogBoxEvent: function (component, event, helper) {
        var dialogType = event.getParam("dialogType");
        var actionType = event.getParam("actionType");
        if(dialogType === 'Performance Metrics') {
            if(actionType === 'No') {
                helper.closeModel(component, event);
            }
            if(actionType === 'Yes') {
                helper.applyChanges(component, event);
            }
        }
    }
})