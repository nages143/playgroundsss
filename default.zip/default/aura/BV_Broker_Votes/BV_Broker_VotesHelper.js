({
    saveRecords : function(totalRows, component) {
        component.set("v.showLoadingSpinner",true);
        
        var action1 = component.get("c.saveVoteDetailsDataWithJSON");
        action1.setParams({"params" : JSON.stringify(totalRows)});
        action1.setCallback(this, function(response){
            component.set("v.showLoadingSpinner",false);
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + JSON.stringify(response.getReturnValue()));
                if(response.getReturnValue().includes("Error")){
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Error saving records");
                    appEvent.setParam("type", "error");
                    appEvent.setParam("duration", "10000");                     
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire(); 
                }
                else {
                    component.set("v.voteId", response.getReturnValue()); 
                    
                    var hasAtleastOneAccount = false;
                    var hasAtleastOneIndividual = false;
                    var accountLevels = totalRows['accountLevels'];
                    var count = 0;
                    
                    for(var index=0;index<accountLevels.length;index++){
                        var acc = accountLevels[index];
                        if(acc !== undefined) {
                            hasAtleastOneAccount = true;
                            count += 1;
                        }
                        var individuals = acc['individualLevels'];
                        for(var index=0;index<individuals.length;index++){
                            var ind = individuals[index];
                            if(ind !== undefined) {
                                hasAtleastOneIndividual = true;
                                count += 1;
                                break;
                            }
                        }
                        if(count == 2) 
                            break;
                    }
                    var changeToInProgressEvent = component.getEvent("changeToInProgressEvent");
                    changeToInProgressEvent.setParams({"hasAtleastOneAccount":hasAtleastOneAccount,
                                                       "hasAtleastOneIndividual":hasAtleastOneIndividual
                                                      });
                    changeToInProgressEvent.fire();
                    
                    var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                    appEvent.setParam("message", "Records saved successfully");
                    appEvent.setParam("type", "success");
                    appEvent.setParam("duration", "3000");
                    appEvent.setParam("mode", "dismissible");
                    appEvent.fire();                      
                }
            }
        }); 
        
        $A.enqueueAction(action1);
    },
    
    getExternalId : function(component){
        return new Promise((function(resolve, reject){
            var action1 = component.get("c.bvGUID");
            var id = null;
            action1.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    id = response.getReturnValue();
                    resolve(id)
                }
                else{
                    reject(null)
                }
            });
            $A.enqueueAction(action1);          
        }));
    },
    
    formatJson : function(finalRows, voteId, component){
        var formattedList = [];
        var recordMap = JSON.parse(JSON.stringify(component.get("v.recordMap")));
        var buyingCenter = component.get("v.buyingCenter");
        var accountCaptures = component.get("v.accountCaptures");
        var individualCaptures = component.get("v.individualCaptures");
        var brokerVote = component.get("v.brokerVote");
        
        var temp={};
        for(var k=0; k<finalRows.length; k++){
            finalRows[k].accountLevel.RecordTypeId = recordMap[finalRows[k].accountLevel.type]; 
            delete finalRows[k].accountLevel.type; 
            delete finalRows[k].accountLevel.Parent_External_Id;
            if(finalRows[k].accountLevel.Contact__c){
                delete finalRows[k].accountLevel.Contact__c; 
            }
            if(finalRows[k].accountLevel.Employee__c){
                delete finalRows[k].accountLevel.Employee__c; 
            }
            if(finalRows[k].accountLevel.BCAP_Client_Region__r){
                delete finalRows[k].accountLevel.BCAP_Client_Region__r; 
            }
            if(finalRows[k].accountLevel.BCAP_Client_Asset_Class__r){
                delete finalRows[k].accountLevel.BCAP_Client_Asset_Class__r; 
            }
            if(finalRows[k].accountLevel.BCAP_Client_Service__r){
                delete finalRows[k].accountLevel.BCAP_Client_Service__r; 
            } 
            if(finalRows[k].accountLevel.BCAP_Voting_Team_Lookup__r){
                delete finalRows[k].accountLevel.BCAP_Voting_Team_Lookup__r; 
            }
            if(finalRows[k].individualLevels.length && finalRows[k].individualLevels.length>0){
                for(var j=0; j<finalRows[k].individualLevels.length;j++ ){
                    delete finalRows[k].individualLevels[j].Parent_External_Id;
                    finalRows[k].individualLevels[j].RecordTypeId = recordMap[finalRows[k].individualLevels[j].type]; 
                    delete finalRows[k].individualLevels[j].type; 
                    if(finalRows[k].individualLevels[j].Contact__c){
                        delete finalRows[k].individualLevels[j].Contact__c; 
                    }
                    if(finalRows[k].individualLevels[j].Employee__c){
                        delete finalRows[k].individualLevels[j].Employee__c; 
                    }
                    finalRows[k].individualLevels[j].BCAP_Revenue_Currency__c = finalRows[k].accountLevel.BCAP_Data_AUM_Currency__c;
                }
            }
            finalRows[k].accountLevel.BCAP_Data_Payment_Currency__c = finalRows[k].accountLevel.BCAP_Data_AUM_Currency__c;
            finalRows[k].accountLevel.BCAP_Data_Wallet_Currency__c = finalRows[k].accountLevel.BCAP_Data_AUM_Currency__c;
            /*temp = {"voteDetail" : finalRows[k],
                        "Parent_External_Id" : finalRows[k].Parent_External_Id
                       };
            	delete finalRows[k].Parent_External_Id;
            	formattedList.push(temp); */
        }
        var formattedJSON = {"vote" : {"Id": voteId,
                                       "BCAP_Buying_Centre__c":buyingCenter.Id,
                                       "BCAP_Account_Level_Status_EU__c":brokerVote.BCAP_Account_Level_Status_EU__c,
                                       "BCAP_Account_Level_Status_US__c":brokerVote.BCAP_Account_Level_Status_US__c,
                                       "BCAP_Individual_Level_Status_EU__c":brokerVote.BCAP_Individual_Level_Status_EU__c,
                                       "BCAP_Individual_Level_Status_US__c":brokerVote.BCAP_Individual_Level_Status_US__c},
                             "accountLevels" : finalRows,
                             "accountCaptures":accountCaptures,
                             "individualCaptures":individualCaptures};
        return formattedJSON;
    },
    
    getRecordTypeId : function(type, component){
        return new Promise((function(resolve, reject){
            var action = component.get("c.getRecordTypeIdByName");
            var recordType;
            if(type == 'Account'){
                recordType = 'Account Level';
            }
            else if(type == 'Overall detail only'){
                recordType = 'Overall Level';
            }
                else if(type == 'Sector / Industry detail'){
                    recordType = 'Sector Level';
                }
                    else if(type == 'Voter detail'){
                        recordType = 'Voter Level';
                    }
            action.setParams({
                "objAPIName" : "BCAP_Vote_Detail__c",
                "recordTypeName" : recordType
            });
            action.setCallback(this, function(response){
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    resolve(response.getReturnValue());
                }
            }); 
            $A.enqueueAction(action); 
        }));          
    },
    
    showSuccessToast : function(component) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type": "success",
            "message": "The record has been updated successfully."
        });
        toastEvent.fire();
    },
    
    showErrorToast : function(component) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Error!",
            "type": "error",
            "message": "Failed to save records"
        });
        toastEvent.fire();
    },
    
    checkValidity : function(component){
        var childrenAccounts = component.find("childrenAccounts");
        var field;
        var isValid = true;
        var errorField = "";
        if(childrenAccounts.length == undefined){
            field = childrenAccounts.find("fieldIdRegion");
            isValid = field.checkValidity();
            if(!isValid) 
                errorField = "Region";
            if(isValid){
                field = childrenAccounts.find("fieldIdAC");
                isValid = field.checkValidity();
                if(!isValid) 
                    errorField = "Asset Class";
            }
            if(isValid){
                field = childrenAccounts.find("fieldIdService");
                isValid = field.checkValidity();    
                if(!isValid) 
                    errorField = "Service";                
            }
            if(isValid){
                field = childrenAccounts.find("fieldIdHasIndividualRows");
                isValid = field.checkValidity(); 
                if(!isValid) 
                    errorField = "Has Individual Rows";
            }
            if(isValid){
                field = childrenAccounts.find("fieldIdIndividualRowType");
                isValid = field.checkValidity();
                if(!isValid) 
                    errorField = "Basis of individual level detail";
            }
            if(isValid){
                field = childrenAccounts.find("fieldIdNotes");
                isValid = field.checkValidity();   
                if(!isValid) 
                    errorField = "Interpretation Notes";
            } 
        } 
        else if(isValid){
            for(var i=0; i<childrenAccounts.length; i++) {
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdRegion");
                    isValid = field.checkValidity();
                    if(!isValid) 
                        errorField = "Region";
                }
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdAC");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Asset class";
                }
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdService");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Service";
                }
               /* if(isValid){
                    field = childrenAccounts[i].find("tdAccIdOppAUM");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Opp-AUM";
                }
                if(isValid){
                    field = childrenAccounts[i].find("tdAccIdOppWallet");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Opp-Wallet";
                }
                if(isValid){
                    field = childrenAccounts[i].find("tdAccIdOppPayment");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Opp-Payment";
                }
                if(isValid){
					field = childrenAccounts[i].find("fieldIdContentRank");
     	        	isValid = field.checkValidity();  
                    if(!isValid) 
                    	errorField = "Content Rank";
                }*/
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdHasIndividualRows");
                    isValid = field.checkValidity(); 
                    if(!isValid) 
                        errorField = "Has Individual Rows";
                }
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdIndividualRowType");
                    isValid = field.checkValidity();  
                    if(!isValid) 
                        errorField = "Basis of individual level detail";         
                }
                if(isValid){
                    field = childrenAccounts[i].find("fieldIdNotes");
                    isValid = field.checkValidity();   
                    if(!isValid) 
                        errorField = "Interpretation Notes"; 
                }
                if(isValid){
                    //segregate for single valued grandchild and array
                    var childFields = childrenAccounts[i].find("grandChildren");
                    if(childFields != undefined && childFields.length == undefined && isValid){
                        field = childFields.find("employeeChild");
                        var value = field.get("v.selectedRecord.Name");
                        if(value == null){
                            isValid = false;
                            errorField = "Individual Level - Full Name";  
                        }
                    }
                    else if(childFields != undefined && childFields.length>0 && isValid){
                        var error = false;
                        for(var k=0;k<childFields.length; k++){
                            if(isValid){
                                field = childFields[k].find("normalizedRecordTable");
                                if(field) {
                                    isValid = true;
                                }
                                else{
                                    field = childFields[k].find("employeeChild");
                                    var value = field.get("v.selectedRecord.Name");
                                    if(value == null){
                                        isValid = false;
                                        error = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if(error)
                            errorField = "Individual Level - Full Name";
                    }
                    if(childFields != undefined && childFields.length == undefined && isValid){
                        field = childFields.find("fieldIdFunction");
                        isValid = field.checkValidity();
                        if(!isValid) 
                            errorField = "Individual Level - Function";  
                    }
                    else if(childFields != undefined && childFields.length>0 && isValid){
                        var error = false;
                        for(var k=0;k<childFields.length; k++){
                            if(isValid){
                                field = childFields[k].find("normalizedRecordTable");
                                if(field) {
                                    isValid = true;
                                }
                                else{
                                    field = childFields[k].find("fieldIdFunction");
                                    isValid = field.checkValidity();
                                    if(!isValid) {
                                        error = true;
                                        break;
                                    } 
                                }
                            }
                        }
                        if(error)
                            errorField = "Individual Level - Function";
                    }
                    if(childFields != undefined && childFields.length == undefined && isValid){
                        field = childFields.find("fieldIdSector");
                        isValid = field.checkValidity();
                        if(!isValid) 
                            errorField = "Individual Level - Sector";  
                    }
                    else if(childFields != undefined && childFields.length>0 && isValid){
                        var error = false;
                        for(var k=0;k<childFields.length; k++){
                            if(isValid){
                                field = childFields[k].find("normalizedRecordTable");
                                if(field) {
                                    isValid = true;
                                }
                                else{
                                    field = childFields[k].find("fieldIdSector");
                                    isValid = field.checkValidity();
                                    if(!isValid) {
                                        error = true;
                                        break;
                                    }
                            	}
                            }
                        }
                        if(error)
                            errorField = "Individual Level - Sector";
                    }
                    if(childFields != undefined && childFields.length == undefined && isValid){
                        field = childFields.find("fieldIdPCL");
                        isValid = field.checkValidity();
                        if(!isValid) 
                            errorField = "Individual Level - PCL";  
                    }
                    else if(childFields != undefined && childFields.length>0 && isValid){
                        var error = false;
                        for(var k=0;k<childFields.length; k++){
                            if(isValid){
                                field = childFields[k].find("normalizedRecordTable");
                                if(field) {
                                    isValid = true;
                                }
                                else{
                                    field = childFields[k].find("fieldIdPCL");
                                    isValid = field.checkValidity();
                                    if(!isValid) {
                                        error = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if(error)
                            errorField = "Individual Level - PCL";
                    }
                    
                    if(childFields != undefined && childFields.length == undefined && isValid){
                        field = childFields.find("contactChild");
                        var value = field.get("v.selectedRecord.Name");
                        if(value == null){
                            isValid = false;
                            errorField = "Individual Level - Voter Name";
                        }
                    }
                    else if(childFields != undefined && childFields.length>0 && isValid){
                        var error=false;
                        for(var k=0;k<childFields.length; k++){
                            if(isValid){
                                field = childFields[k].find("normalizedRecordTable");
                                if(field) {
                                    isValid = true;
                                }
                                else{
                                    field = childFields[k].find("contactChild");
                                    var value = field.get("v.selectedRecord.Name");
                                    if(value == null){
                                        isValid = false;
                                        error = true;
                                        break;
                                    }
                                }
                            }
                            
                        }
                        if(error)
                            errorField = "Individual Level - Voter Name";
                    }	
                }
            }
        }
        if(!isValid) {
            var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
            appEvent.setParam("message", "Please fill mandatory fields: "+errorField);
            appEvent.setParam("type", "error");
            appEvent.setParam("duration", "10000");                     
            appEvent.setParam("mode", "dismissible");
            appEvent.fire();
        }
        return isValid;
    },
    controlVisibility : function(component) {
        var accountCaptures = component.get("v.accountCaptures");
        var individualCaptures = component.get("v.individualCaptures");
        var appEvent = $A.get("e.c:BV_performanceMetricsChangeEvent");
        appEvent.setParam("accountCaptures", accountCaptures);
        appEvent.setParam("individualCaptures", individualCaptures);
        appEvent.fire(); 
    },
    updateHasValueForPerformanceMetrics : function(component){
        var accountCaptures = component.get("v.accountCaptures");
        var individualCaptures = component.get("v.individualCaptures");
        var accounts = JSON.parse(JSON.stringify(component.get("v.accountLevelRows")));
        
        var accCaps = [false,false,false,false,false,false,false,false,false];
        var indCaps = [false,false,false,false,false,false,false,false];
        for (var j in accounts) {
            var acc = accounts[j].accountLevel;
            if(acc.BCAP_Data_Tier__c!=undefined && acc.BCAP_Data_Tier__c!=''){
                accCaps[0] = true;}
            if(acc.BCAP_Data_Rank__c!=undefined && acc.BCAP_Data_Rank__c!=''){
                accCaps[1] = true;}
            if(acc.BCAP_Data_Points__c!=undefined && acc.BCAP_Data_Points__c!=''){
                accCaps[2] = true;}
            if(acc.BCAP_Data_Market_Share__c!=undefined && acc.BCAP_Data_Market_Share__c!=''){
                accCaps[3] = true;}
            if(acc.BCAP_Data_Wallet__c!=undefined && acc.BCAP_Data_Wallet__c!=''){
                accCaps[4] = true;}
            if(acc.BCAP_Data_Payment__c!=undefined && acc.BCAP_Data_Payment__c!=''){
                accCaps[5] = true;}
            if(acc.BCAP_Data_Relative_Rank__c!=undefined && acc.BCAP_Data_Relative_Rank__c!=''){
                accCaps[6] = true;}
            if(acc.BCAP_Data_Grade__c!=undefined && acc.BCAP_Data_Grade__c!=''){
                accCaps[7] = true;}
            if(acc.BCAP_Comments__c!=undefined && acc.BCAP_Comments__c!=''){
                accCaps[8] = true;}
            
            var individuals = accounts[j].individualLevels;
            if(individuals.length && individuals.length>0){
                for(var k in individuals){
                    var isNormRecord = individuals[k].Is_Normalization_Rollup_Record__c;
                    if(!isNormRecord && individuals[k].BCAP_Data_Tier__c!=undefined && individuals[k].BCAP_Data_Tier__c!=''){
                        indCaps[0] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Data_Rank__c!=undefined && individuals[k].BCAP_Data_Rank__c!=''){
                        indCaps[1] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Data_Points__c!=undefined && individuals[k].BCAP_Data_Points__c!=''){
                        indCaps[2] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Data_Payment__c!=undefined && individuals[k].BCAP_Data_Payment__c!=''){
                        indCaps[3] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Data_Relative_Rank__c!=undefined && individuals[k].BCAP_Data_Relative_Rank__c!=''){
                        indCaps[4] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Data_Grade__c!=undefined && individuals[k].BCAP_Data_Grade__c!=''){
                        indCaps[5] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Comments__c!=undefined && individuals[k].BCAP_Comments__c!=''){
                        indCaps[6] = true;}
                    if(!isNormRecord && individuals[k].BCAP_Other_Quantative_Data__c!=undefined && individuals[k].BCAP_Other_Quantative_Data__c!=''){
                        indCaps[7] = true;}
                }
            }
        }
        for(var i in accCaps) {
            accountCaptures[i].hasValue = accCaps[i];
        }
        for(var i in indCaps) {
            individualCaptures[i].hasValue = indCaps[i];
        }
        component.set("v.accountCaptures",accountCaptures);
        component.set("v.individualCaptures",individualCaptures);
    },
    applyChanges:function(component, event){
        var accountCaptures = component.get("v.accountCaptures");
        var previousAccountCaptures = [];
        for(var i=0;i<accountCaptures.length;i++) {
            previousAccountCaptures.push({"isVisible": accountCaptures[i].isVisible,
                                          "hasValue": accountCaptures[i].hasValue,
                                          "colName": accountCaptures[i].colName});
        }
        if(previousAccountCaptures.length != 0)
        	component.set("v.previousAccountCaptures",previousAccountCaptures);
        var individualCaptures = component.get("v.individualCaptures");
        var previousIndividualCaptures = [];
        for(var i=0;i<individualCaptures.length;i++) {
            previousIndividualCaptures.push({"isVisible": individualCaptures[i].isVisible,
                                             "hasValue": individualCaptures[i].hasValue,
                                             "colName": individualCaptures[i].colName});
        }
        if(previousIndividualCaptures.length != 0)
            component.set("v.previousIndividualCaptures",previousIndividualCaptures);
        
        this.controlVisibility(component);
        var appEvent = $A.get("e.c:BV_changeZIndexEvent");
        appEvent.setParam("flag", false);
        appEvent.fire();
        component.set("v.showOppMetricsDialog", false);
    },
    closeModel:function(component, event, helper){
        var previousAccountCaptures = component.get("v.previousAccountCaptures");
        var accountCaptures = [];
        for(var i=0;i<previousAccountCaptures.length;i++) {
            accountCaptures.push({"isVisible": previousAccountCaptures[i].isVisible,
                                  "hasValue": previousAccountCaptures[i].hasValue,
                                  "colName": previousAccountCaptures[i].colName});
        }
        if(accountCaptures.length != 0)
        	component.set("v.accountCaptures",accountCaptures);
        var previousIndividualCaptures = component.get("v.previousIndividualCaptures");
        var individualCaptures = [];
        for(var i=0;i<previousIndividualCaptures.length;i++) {
            individualCaptures.push({"isVisible": previousIndividualCaptures[i].isVisible,
                                     "hasValue": previousIndividualCaptures[i].hasValue,
                                     "colName": previousIndividualCaptures[i].colName});
        }
        if(individualCaptures.length != 0)
        	component.set("v.individualCaptures",individualCaptures);
        
        this.controlVisibility(component);
        var appEvent = $A.get("e.c:BV_changeZIndexEvent");
        appEvent.setParam("flag", false);
        appEvent.fire();
        component.set("v.showOppMetricsDialog", false);
        
    }

    
})