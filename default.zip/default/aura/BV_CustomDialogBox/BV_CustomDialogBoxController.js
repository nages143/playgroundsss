({
	init : function(component, event, helper) {
        var labelNo =  component.get("v.labelNo");
        var labelYes =  component.get("v.labelYes");
        component.find("buttonNo").set("v.title", labelNo);
        component.find("buttonNo").set("v.label", labelNo);
        
        if(component.get("v.dialogType") != 'View Flashed Email' && component.get("v.dialogType") != 'Allocation Method Read Only'){
            component.find("buttonYes").set("v.title", labelYes);
            component.find("buttonYes").set("v.label", labelYes);
        }
	},
    actionNo : function(component, event, helper) {
        var appEvent = $A.get("e.c:BV_CustomDialogBoxEvent");
        appEvent.setParam("dialogType", component.get("v.dialogType"));
        appEvent.setParam("actionType", "No");
        appEvent.fire();
	},
    actionYes : function(component, event, helper) {
        var appEvent = $A.get("e.c:BV_CustomDialogBoxEvent");
        appEvent.setParam("dialogType", component.get("v.dialogType"));
        appEvent.setParam("actionType", "Yes");
        appEvent.fire();
	}
})