({
	// show toast event handler
	handleShowToastEvent : function(cmp, event, helper) {
	
		// get event parameters
		var message = event.getParam("message");
        var type = event.getParam("type");
        var duration = event.getParam("duration");
        var mode = event.getParam("mode");
        var details = event.getParam("details");
              
        // set duration if null
        if(duration==null || duration==undefined){
        	duration=5000;
        }     
        
        // set mode if null
        if(mode==null || mode==undefined){
        	mode='dismissible';
        }
        
        // set attributes
        cmp.set("v.message", message);
        cmp.set("v.type", type);
        cmp.set("v.mode", mode);
        cmp.set("v.details", details);
        cmp.set("v.showToast", true);
        
        // if mode is sticky, remains visible until you press the close buttons.
        if(mode != 'sticky') {
           var close = function(){
        	    cmp.set("v.message", '');
		        cmp.set("v.type", '');
		        cmp.set("v.mode", '');
		        cmp.set("v.details", '');
		        cmp.set("v.showToast", false);
            }
           setTimeout(close, duration);
        }   
		
	},
	
	// close button click handler
	closeClicked : function(cmp, event, helper) {
	
		// reset attributes
        cmp.set("v.message", '');
        cmp.set("v.type", '');
        cmp.set("v.mode", '');
        cmp.set("v.details", '');
        cmp.set("v.showToast", false);
	
	}
})