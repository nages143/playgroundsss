({
    init: function (component, event, helper) {
        
            var voteId = component.get("v.mainVoteId");
            if(voteId != null) {
                var action = component.get("c.getVoteDetailsDataWithJSON"); 
                action.setParams({
                    "voteId" : voteId
                });
                action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var brokerVoteResponse = JSON.parse(response.getReturnValue());
                    var vote = brokerVoteResponse["vote"];
                    var voteDetails = brokerVoteResponse["accountLevels"];
                    var flashDetails = brokerVoteResponse["flashDetails"];
                    var ranks = brokerVoteResponse["ranks"];
                    var trailingVoteRanks = brokerVoteResponse["trallingVoteRanks"];
                    
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
        		
                    var keyRank = []
                    var addRank = []
                    for (var i = 0; i < ranks.length; i++) {
                    	var rank = ranks[i];
                        rank['overallRank'] = parseInt(rank['overallRank'] );
                        rank['preOverallRank'] = parseInt(rank['preOverallRank'] );
                        if(rank["rankType"] === "Key Rank")
                            keyRank.push(rank);
                        else 
                            addRank.push(rank);
                	}
                    
                    var accountManager = {};
                    var wallet = {};
                    var share = {};
                    var clientTier = {};
                    
                    if(flashDetails != null) {
                        if (flashDetails["clientTier"] !=null) {
                            if(flashDetails["clientTier"][0] != null) {
                                var clientTier0 = flashDetails["clientTier"][0];
                                clientTier[clientTier0['region']] = clientTier0['tier'];
                            }
                            if(flashDetails["clientTier"][1] != null) {
                                var clientTier1 = flashDetails["clientTier"][1];
                                clientTier[clientTier1['region']] = clientTier1['tier'];
                            }
                        }
                        if (flashDetails["coverage"] !=null) {
                            if(flashDetails["coverage"][0] != null) {
                                var coverage0 = flashDetails["coverage"][0];
                                accountManager[coverage0['region']] = coverage0['accountManager'];
                            }
                            if(flashDetails["coverage"][1] != null) {
                                var coverage1 = flashDetails["coverage"][1];
                                accountManager[coverage1['region']] = coverage1['accountManager'];
                            }
                        }   
                        if (flashDetails["mcLaganData"] !=null) {
                            if(flashDetails["mcLaganData"][0] != null) {
                                var mcLaganData0 = flashDetails["mcLaganData"][0];
                                wallet[mcLaganData0['region']] = ((parseFloat(mcLaganData0['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData0['region']] = ((parseFloat(mcLaganData0['share'])) * 100).toFixed(2) + '%';
                            }
                            if(flashDetails["mcLaganData"][1] != null) {
                                var mcLaganData1 = flashDetails["mcLaganData"][1];
                                wallet[mcLaganData1['region']] = ((parseFloat(mcLaganData1['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData1['region']] = ((parseFloat(mcLaganData1['share'])) * 100).toFixed(2) + '%';
                            }
                            if(flashDetails["mcLaganData"][2] != null) {
                                var mcLaganData2 = flashDetails["mcLaganData"][2];
                                wallet[mcLaganData2['region']] = ((parseFloat(mcLaganData2['wallet'])) / 1000000).toFixed(2) + 'm';
                                share[mcLaganData2['region']] = ((parseFloat(mcLaganData2['share'])) * 100).toFixed(2) + '%';
                            }
                        }
                    }
                    var url = new URL(window.location.href);
        			var urlString = encodeURI(url);
        			//var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
        			//redirectUrl = redirectUrl + '/BVLanding.app';
                    
                    var redirectUrl = 'http://teams.barclays.intranet/sites/emeaequitiesclientstrategy/Shared%20Documents/Forms/AllItems.aspx?RootFolder=%2fsites%2femeaequitiesclientstrategy%2fShared%20Documents%2fClient%20Vote%20Files&FolderCTID=0x0120006C987036CAB3164D99A9F56BC9FADDF5';
                    
                    component.set("v.vote",vote);                
                    component.set("v.voteDetails",voteDetails);
                    component.set("v.accountManager",accountManager);
                    component.set("v.wallet",wallet);
                    component.set("v.share",share);
                    component.set("v.clientTier",clientTier);
                    component.set("v.keyRank",keyRank);
                    component.set("v.additionalRank",addRank);
                    component.set("v.BVUrl",redirectUrl);
                    component.set("v.trailingVoteRanks",trailingVoteRanks);
                    helper.initDocuments(component,event,helper);
                }
            });
            $A.enqueueAction(action);
            }
	},
    
})