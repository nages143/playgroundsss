({
	initDocuments: function(component, event, helper) {
        var voteId = component.get("v.mainVoteId");
        if(voteId != null) {
            var action = component.get("c.getDocuments"); 
            action.setParams({
                "voteId" : voteId
            });
            action.setCallback(this, function(response) {
                var result = response.getReturnValue();
                component.set("v.listOfDocuments", result);                
                component.set("v.totalDocuments", result.length);
                this.doInit(component,event,helper);
            });
            $A.enqueueAction(action);
        }
    },
    doInit : function(component,event,helper) {
        
        var data=[];
        var votePeriods = [];
        var i=0;
        var trailingVoteRanks = component.get("v.trailingVoteRanks");
        for(i=0; i<trailingVoteRanks.length;i++) {
            data.push({"y":trailingVoteRanks[i].rank, "name":"key"+i });
            votePeriods.push(trailingVoteRanks[i].year+' '+trailingVoteRanks[i].quarter.substring(0,2));
        }
        
        component.set("v.data",JSON.stringify(data));  
        component.set("v.xAxisCategories",votePeriods);  
        component.set("v.documentViewUrl",$A.get("$Label.c.brokerVoteGetActiveStoreURI"));
        this.Linechart(component,event,helper);
	},
    
    Linechart : function(component,event,helper) {
        var jsonData = component.get("v.data");
        var dataObj = JSON.parse(jsonData);
        
        var chart = new Highcharts.Chart({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                renderTo: component.find("linechart").getElement(),
                type: 'line'
            },
            title: {
				text: ''
			},
            xAxis: {
                categories: component.get("v.xAxisCategories"),
                opposite:true,
            },
            yAxis: {
                min:0,
                opposite:true,
                reversed:true,
                title: 
                {
                    text: ''
                }
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true
                    },
                    enableMouseTracking: false
                }
            },
            exporting:{
            	enabled:false        
        	},
            series: [{
                showInLegend:false,
                name:'Rank',
                data:dataObj,
                events: {
                        legendItemClick: function(e) {
                            e.preventDefault()
            	}
            }         
        }]
            
        });
       
		var jpg = chart.getSVGForExport({type:"image/jpeg"});
        //console.log(jpg);
        var appEvent = $A.get("e.c:BV_saveGraphCodeEvent");
        appEvent.setParams({
            "graphcode": jpg
        });
       appEvent.fire(); 
    },
    
})