({
    customInit : function(component, event, helper){
        var voterDetailRecord = JSON.parse(JSON.stringify(component.get("v.voterDetailRecord")));
        var tableType = component.get("v.tableType");
        var rowIndex = JSON.stringify(component.get("v.rowIndex"));
        var childKey = tableType.concat(rowIndex);
       
        var action3 = component.get("c.getSector");
        action3.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfSector = [];
                console.log("From server sector: " + JSON.stringify(response.getReturnValue()));
                var sector = response.getReturnValue();
                listOfSector.push({'label' :'Select' , 'value':null});
                for(var i=0;i<sector.length; i++){
                    listOfSector.push({'label' :sector[i] , 'value':sector[i]});
                } 
                component.set("v.sectors", listOfSector);
                //component.find("fieldIdSector").set("v.value", listOfSector[0].value);
            }
        }); 
        
        var action1 = component.get("c.getFunctions");
        action1.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfFunctions = [];
                console.log("From server functionValues: " + JSON.stringify(response.getReturnValue()));
                var functionValues = response.getReturnValue();
                listOfFunctions.push({'label' :'Select' , 'value':null});
                for(var i=0;i<functionValues.length; i++){
                    listOfFunctions.push({'label' :functionValues[i] , 'value':functionValues[i]});
                } 
                component.set("v.functionValues", listOfFunctions);
                //component.find("fieldIdFunction").set("v.value", listOfFunctions[0].value);
            }
        });
        var action2 = component.get("c.getPCLValues");
        action2.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfPCL = [];
                console.log("From server PCL Values: " + JSON.stringify(response.getReturnValue()));
                var pcl = response.getReturnValue();
                listOfPCL.push({'label' :'Select' , 'value':null});
                for(var i=0;i<pcl.length; i++){
                    listOfPCL.push({'label' :pcl[i] , 'value':pcl[i]});
                } 
                component.set("v.PCLValues", listOfPCL);
                //component.find("fieldIdPCL").set("v.value", listOfPCL[0].value);
            }
        }); 
        
        var action5 = component.get("c.getRank");
        action5.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfDataRank = [];
                console.log("From server region: " + JSON.stringify(response.getReturnValue()));
                var ranks = response.getReturnValue();
                listOfDataRank.push({'label' :'Select' , 'value':null});
                for(var i=0;i<ranks.length; i++){
                    listOfDataRank.push({'label' :ranks[i] , 'value':ranks[i]});
                } 
                component.set("v.dataRanks", listOfDataRank);
                //component.find("fieldIdDataRank").set("v.value", listOfDataRank[0].value);
            }
        }); 
        
        var action6 = component.get("c.getRelativeRank");
        action6.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var listOfDataRelativeRank = [];
                console.log("From server Relative Rank: " + JSON.stringify(response.getReturnValue()));
                var dataRelativeRank = response.getReturnValue();
                listOfDataRelativeRank.push({'label' :'Select' , 'value':null});
                for(var i=0;i<dataRelativeRank.length; i++){
                    listOfDataRelativeRank.push({'label' :dataRelativeRank[i] , 'value':dataRelativeRank[i]});
                } 
                component.set("v.dataRelativeRank", listOfDataRelativeRank);
            }
        });
         $A.enqueueAction(action1);
        $A.enqueueAction(action2);
        $A.enqueueAction(action3); 
        $A.enqueueAction(action5);
        $A.enqueueAction(action6);
      
       
        var detailRecord = JSON.parse(JSON.stringify(component.get("v.voterDetailRecord")));
        
        var tableType = component.get("v.tableType");
        console.log(detailRecord);
        var hasDataValues = false;
        if(tableType == 'Overall detail only'){
            if(detailRecord.BCAP_Comments__c !== '' && detailRecord.BCAP_Comments__c !== undefined && detailRecord.BCAP_Comments__c !== null){
                hasDataValues = true;
            }
        }
        else{
            if(detailRecord.BCAP_Data_Tier__c !== '' && detailRecord.BCAP_Data_Tier__c !== undefined && detailRecord.BCAP_Data_Tier__c !== null){
                hasDataValues = true;
            }
            else if(detailRecord.BCAP_Data_Rank__c !== '' && detailRecord.BCAP_Data_Rank__c !== undefined && detailRecord.BCAP_Data_Rank__c !== null){
                hasDataValues = true;
            }
                else if(detailRecord.BCAP_Data_Points__c !== '' && detailRecord.BCAP_Data_Points__c !== undefined && detailRecord.BCAP_Data_Points__c !== null){
                    hasDataValues = true;
                }
                    else if(detailRecord.BCAP_Data_Payment__c !== '' && detailRecord.BCAP_Data_Payment__c !== undefined && detailRecord.BCAP_Data_Payment__c !== null){
                        hasDataValues = true;
                    }
                        else if(detailRecord.BCAP_Data_Relative_Rank__c !== '' && detailRecord.BCAP_Data_Relative_Rank__c !== undefined && detailRecord.BCAP_Data_Relative_Rank__c !== null){
                            hasDataValues = true;
                        }
                            else if(detailRecord.BCAP_Data_Grade__c !== '' && detailRecord.BCAP_Data_Grade__c !== undefined && detailRecord.BCAP_Data_Grade__c !== null){
                                hasDataValues = true;
                            }
                                else if(detailRecord.BCAP_Comments__c !== '' && detailRecord.BCAP_Comments__c !== undefined && detailRecord.BCAP_Comments__c !== null){
                                    hasDataValues = true;
                                }
                                    else{
                                        hasDataValues = false;
                                    }
        }
        component.set("v.haveDataValues",hasDataValues);
        
        if(detailRecord.BCAP_Billable_Hours__c == null || detailRecord.BCAP_Billable_Hours__c == '') {
            detailRecord.BCAP_Billable_Hours__c = 0.00;
        }
        else{
            detailRecord.BCAP_Billable_Hours__c = parseFloat(detailRecord.BCAP_Billable_Hours__c).toFixed(2);
        }
        if(detailRecord.BCAP_Data_Payment__c == null || detailRecord.BCAP_Data_Payment__c == '') {
            detailRecord.BCAP_Data_Payment__c = 0.00;
        }
        else{
            detailRecord.BCAP_Data_Payment__c = parseFloat(detailRecord.BCAP_Data_Payment__c).toFixed(2);
        }
        if(detailRecord.BCAP_Data_Points__c == null || detailRecord.BCAP_Data_Points__c == '') {
            detailRecord.BCAP_Data_Points__c = 0.00;
        }
        else{
            detailRecord.BCAP_Data_Points__c = parseFloat(detailRecord.BCAP_Data_Points__c).toFixed(2);
        }
        if(detailRecord.BCAP_Total_Hours_Ex_Corp_Access__c == null || detailRecord.BCAP_Total_Hours_Ex_Corp_Access__c == '') {
            detailRecord.BCAP_Total_Hours_Ex_Corp_Access__c = 0.00;
        }
        else{
            detailRecord.BCAP_Total_Hours_Ex_Corp_Access__c = parseFloat(detailRecord.BCAP_Total_Hours_Ex_Corp_Access__c).toFixed(2);
        }
        if(detailRecord.BCAP_Revenue__c == null || detailRecord.BCAP_Revenue__c == '') {
            detailRecord.BCAP_Revenue__c = 0.00;
        }
        else{
            detailRecord.BCAP_Revenue__c = parseFloat(detailRecord.BCAP_Revenue__c).toFixed(2);
        }
        
        component.set("v.voterDetailRecord", detailRecord);
        
    }, 
    
    addNewRow : function(component, event, helper) {
        var appEvent = component.getEvent("addIndividualLevelRow");
        var row = {};
        var getIdPromise = helper.getExternalId(component);
        //row.BCAP_External_ID__c = component.get("v.tableType") + (component.get("v.rowIndex") + 1);
        row.type = component.get("v.tableType");
        row.Parent_External_Id = component.get("v.Parent_External_Id");
        row.BCAP_Is_Deleted__c = false;
        row.BCAP_Sector__c = 'Select';
        getIdPromise.then(function(id){
            row.BCAP_External_ID__c = id; 
            appEvent.setParam("row", row);
            appEvent.fire(); 
        });
    },
    
    addRow : function(component, event, helper) {
        var appEvent = component.getEvent("addIndividualLevelRow");
        var row = JSON.parse(JSON.stringify(component.get("v.voterDetailRecord")));
        var getIdPromise = helper.getExternalId(component);
        //row.BCAP_External_ID__c = component.get("v.tableType") + (component.get("v.rowIndex") + 1);
        row.type = component.get("v.tableType");
        row.Parent_External_Id = component.get("v.Parent_External_Id");
        row.BCAP_Is_Deleted__c = false;
        row.Id = null;
       //row.CreatedById = null;
        //row.CreatedDate = null;
        //row.IsDeleted = null;
        //row.LastModifiedById = null;
       // row.LastModifiedDate = null;
       // row.LastReferencedDate = null;
       // row.LastViewedDate = null;
       // row.Name = null;
        //row.OwnerId = null;
       // row.SystemModstamp = null;
        getIdPromise.then(function(id){
            row.BCAP_External_ID__c = id; 
            appEvent.setParam("row", row);
            appEvent.fire(); 
        });
    },
    
    
    deleteRow : function(component, event, helper){
        var index = component.get("v.rowIndex");
        var appEvent = component.getEvent("deleteIndividualLevelRow");
        appEvent.setParam("rowIndex", index);
        appEvent.fire();
    },
    
    handleComponentEvent : function(component, event, helper){
        var selectedContact = event.getParam("recordByEvent");
        component.set("v.voterDetailRecord.Contact__c.Name", selectedContact.Name);
        component.set("v.voterDetailRecord.Contact__c.Email", selectedContact.Email);
        component.set("v.voterDetailRecord.BCAP_Contact__c", selectedContact.Id);
        component.set("v.voterDetailRecord.BCAP_PCL__c", selectedContact.PCL_Contact_Temp__c);
        helper.validateEmail(component);
    },
    
    handleEmployeeComponentEvent : function(component, event, helper){
        var selectedEmployee = event.getParam("recordByEvent");
        component.set("v.voterDetailRecord.Employee__c.Name", selectedEmployee.Name);
        component.set("v.voterDetailRecord.Employee__c.BCAP_External_ID__c", selectedEmployee.BCAP_External_ID__c);
        component.set("v.voterDetailRecord.BCAP_Employee__c", selectedEmployee.Id);
        component.set("v.voterDetailRecord.BCAP_Function__c",selectedEmployee.BCAP_Function__c);
        component.set("v.voterDetailRecord.BCAP_Sector__c",selectedEmployee.BCAP_Sector__c);
        helper.validateBrid(component);
        helper.validateFunctionField(component);
        helper.validateSectorField(component);
    },
    validateFunction: function(component, event, helper){
        helper.validateFunctionField(component);
    },
    validateSector : function(component, event, helper){
        helper.validateSectorField(component);
    },
    validatePCL: function(component, event, helper){
        helper.validatePCLField(component);
    },
    validateDataRank : function(component, event, helper){
        helper.validateDataRankField(component);
    },
    
    validateRank : function(component, event, helper){
        var rank = component.get("v.voterDetailRecord.BCAP_Rank__c"); 
        var inputCmp = component.find("fieldIdRank");
        if(rank == null || rank == ''){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
            inputCmp.showHelpMessageIfInvalid();
        } 
        else if(rank != null || rank != ''){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        } 
    },
    
    validateNotes : function(component, event, helper){
        var notes = component.get("v.voterDetailRecord.BCAP_Notes__c"); 
        var inputCmp = component.find("fieldIdNotes");
        if(notes == null || notes == ''){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
            inputCmp.showHelpMessageIfInvalid();
        } 
        else if(notes != null || notes != ''){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        } 
    },
    handleDataChange: function(component, event, helper){
        var enteredValue = event.getParam("value");
        var haveDataValues = component.get("v.haveDataValues");
        var detailRecord = JSON.parse(JSON.stringify(component.get("v.voterDetailRecord")));
        var tableType = component.get("v.tableType");
        var isNormRecord = detailRecord.Is_Normalization_Rollup_Record__c;
        console.log(detailRecord);
        var hasDataValues = false;
        if(tableType == 'Overall detail only'){
            if(!isNormRecord && detailRecord.BCAP_Comments__c !== '' && detailRecord.BCAP_Comments__c !== undefined && detailRecord.BCAP_Comments__c !== null){
                hasDataValues = true;
            }
        }
        else{
            if(!isNormRecord && detailRecord.BCAP_Data_Tier__c !== '' && detailRecord.BCAP_Data_Tier__c !== undefined && detailRecord.BCAP_Data_Tier__c !== null){
                hasDataValues = true;
            }
            else if(!isNormRecord && detailRecord.BCAP_Data_Rank__c !== '' && detailRecord.BCAP_Data_Rank__c !== undefined && detailRecord.BCAP_Data_Rank__c !== null){
                hasDataValues = true;
            }
                else if(!isNormRecord && detailRecord.BCAP_Data_Points__c !== '' && detailRecord.BCAP_Data_Points__c !== undefined && detailRecord.BCAP_Data_Points__c !== null){
                    hasDataValues = true;
                }
                    else if(!isNormRecord && detailRecord.BCAP_Data_Payment__c !== '' && detailRecord.BCAP_Data_Payment__c !== undefined && detailRecord.BCAP_Data_Payment__c !== null){
                        hasDataValues = true;
                    }
                        else if(!isNormRecord && detailRecord.BCAP_Data_Relative_Rank__c !== '' && detailRecord.BCAP_Data_Relative_Rank__c !== undefined && detailRecord.BCAP_Data_Relative_Rank__c !== null){
                            hasDataValues = true;
                        }
                            else if(!isNormRecord && detailRecord.BCAP_Data_Grade__c !== '' && detailRecord.BCAP_Data_Grade__c !== undefined && detailRecord.BCAP_Data_Grade__c !== null){
                                hasDataValues = true;
                            }
                                else if(!isNormRecord && detailRecord.BCAP_Comments__c !== '' && detailRecord.BCAP_Comments__c !== undefined && detailRecord.BCAP_Comments__c !== null){
                                    hasDataValues = true;
                                }
                                    else if(!isNormRecord && detailRecord.BCAP_Other_Quantative_Data__c !== '' && detailRecord.BCAP_Other_Quantative_Data__c !== undefined && detailRecord.BCAP_Other_Quantative_Data__c !== null){
                                        hasDataValues = true;
                                    }
                                        else{
                                        hasDataValues = false;
                                    }
        }
        component.set("v.haveDataValues",hasDataValues);
    },
    controlVisibility : function(component, event, helper){
        var individualCaptures = event.getParam("individualCaptures"); 
        component.set("v.individualCaptures",individualCaptures);
    }
    
    
})