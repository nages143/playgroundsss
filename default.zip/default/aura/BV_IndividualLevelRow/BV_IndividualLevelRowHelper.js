({
    getExternalId : function(component){
        
       return new Promise((function(resolve, reject){
			var action1 = component.get("c.bvGUID");
       		var id = null;
        	action1.setCallback(this, function(response){
             	var state = response.getState();
             	if (state === "SUCCESS") {
             	 	console.log("From server: " + JSON.stringify(response.getReturnValue()));
                 	id = response.getReturnValue();
                 	resolve(id)
             	}
                else{
                    reject(null)
                }
        	});
        	$A.enqueueAction(action1);          
        }));
           
    },
    
    validateBrid : function(component){
         var brid = component.get("v.voterDetailRecord.Employee__c.BCAP_External_ID__c"); 
         var inputCmpBrid = component.find("fieldIdBrid");
         if(brid == null || brid == ''){
            inputCmpBrid.setCustomValidity(" "); 
            inputCmpBrid.reportValidity();
         } 
         else if(brid != null || brid != ''){
            inputCmpBrid.setCustomValidity(""); 
            inputCmpBrid.reportValidity();
         } 
    },
    
    validateEmail : function(component){
         var field = component.get("v.voterDetailRecord.Contact__c.Email"); 
         var fieldName = component.get("v.voterDetailRecord.Contact__c.Name");
         var inputCmp = component.find("fieldIdEmail");
         if(field == null || field == ''){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
         } 
         else if(field != null || field != ''){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
         } 
    },
    validateFunctionField: function(component){
        var empName = component.get("v.voterDetailRecord.BCAP_Employee__c");
        var func = component.find("fieldIdFunction").get("v.value");//component.get("v.voterDetailRecord.BCAP_Rank__c"); 
        var inputCmp = component.find("fieldIdFunction");
        if(empName !==null && (func === null || func === '')){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
            inputCmp.showHelpMessageIfInvalid();
        } 
        else if(func !== null || func !== ''){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        }
        this.validateSectorField(component);
        this.validatePCLField(component);
    },
    validateSectorField : function(component){
        var sector = component.get("v.voterDetailRecord.BCAP_Sector__c"); 
        var func = component.get("v.voterDetailRecord.BCAP_Function__c"); 
        var inputCmp = component.find("fieldIdSector");
        if(func == 'Specialist Sales' || func == 'Equity Research'){ 
            if(sector === null || sector === ''){
                inputCmp.setCustomValidity(" "); 
                inputCmp.reportValidity();
                inputCmp.showHelpMessageIfInvalid();
            } 
            else if(sector !== null || sector !== ''){
                inputCmp.setCustomValidity(""); 
                inputCmp.reportValidity();
            } 
        }
        else{
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        }
	},
     validatePCLField : function(component){
        var pcl = component.get("v.voterDetailRecord.BCAP_PCL__c"); 
        var func = component.get("v.voterDetailRecord.BCAP_Function__c"); 
        var inputCmp = component.find("fieldIdPCL");
        if(func == 'Specialist Sales' || func == 'Equity Research'){ 
            if(pcl === null || pcl === ''){
                inputCmp.setCustomValidity(" "); 
                inputCmp.reportValidity();
                inputCmp.showHelpMessageIfInvalid();
            } 
            else if(pcl !== null || pcl !== ''){
                inputCmp.setCustomValidity(""); 
                inputCmp.reportValidity();
            } 
        }
         else{
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
        }
	},
	/*
	validateDataRankField : function(component){
    	var dataRank = component.get("v.voterDetailRecord.BCAP_Data_Rank__c"); 
         var inputCmp = component.find("fieldIdDataRank");
         if(dataRank == null || dataRank == ''){
            inputCmp.setCustomValidity(" "); 
            inputCmp.reportValidity();
            inputCmp.showHelpMessageIfInvalid();
         } else if(dataRank != null || dataRank != ''){
            inputCmp.setCustomValidity(""); 
            inputCmp.reportValidity();
         } 
	}
    */
})