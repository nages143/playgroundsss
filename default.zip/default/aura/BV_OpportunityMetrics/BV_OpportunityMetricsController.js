({
	init : function(component, event, helper) {
		alert(component.get("v.individualCaptures"));
	}
})