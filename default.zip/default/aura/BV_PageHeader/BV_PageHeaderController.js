({
    init : function(component, event, helper) {
        var url = new URL(window.location.href);
        var voteId = url.searchParams.get("Id");
        var editMode = url.searchParams.get("editMode");
        if(String(url).includes("BVLanding")) {
            component.set("v.landingScreen",true);
        }
        if(String(url).includes("BVAddVote") && editMode) {
            component.set("v.addVoteScreen",true);
            component.set("v.voteId",voteId);
        }
        
        var action = component.get("c.getTemplateIds");        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + response.getReturnValue());
                var idResponse = response.getReturnValue();
                
                component.set("v.voteTemplateId",'/servlet/servlet.FileDownload?file='+idResponse[0]);
                component.set("v.voteDetailTemplateId",'/servlet/servlet.FileDownload?file='+idResponse[1]);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
        
        var landingScreen = component.get("v.landingScreen");
        var brokerVote = component.get("v.brokerVote");
        if(!landingScreen && brokerVote && brokerVote.Id !==null){
            var brokerVote = component.get("v.brokerVote");
            var userRegion = component.get("v.userRegion");
            var curAccStatus = '';
            var curIndStatus = '';
            
            if(userRegion === 'EU'){
                curAccStatus = brokerVote.BCAP_Account_Level_Status_EU__c;
                curIndStatus = brokerVote.BCAP_Individual_Level_Status_EU__c;
            }
            if(userRegion === 'NAM'){
                curAccStatus = brokerVote.BCAP_Account_Level_Status_US__c;
                curIndStatus = brokerVote.BCAP_Individual_Level_Status_US__c;
            }
            
            var accountStatus = component.get("v.accountStatus");
            var isSet = false;
            for(var index=0;index<accountStatus.length; index++) {
                if(isSet || curAccStatus === 'Not Started') {
                    accountStatus[index].status = 'Incomplete';
                }
                else{
                    if(accountStatus[index].value== curAccStatus) {
                        if(curAccStatus ==='Flash Published') {
                            accountStatus[index].status = 'Complete';
                        }
                        else{
                            accountStatus[index].status = 'Current';
                        	isSet=true;
                        }  
                        
                        
                    }
                    else {
                        accountStatus[index].status = 'Complete';
                    }
                }
            }   
            component.set("v.accountStatus",accountStatus);
            
            var indStatus = component.get("v.indStatus");
            var isSet = false;
            for(var index=0;index<indStatus.length; index++) {
                if(isSet || curIndStatus === 'Not Started') {
                    indStatus[index].status = 'Incomplete';
                }
                else{
                    if(indStatus[index].value== curIndStatus) {
                        if(curIndStatus ==='Published') {
                            indStatus[index].status = 'Complete';
                        }
                        else{
                            indStatus[index].status = 'Current';
                            isSet=true;
                        }                        
                    }
                    else {
                        indStatus[index].status = 'Complete';
                    }
                }
            }   
            component.set("v.indStatus",indStatus);
            
            var fullVoteStatus = component.get("v.fullVoteStatus");
            if(fullVoteStatus[0].value== brokerVote.BCAP_Full_Vote_Status__c) {
                fullVoteStatus[0].status = 'Complete';
            }
            component.set("v.fullVoteStatus",fullVoteStatus);
        }
    },
    addVote: function (component, event, helper) {
        
        var ctarget = event.currentTarget;
        var url = new URL(window.location.href);
        var urlString = encodeURI(url);
        var redirectUrl = urlString.substring(0,urlString.lastIndexOf('/'));
        window.open(redirectUrl+"/BVAddVote.app", '_parent');
    },
})