({
   selectRecord : function(component, event, helper){      
    // get the selected record from list  
       var getSelectRecord = JSON.parse(JSON.stringify(component.get("v.oRecord")));
    // call the event   
      var compEvent = component.getEvent("selectedRegionEvent");
    // set the Selected sObject Record to the event attribute.  
         compEvent.setParam("recordByEvent", getSelectRecord );  
    // fire the event  
         compEvent.fire();
    },
})