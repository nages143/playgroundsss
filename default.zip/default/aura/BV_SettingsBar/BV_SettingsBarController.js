({
	downloadVoteDetails: function(component, event, helper) {
        var action = component.get("c.exportReport");        
        var params = {"buyingCenter": {},
                      "votePeriod": {},
                      "startDate": null,
                      "endDate": null,
                      "voteIds": component.get("v.mainVoteId"),
                      "reportType": "BV_Vote_Vote_Details"}; 
        
        action.setParams({
            'params': JSON.stringify(params)
        });
        
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + response.getReturnValue());
                var storeResponse = response.getReturnValue();
                window.open(storeResponse);
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    showPerformanceMetricsDialog: function(component, event, helper) {
        var appEvent = $A.get("e.c:BV_openPerformanceMetricsEvent");
        appEvent.fire(); 
    },
    handleRegionChange: function(component, event, helper) {
    }
})