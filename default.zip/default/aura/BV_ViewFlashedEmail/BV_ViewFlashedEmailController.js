({
    init : function(component, event, helper) {
        var action = component.get("c.getVoteMessage");
        var voteId =component.get("v.mainVoteId");   
        action.setParams({
            "voteId" : voteId
        });
        // Create a callback that is executed after 
        // the server-side action returns
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue().includes("Error")) {
                    
                }
                else{
                    console.log("From server: " + JSON.stringify(response.getReturnValue()));
                    var voteMessge = JSON.parse(response.getReturnValue());
                    var code = voteMessge[0]["code"];
                    var graphCode = voteMessge[0]["graphCode"];
                    code = code.replace('<img src="cid:image1" />', graphCode);
                    component.set("v.code",code);
                    component.set("v.graphCode",graphCode);
                    component.set("v.initiated", true);
                }
            }
        });
        $A.enqueueAction(action); 
    }
})