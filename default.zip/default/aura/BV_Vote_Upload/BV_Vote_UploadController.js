({
    init : function(component, event, helper) {
		var url = new URL(window.location.href);
        if(String(url).includes("BVLanding")) {
            component.set("v.landingScreen",true);
        }
	},
    CreateRecord: function (component, event, helper) {
         
        var url = new URL(window.location.href);
        var uploadType = 'Vote';
        
        //var fileInput = component.find("file").getElement();
        var fileInput = component.get("v.fileToBeUploaded");
        //var file = fileInput.files[0];
        var file = fileInput[0][0];
        //alert(file);
        if (file) {
        console.log("File");
        var reader = new FileReader();
        reader.readAsText(file, "UTF-8");
        /*reader.onload = function (evt) {
            console.log("EVT FN");
            var csv = evt.target.result;
            console.log('@@@ csv file contains'+ csv);
            var result = helper.CSV2JSON(component,csv);
            console.log('@@@ result = ' + result);
            //console.log('@@@ Result = '+JSON.parse(result));
            helper.upload(component,result);
            
        }*/
            
            reader.onload = $A.getCallback(function() {
            var fileContents = reader.result;
           
                var result = helper.CSV2JSON(component,fileContents);
            
           helper.upload(component,result,uploadType);
           
        });
            
        reader.onerror = function (evt) {
            console.log("error reading file");
        }
    }

    },
    CreateRecordVoteDetails: function (component, event, helper) {
         
        var url = new URL(window.location.href);
        var uploadType = 'VoteDetails';        
        
        //var fileInput = component.find("file").getElement();
        var fileInput = component.get("v.fileToBeUploaded");
        //var file = fileInput.files[0];
        var file = fileInput[0][0];
        //alert(file);
        if (file) {
        console.log("File");
        var reader = new FileReader();
        reader.readAsText(file, "UTF-8");
        /*reader.onload = function (evt) {
            console.log("EVT FN");
            var csv = evt.target.result;
            console.log('@@@ csv file contains'+ csv);
            var result = helper.CSV2JSON(component,csv);
            console.log('@@@ result = ' + result);
            //console.log('@@@ Result = '+JSON.parse(result));
            helper.upload(component,result);
            
        }*/
            
            reader.onload = $A.getCallback(function() {
            var fileContents = reader.result;
           
                var result = helper.CSV2JSON(component,fileContents);
            
           helper.upload(component,result,uploadType);
           
        });
            
        reader.onerror = function (evt) {
            console.log("error reading file");
        }
    }

    }
    
    
})