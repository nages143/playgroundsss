({
    CSV2JSON: function (component,csv) {
        console.log('@@@ Incoming csv = ' + csv);
        
        //var array = [];
        var arr = []; 
        
        arr =  csv.split('\n');;
        //console.log('@@@ Array  = '+array);
        console.log('@@@ arr = '+arr);
        arr.pop();
        var jsonObj = [];
        var headers = arr[0].split(',');
        for(var i = 1; i < arr.length; i++) {
            var data = arr[i].split(',');
            var obj = {};
            for(var j = 0; j < data.length; j++) {
                obj[headers[j].trim()] = data[j].trim();
                //console.log('@@@ obj headers = ' + obj[headers[j].trim()]);
            }
            jsonObj.push(obj);
        }
        var json = JSON.stringify(jsonObj);
        console.log('@@@ json = '+ json);
        return json;
        
        
    },
    
    upload : function (component,jsonstr,uploadType){
        component.set("v.showLoadingSpinner",true);
        console.log('@@@ jsonstr' + jsonstr);
        var voteId = component.get("v.voteId");
        var action = null;
        if(uploadType == 'VoteDetails') {
            action = component.get("c.insertVoteDetails");
        } else {
            action = component.get("c.insertVote");
        }
        
        //alert('@@@ Server Action' + action);    
        action.setParams({
            "strfromlex" : jsonstr
        });
        action.setCallback(this, function(response) {
            component.set("v.showLoadingSpinner",false);
            var state = response.getState();
            //alert(state);
            if (state === "SUCCESS") {  
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Records uploaded successfully");
                appEvent.setParam("type", "success");
                appEvent.setParam("duration", "3000");
                appEvent.setParam("mode", "dismissible");
                appEvent.fire();            
            }
            else if (state === "ERROR") {
                
                var appEvent = $A.get("e.c:BV_CustomShowToastEvent");
                appEvent.setParam("message", "Error uploading records");
                appEvent.setParam("type", "error");
                appEvent.setParam("duration", "3000");
                appEvent.setParam("mode", "dismissible");
                appEvent.fire(); 
                
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                    //alert("Vote Upload Failed");
                }
            }
        }); 
        
        $A.enqueueAction(action);    
        
    }
})