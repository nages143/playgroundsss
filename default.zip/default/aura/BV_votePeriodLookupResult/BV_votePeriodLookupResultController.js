({
    selectRecord : function(component, event, helper){      
        // get the selected record from list  
        var getSelectRecord = component.get("v.oRecord");
        
        var startDate = component.get("v.startDate");
        var endDate = component.get("v.endDate");
        //var scorecardDate = component.get("v.scorecardDate");
        var compEvent = component.getEvent("oSelectedRecordEvent");
        compEvent.setParams({"recordByEvent" : getSelectRecord, "startDate": startDate, 
                             "endDate" : endDate});  
        compEvent.fire();
        
    },
})