({
	fetchCycleVoteHelper : function(component,event,votePeriodRecord) {
	  // call the apex class method 
     var action = component.get("c.fetchCycleVote");
      // set param to method  
        action.setParams({
            'votePeriodName': votePeriodRecord.Name
          });
      // set a callBack    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                // set vote list with return value from server.
                // 
                component.set("v.voteCycleRecord", storeResponse);
                component.set("v.scorecardDate", storeResponse.BCAP_Start_Month__c);
                
                var getSelectRecord = component.get("v.oRecord");
      			var startDate = component.get("v.startDate");
      			var endDate = component.get("v.endDate");
      			var scorecardDate = component.get("v.scorecardDate");
      			var voteCycleRecord = component.get("v.voteCycleRecord");
                
    			// call the event   
      			var compEvent = component.getEvent("oSelectedRecordEvent");
    			// set the Selected sObject Record to the event attribute.  
       			compEvent.setParams({"recordByEvent" : getSelectRecord, "startDate": startDate, 
                                     "endDate" : endDate, "scorecardDate": scorecardDate , "voteCycle":voteCycleRecord});  
    			// fire the event  
         		compEvent.fire();
            }
            else
            {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
 
        });
      // enqueue the Action  
        $A.enqueueAction(action);
    
	}
})