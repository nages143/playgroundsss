({
    doInit: function(component, event, helper) {
        var csatSurveyName = component.get("v.csatSurveyName");
        var csatSurveyId = component.get("v.csatSurveyId");
        helper.fetchSurveyQuestionDetails(component, event);
    },
 
    Save: function(component, event, helper) {
        // Call helper function in if block to validate each record, function will return true or false.      
        if (helper.validateRequired(component, event)) {
            // Call apex class method to List attribute to method param.  
            var action = component.get("c.saveSurveyResponse");
            action.setParams({
                "listSurveyResponse": component.get("v.surveyResponseList")
            });
            // set call back 
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    // if response is success then redirect to CSAT Survey record                
                    var csatSurveyId = component.get("v.csatSurveyId");
                    //alert($A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view");
                    //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view";
                    window.location.href = '/one/one.app#/sObject/'+csatSurveyId+'/view';
                    
                }
            });
            // enqueue the server side action  
            $A.enqueueAction(action);
        }
    },
    
    Cancel : function(component,event,helper){
    	var csatSurveyId = component.get("v.csatSurveyId");
        //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view";  
        window.location.href = '/one/one.app#/sObject/'+csatSurveyId+'/view';
    },
    
    Next : function(component,event,helper){
        var respList  = {}
        respList = component.get("v.surveyResponseList");    
        /*console.log(respList);
        for(var i in respList){
            //console.log(respList[i]);
            if(respList[i].CSAT_Survey_Question__name == 'NPS'){
                var reasonMap = component.get("v.themeReasonMap");
                var reasons = reasonMap[respList[i].CSAT_Survey_Question__name + respList[i].Product__c];
                console.log('reasons : '+reasons);
            }
        }*/
        if (helper.validateRequiredNext(component, event)) {
        	component.set("v.showNext",true);
        }
    },
    
    Back : function(component,event,helper){
        component.set("v.showNext",false);
        var respList  = {}
        respList = component.get("v.surveyResponseList"); 
        console.log(respList);
        for(var i in respList){
            
        }
        alert(component.find("comments").get("v.value"));
    },
})