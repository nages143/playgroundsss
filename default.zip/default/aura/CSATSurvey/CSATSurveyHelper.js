({
    //helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        var isValid = true;
        var errorMessage = [];
        var errormsg = '';
        var surveyResponseList = component.get("v.surveyResponseList");
        var npsComments = component.find("comments").get("v.value"); 
        var i=0;
        for (var indexVar = 0; indexVar < surveyResponseList.length; indexVar++) {
            if (surveyResponseList[indexVar].Rating__c != '' && surveyResponseList[indexVar].Rating__c != 'Excellent' && surveyResponseList[indexVar].Rating__c != 'Above Average' && surveyResponseList[indexVar].Reason__c == '') {
                alert(surveyResponseList[indexVar].Rating__c);
                isValid = false;
                errormsg = "Reason Can\'t be Blank on " + surveyResponseList[indexVar].CSAT_Survey_Question__name + " Theme ";
                errormsg += surveyResponseList[indexVar].Product__c ? " for Product "+surveyResponseList[indexVar].Product__c : '';
                errorMessage[i++] = errormsg;               
            }
            if(surveyResponseList[indexVar].CSAT_Survey_Question__name == 'NPS'){
            	surveyResponseList[indexVar].NPS_Comment__c = npsComments;
            }
        }
        component.set("v.errorMessage",errorMessage);
        console.log(errorMessage);
        return isValid;
    },
    fetchSurveyQuestionDetails: function(component, event){
        var action = component.get("c.getSetUpData");
        var records;
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                records = response.getReturnValue();
                //To store the CSAT Survey ID
                var csatSurveyId = component.get("v.csatSurveyId");
                //To store the name of Survey Question
                var keyColumn = {};
                //After fetching Survey Questions set the question in list
                var RowItemList = component.get("v.surveyResponseList");
                for(var i=0; i<records.wrapListQuestions.length; i++){
                    var occurence = keyColumn.hasOwnProperty(records.wrapListQuestions[i].Survey_Question__c)
                    RowItemList.push({
                        'sobjectType': 'OCS_CSAT_Survey_Response__c',
                        'CSAT_Survey_Question__name': records.wrapListQuestions[i].Survey_Question__c,
                        'CSAT_Survey_Question__tmp': occurence ? "" : records.wrapListQuestions[i].Survey_Question__c,
                        'CSAT_Survey_Question__c': records.wrapListQuestions[i].Id,
                        'CSAT_Survey__c': csatSurveyId,
                        'Product__c': records.wrapListQuestions[i].Product__c ? records.wrapListQuestions[i].Product__c : "",
                        'Rating__c': '',
                        'Reason__c':'',
                        'NPS_Score__c':'',
                        'NPS_Comment__c':''
                    });
                    keyColumn[records.wrapListQuestions[i].Survey_Question__c] = records.wrapListQuestions[i].Survey_Question__c;    
                    
                }
                //set the updated list to attribute (surveyResponseList) again   
                console.log(RowItemList); 
                component.set("v.npsScore", records.npsScore);
                component.set("v.themeReasonMap", records.themeReasonMapValue);
                component.set("v.ratingValue", records.ratingValues);
                component.set("v.surveyResponseList", RowItemList);
            }
        });
        // enqueue the server side action  
        $A.enqueueAction(action);        
    },
    
    validateRequiredNext: function(component, event) {
        var isValid = true;
        var errorMessage = [];
        var errormsg = '';
        var surveyResponseList = component.get("v.surveyResponseList");
        var i=0;
        for (var indexVar = 0; indexVar < surveyResponseList.length; indexVar++) {
            if (surveyResponseList[indexVar].Rating__c != '' && surveyResponseList[indexVar].Rating__c != 'Excellent' && surveyResponseList[indexVar].Rating__c != 'Above Average' && surveyResponseList[indexVar].Reason__c == '') {
                alert(surveyResponseList[indexVar].Rating__c);
                isValid = false;
                errormsg = "Reason Can\'t be Blank on " + surveyResponseList[indexVar].CSAT_Survey_Question__name + " Theme ";
                errormsg += surveyResponseList[indexVar].Product__c ? " for Product "+surveyResponseList[indexVar].Product__c : '';
                errorMessage[i++] = errormsg;               
            }
        }
        component.set("v.errorMessage",errorMessage);
        console.log(errorMessage);
        return isValid;
    },
    
})