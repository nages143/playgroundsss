({
    doInit: function(component, event, helper) {
        debugger;
        var csatSurveyName = component.get("v.csatSurveyName");
        var csatSurveyId = component.get("v.csatSurveyId");
        helper.fetchSurveyQuestionDetails(component, event);
    },
 
    Save: function(component, event, helper) {
        if (helper.validateRequired(component, event)) {
            var action = component.get("c.saveSurveyResponse");
            action.setParams({
                "listSurveyResponse": component.get("v.surveyResponseList")
            });
            // set call back 
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {           
                    var csatSurveyId = component.get("v.csatSurveyId");
                    //alert($A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view");
                    //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view";
                    //window.location.href = '/one/one.app#/sObject/'+csatSurveyId+'/view';
                    window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+ csatSurveyId +"/view", '_top');
                    
                }
            });
            $A.enqueueAction(action);
        }
    },
    
    Cancel : function(component,event,helper){
    	var csatSurveyId = component.get("v.csatSurveyId");
        //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + csatSurveyId+"/view";
        //window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+ csatSurveyId +"/view", '_top');
          window.open('/one/one.app#/sObject/'+csatSurveyId+'/view', '_top');    
        //window.location.href = '/one/one.app#/sObject/'+csatSurveyId+'/view';
    },
    
    Next : function(component,event,helper){
        debugger;
        var respList  = {}
        respList = component.get("v.surveyResponseList");    
        if (helper.validateRequiredNext(component, event)) {
        	component.set("v.showNext",true);
        }
        component.find("comments").set("v.value",component.get("v.NpsComment"));
        component.find("npsRate").set("v.value",component.get("v.selectedNpsScore"));
    },
    
    Back : function(component,event,helper){
        component.set("v.showNext",false);
        var respList  = {}
        respList = component.get("v.surveyResponseList");        
    },
    pickValue : function(component,event,helper){
        var npsComments = component.find("npsRate").get("v.value"); 
        alert(npsComments);      
    },
})