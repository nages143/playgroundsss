({
    validateRequired: function(component, event) {
        var isValid = true;
        var errorMessage = [];
        var errormsg = '';
        var surveyResponseList = component.get("v.surveyResponseList");
        var npsComments = component.find("comments").get("v.value"); 
        var npsRate = component.find("npsRate").get("v.value"); 
        var i=0;
        for (var indexVar = 0; indexVar < surveyResponseList.length; indexVar++) {
            if (surveyResponseList[indexVar].Rating__c != '' && surveyResponseList[indexVar].Rating__c != 'Excellent' && surveyResponseList[indexVar].Rating__c != 'Above Average' && surveyResponseList[indexVar].Reason__c == '') {
                alert(surveyResponseList[indexVar].Rating__c);
                isValid = false;
                errormsg = "Reason Can\'t be Blank on " + surveyResponseList[indexVar].CSAT_Survey_Question__name + " Theme ";
                errormsg += surveyResponseList[indexVar].Product__c ? " for Product "+surveyResponseList[indexVar].Product__c : '';
                errorMessage[i++] = errormsg;               
            }
            if(surveyResponseList[indexVar].CSAT_Survey_Question__name == 'NPS'){
            	surveyResponseList[indexVar].NPS_Comment__c = npsComments;
                surveyResponseList[indexVar].NPS_Score__c = npsRate;
            }
        }
        component.set("v.errorMessage",errorMessage);
        console.log(errorMessage);
        return isValid;
    },
    fetchSurveyQuestionDetails: function(component, event){
        debugger;
        var action = component.get("c.getSetUpData");
        var records;
        
        action.setParams({
            "mode": component.get("v.mode"),
            "csatId": component.get("v.csatSurveyId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                records = response.getReturnValue();
                //To store the CSAT Survey ID
                var csatSurveyId = component.get("v.csatSurveyId");
                //To store the name of Survey Question
                var keyColumn = {};
                //After fetching Survey Questions set the question in list
                var RowItemList = component.get("v.surveyResponseList");
                
				
				var mapSelectedValue = records.getRecords;
				
				for (var key in mapSelectedValue) {
					if (mapSelectedValue.hasOwnProperty(key)) {
						var occurence = keyColumn.hasOwnProperty(mapSelectedValue[key].Survey_Question_Name__c)	
						console.log(key + " -> " + mapSelectedValue[key].Id);
						RowItemList.push({
							'sobjectType': 'OCS_CSAT_Survey_Response__c',
							'Id': mapSelectedValue[key].Id,
							'CSAT_Survey_Question__name': mapSelectedValue[key].Survey_Question_Name__c ,
							'CSAT_Survey_Question__tmp': occurence ? "" : mapSelectedValue[key].Survey_Question_Name__c,
							'CSAT_Survey_Question__c': mapSelectedValue[key].Survey_Question__c,
							'CSAT_Survey__c': mapSelectedValue[key].CSAT_Survey__c,
							'Product__c': mapSelectedValue[key].Product__c ? mapSelectedValue[key].Product__c : "",
							'Rating__c': mapSelectedValue[key].Rating__c,
							'Reason__c': mapSelectedValue[key].Reason__c,
							'NPS_Score__c': mapSelectedValue[key].NPS_Score__c,
							'NPS_Comment__c': mapSelectedValue[key].NPS_Comment__c
						});
						mapSelectedValue[key].NPS_Comment__c ? component.set("v.NpsComment",mapSelectedValue[key].NPS_Comment__c) : '';
						mapSelectedValue[key].NPS_Score__c ? component.set("v.selectedNpsScore",mapSelectedValue[key].NPS_Score__c) : '';
						keyColumn[mapSelectedValue[key].Survey_Question_Name__c] = mapSelectedValue[key].Survey_Question_Name__c;
					}
				}
                component.set("v.npsScore", records.npsScore);
                component.set("v.themeReasonMap", records.themeReasonMapValue);
                component.set("v.ratingValue", records.ratingValues);
                component.set("v.surveyResponseList", RowItemList);
            }
        });
        // enqueue the server side action  
        $A.enqueueAction(action);        
    },
    
    validateRequiredNext: function(component, event) {
        
        var isValid = true;
        var errorMessage = [];
        var errormsg = '';
        var surveyResponseList = component.get("v.surveyResponseList");
        var i=0;
        for (var indexVar = 0; indexVar < surveyResponseList.length; indexVar++) {
            if (surveyResponseList[indexVar].Rating__c != '' && surveyResponseList[indexVar].Rating__c != 'Excellent' && surveyResponseList[indexVar].Rating__c != 'Above Average' && surveyResponseList[indexVar].Reason__c == '') {
                alert(surveyResponseList[indexVar].Rating__c);
                isValid = false;
                errormsg = "Reason Can\'t be Blank on " + surveyResponseList[indexVar].CSAT_Survey_Question__name + " Theme ";
                errormsg += surveyResponseList[indexVar].Product__c ? " for Product "+surveyResponseList[indexVar].Product__c : '';
                errorMessage[i++] = errormsg;               
            }
        }
        component.set("v.errorMessage",errorMessage);
        console.log(errorMessage);
        return isValid;
    },
    
})