({
	
	doInit : function(component, event) {
		component.set('v.mycolumns', [
				{label:'Type',fieldName: 'Type', type: 'text'},
            	{label:'Legal Entity',fieldName: 'Legal_Entity__c', type: 'text'},
                {label: 'First Name', fieldName: 'FirstName', type: 'text',/*cellAttributes: { iconName: 'utility:event' }*/},
				{label: 'Last Name', fieldName: 'LastName', type: 'text'},
            	{label:'Email',fieldName: 'Email', type: 'email'},
				{label: 'Status', fieldName: 'Status', type: 'text'},
            	{label: 'Version Type', fieldName: 'OR_Version_Type__c', type: 'text'},
            	{label: 'Version Language', fieldName: 'Version_Language__c', type: 'text'},
                {label: 'Targeted SDS Ids', fieldName: 'OR_Related_SDS_Ids__c', type: 'phone'}
		]);        
        var campaignId =component.get('v.campaignId');		
		var action = component.get("c.getRelatedCampaignMembers");       
		action.setParams({"CampaignId": campaignId});
    	
        action.setCallback(this, function(a) {
			var rows = a.getReturnValue();
          //  Below logic is used when need to populate parent data in datatable[Commented]
				/*for (var i = 0; i < rows.length; i++) {
         			var row = rows[i];
					if (row.Contact) 
                        row.ContactLeadSource = row.Contact.LeadSource;
         		}*/
			component.set("v.CampaignMembers", rows);		          
			if((component.get("v.CampaignMembers")).length<=0){
				component.set('v.noResult','No Campaign Members Found!')  ;
			 }else{
				component.set('v.noResult','') ;
			}
    	});
    $A.enqueueAction(action);    
    },  
    updateSelectedLeads : function(component, event) {
        var id = event.source.get("v.text");
        if (event.source.get("v.value")) {
            
            if (component.get("v.selectedLeads").indexOf(id) < 0) {
                component.get("v.selectedLeads").push(id);
                console.log(component.get("v.selectedLeads"));
            }
        } else {
            
            var index = component.get("v.selectedLeads").indexOf(id);
            if (index > -1) {
                component.get("v.selectedLeads").splice(index, 1);
            }
            console.log(component.get("v.selectedLeads"));
        }
},
    getCampaignMembers: function(component, event) {
        component.set("v.render", "true");
        console.log('getCampaignMembers called');
				component.set('v.mycolumns', [
				{label:'Type',fieldName: 'Type', type: 'text'},
            	{label:'Legal Entity',fieldName: 'Legal_Entity__c', type: 'text'},
                {label: 'First Name', fieldName: 'FirstName', type: 'text',/*cellAttributes: { iconName: 'utility:event' }*/},
				{label: 'Last Name', fieldName: 'LastName', type: 'text'},
            	{label:'Email',fieldName: 'Email', type: 'email'},
				{label: 'Status', fieldName: 'Status', type: 'text'},
            	{label: 'Version Type', fieldName: 'OR_Version_Type__c', type: 'text'},
            	{label: 'Version Language', fieldName: 'Version_Language__c', type: 'text'},
                {label: 'Related SDS Ids', fieldName: 'OR_Related_SDS_Ids__c', type: 'phone'}
		]);  
        var campaignId =component.get('v.campaignId');
    var searchKey = event.getParam("recName");    
     console.log('searchKey'+searchKey);   
    var action = component.get("c.getSearchCampaignMembers");
        
    action.setParams({
        "recName": searchKey,"campaignId":campaignId
    });
    action.setCallback(this, function(a) {
			var rows = a.getReturnValue();
        	 //  Below logic is used when need to populate parent data in datatable[Commented]
				/*for (var i = 0; i < rows.length; i++) {
         			var row = rows[i];
					if (row.Contact) 
                        row.ContactLeadSource = row.Contact.LeadSource;
         		}*/
			component.set("v.CampaignMembers", rows);
        var z = component.get("v.CampaignMembers");
        console.log('hello');
        	console.log(z);
			if((component.get("v.CampaignMembers")).length<=0){
				component.set('v.noResult','No Campaign Members Found!')  ;
                var togglerEvent = $A.get("e.c:ToggleProcessButton");                                  
        		togglerEvent.setParams({"toogler": true});                 
        		togglerEvent.fire()
			 }else{
					component.set('v.noResult','') ;
                
						
			}
    	});
    $A.enqueueAction(action); 
        
    },

    getSelectedName: function (component, event) {
        var searchKey = event.getParam("recName"); 
        console.log('searchkeybelow');
        console.log(searchKey);
        var selectedRows = event.getParam('selectedRows');
        console.log('selectedRows below');
        console.log(selectedRows);
		var srows = [];  
   		for (var i = 0; i < selectedRows.length; i++){
            srows.push(selectedRows[i].Id);
        }
        //srows.push(selectedRows);
        console.log('srows');
        console.log(srows);
        component.set('v.selectedRecordList',srows);
        var l =component.get('v.selectedRecordList');
        
        if(selectedRows.length <= 0 ){
        	var tooglerEvent = $A.get("e.c:ToggleProcessButton");                                  
        			tooglerEvent.setParams({"toogler": true});                 
        			tooglerEvent.fire();
        }else
        {
          var tooglerEvent = $A.get("e.c:ToggleProcessButton");                                  
        			tooglerEvent.setParams({"toogler": false});                 
        			tooglerEvent.fire();  
            
            
        }
         
    },
  
    
    ProcessFinalCM: function(component, event, helper){
        
        var searchParam = event.getParam("input");
        console.log('searchParam'+searchParam);
        if(searchParam!= null){
		 if(searchParam.length != 8 || (searchParam.length == 0 && (component.get('v.selectedRecordList').size <=0))) {
        	//alert('You must enter a valid SDS ID to Process');
      			 component.set("v.isOpenError", true);  
        } 
        }else
        {
             component.set("v.isOpenError", true); 
        }
        
        var l =component.get('v.selectedRecordList');
        console.log(l);
        
        
        var action = component.get("c.processFinalCampaignMembers");  
        action.setParams({"cm": l,"input":searchParam});
        console.log(action.getParam("cm"));
        action.setCallback(this, function(response) {
            var status = response.getState();
            if(status==="SUCCESS")
            {
                console.log(response.getReturnValue());
                if(response.getReturnValue()=='No Records selected')
					component.set("v.isOpenError", true);
                else if(response.getReturnValue()== 'success'){
                 helper.refresh(component,event);
                  component.set("v.isOpen", true);  	
                }
                else if(response.getReturnValue()=='do Nothing' || (response.getReturnValue()=='do Something'))
                {
                    
                      var tooglerEvent = $A.get("e.c:ToggleProcessButton");                                  
        			tooglerEvent.setParams({"toogler": true});                 
        			tooglerEvent.fire();   
                }
            }
            
 });
        $A.enqueueAction(action);

    },
     closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
      component.set("v.isOpen", false);
   },
 
   closeModelError: function(component, event, helper) {
      // Display alert message on the click on the "Like and Close" button from Model Footer 
      // and set set the "isOpen" attribute to "False for close the model Box.
     
      component.set("v.isOpenError", false);
   },
    
    CancelMassAction: function(component, event, helper)
    {
           //var url = window.location.href; 
           // var value = url.substr(0,url.lastIndexOf('/') + 1);
            window.history.back();
           // return false;
        
    }



})