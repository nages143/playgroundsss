({
	refresh : function(component, event) {
      
		component.set('v.mycolumns', [
				{label:'Type',fieldName: 'Type', type: 'text'},
            	{label:'Legal Entity',fieldName: 'Legal_Entity__c', type: 'text'},
                {label: 'First Name', fieldName: 'FirstName', type: 'text',/*cellAttributes: { iconName: 'utility:event' }*/},
				{label: 'Last Name', fieldName: 'LastName', type: 'text'},
            	{label:'Email',fieldName: 'Email', type: 'email'},
				{label: 'Status', fieldName: 'Status', type: 'text'},
            	{label: 'Version Type', fieldName: 'OR_Version_Type__c', type: 'text'},
            	{label: 'Version Language', fieldName: 'Version_Language__c', type: 'text'},
                {label: 'Related SDS Ids', fieldName: 'OR_Related_SDS_Ids__c', type: 'phone'}
		]);          
        var campaignId =component.get('v.campaignId');	
        console.log(campaignId);
		var action = component.get("c.getRelatedCampaignMembers");       
		action.setParams({"CampaignId": campaignId});
    	
        action.setCallback(this, function(a) {
			var rows = a.getReturnValue();
            //  Below logic is used when need to populate parent data in datatable[Commented]
				/*for (var i = 0; i < rows.length; i++) {
         			var row = rows[i];
                    console.log('row');
                    console.log(row);
					if (row.Contact)  
                        row.ContactLeadSource = row.Contact.LeadSource;
         		}*/
            component.set("v.render", "false");
            if(rows.length > 0)
			component.set("v.CampaignMembers", rows);
            else
            component.set("v.CampaignMembers", "[]");    

		/*	if((component.get("v.CampaignMembers")).length<=0){
				component.set('v.noResult','No Campaign Members Found!')  ;
			 }else{
				component.set('v.noResult','') ;
			}*/
            
            
    	});
    $A.enqueueAction(action);    
    }
})