({
    doInit : function(component, event, helper) {
        helper.getCase(component, '');
    },
    searchKeyChange : function(component, event, helper){
        var searchkey = component.get("v.SearchKeyWord");
        helper.getCase(component, searchkey);  
    },
    OpenModal : function(component, event, helper) {  
        var lstCases = component.get("v.lstCases"); 
        var caseRecords = component.get("v.selectedCases");
        if(!$A.util.isEmpty(caseRecords) && !$A.util.isUndefined(caseRecords)){           
            var action = component.get("c.performAction"); 
            action.setParams({
                CaseRecords : caseRecords
            });
            action.setCallback(this,function(a){
                var state = a.getState();               
                if(state == "SUCCESS"){                   
                    var result = a.getReturnValue();
                    if(!$A.util.isEmpty(result) && !$A.util.isUndefined(result))
                        component.set("v.relatedRecords",result);
                } 
                else if(state == "ERROR"){
                    alert('Error in calling server side action');
                }
            });      
            $A.enqueueAction(action);
        }
    },
    manageCases : function(component, event, helper) {
        debugger;
        var index = event.currentTarget.getAttribute('data-index');
        var lstCases = component.get("v.lstCases");
        var selectedCases = component.get("v.selectedCases");
        var selectedCasesObj = component.get("v.selectedCasesObj");
        var caseId = lstCases[parseInt(index)]['Id'];
        var caseObj = lstCases[parseInt(index)];
        for(var i in selectedCases){
            if(selectedCases[i] == caseId){
                alert("You have already selected this case");
                return;
            }
        }
        if(selectedCases.indexOf(index) == -1){
            selectedCases.push(caseId);
        }
        if(selectedCasesObj.indexOf(index) == -1){
            selectedCasesObj.push(caseObj);
        }
        component.set("v.selectedCases", selectedCases);
        component.set("v.selectedCasesObj", selectedCasesObj);
    },
    RemoveCases : function(component, event, helper) {
        var index = event.currentTarget.getAttribute('data-index');
        var selectedCases = component.get("v.selectedCases");
        var selectedCasesObj = component.get("v.selectedCasesObj");
        selectedCases.splice(index, 1);
        selectedCasesObj.splice(index, 1);
        component.set("v.selectedCases", selectedCases);
        component.set("v.selectedCasesObj", selectedCasesObj);
    },
    hideSpinner : function (component, event, helper) {
        helper.manageSpinner(component, event, helper, false);
    },
    showSpinner : function (component, event, helper) {
        helper.manageSpinner(component, event, helper, true);
    }
})