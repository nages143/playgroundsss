({
    getCase : function(component, searchKey) {
        var screenWidth = "max-width :"+window.screen.width * 0.3975+"px ;";
        var screenheight = "max-height : "+window.screen.height * 0.16015+"px ;";
        
        component.set("v.HorizontalHeight", screenWidth);
        component.set("v.VerticalHeight", screenheight);
        
        var action = component.get("c.getCaseRecords");
        action.setParams({
            searchKey : searchKey
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            if(state == "SUCCESS"){
                var result = a.getReturnValue();
                component.set("v.lstCases", result);
            } 
            else if(state == "ERROR"){
                alert('Error in calling server side action');
            }
        });      
        $A.enqueueAction(action);
    },
    manageSpinner : function (component, event, helper, isVisible) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : isVisible });
        evt.fire();    
    }
})