({
    init: function (component, event, helper) {
        var opts = [
            { class: "optionClass", label: "Reporting Parent", value: "RP", selected: "true" },
            { class: "optionClass", label: "Base Client", value: "B" }

        ];
        component.find("feeShareSelect").set("v.options", opts);
        component.set('v.ReportingLevel', component.find("feeShareSelect").get("v.value"));

        component.set('v.gridColumns1', [
            { label: 'Fees Paid To Street', fieldName: 'yearRange', type: 'text', cellAttributes: {alignment: 'center'} },
            { label: 'Amount ($mm)', fieldName: 'amount', type: 'text', cellAttributes: {alignment: 'center'} }
        ]);

        component.set('v.gridColumns2', [
            { label: 'Barclays Performance', fieldName: 'yearRange', type: 'text', cellAttributes: {alignment: 'center'}   },
            { label: 'Rank', fieldName: 'rank', type: 'number', cellAttributes: {alignment: 'center'}   },
            { label: 'Share', fieldName: 'share', type: 'text' , cellAttributes: {alignment: 'center'}  }
        ]);

        component.set('v.gridColumns3', [
            { label: 'Top Three Banks', fieldName: 'item', type: 'text', cellAttributes: {alignment: 'left'}  },
            { label: 'Share', fieldName: 'share', type: 'text', cellAttributes: {alignment: 'center'}  }

        ]);

        helper.fetchParameters(component, event, helper)
    },

    levelChange: function(component, event, helper) {
        helper.fetchParameters(component, event, helper)

    }
})