({
    fetchParameters : function(component, event, helper) {
        var recordId = component.get("v.recId")
        var reportingLevel = component.get("v.ReportingLevel");
       // reportingLevel = "B"
       // console.log("Record Id " + recordId);
      //  console.log("Reporting Level " + reportingLevel);
      this.makeAPICall(component, recordId, reportingLevel);
    },

    makeAPICall: function(component, recordId, reportingLevel) {
        //recordId = "0011900000lNVDSAA4"
        // reportingLevel = "RP"
        var xmlHttp = new XMLHttpRequest();
        var url = "https://my.barcapint.com/IBX/v2/feeShare?SFOrganizationId=" + recordId + "&reportingLevel=" + reportingLevel
        console.log("URL: " + url)
        xmlHttp.open("GET", url, true);
        xmlHttp.withCredentials = true;
        var responseText = []
         var expandedRows = []
        //let nestedDataFinal = [{"productName":"FI Syndicate","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[{"productName":"IG Syndicate","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"HY Syndicate","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"Securitization Syndicate","revenueYear1":0,"revenueYear2":0,"revenueYear3":0}]},{"productName":"Conduit/AFT/Other","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[{"productName":"Conduit/Other PM","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"Asset Finance","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"Structured Finance","revenueYear1":0,"revenueYear2":0,"revenueYear3":0}]},{"productName":"HY Hedge","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[]},{"productName":"RSG","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[]},{"productName":"BNC Fees","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[]},{"productName":"Warehouse Financing","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[]},{"productName":"Advisory","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[{"productName":"M&A","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"GFA/ETA","revenueYear1":0,"revenueYear2":0,"revenueYear3":0}]},{"productName":"Equity Origination","revenueYear1":0,"revenueYear2":0,"revenueYear3":0,"children":[{"productName":"Equity Syndicate","revenueYear1":0,"revenueYear2":0,"revenueYear3":0},{"productName":"Equity Derivatives","revenueYear1":0,"revenueYear2":0,"revenueYear3":0}]}]
        xmlHttp.onload = function () {
            if (xmlHttp.readyState === 4) {
                if (xmlHttp.status === 200) {
                    var responseObject1 = JSON.parse(xmlHttp.response);
                    console.log(responseObject1);

                    for (var key in responseObject1) {
                        responseText.push((responseObject1[key]));
                            // console.log("Top 3 banks child node is present" + responseObject1[key].item)
                            // expandedRows.push(responseObject1[key].item);
                        
                    }

                    for (var key in responseObject1['topThreeBanks']) {
                        expandedRows.push(responseObject1['topThreeBanks'][key].item);
                            // console.log("Top 3 banks child node is present" + responseObject1[key].item)
                            // expandedRows.push(responseObject1[key].item);
                        
                    }
                    component.set('v.gridData1', responseObject1['paidToStreet']);
                    component.set('v.gridData2', responseObject1['performance']);
                    component.set('v.gridData3',responseObject1['topThreeBanks']);
                    component.set('v.gridExpandedRows3',expandedRows);
                }
                else {
                    console.log("Fee Share Bad Request");
                    component.set("v.feeShareError",true);
                }
            }
            else {
                console.log("Request completed");
            }
        };


        xmlHttp.onerror = function() {
            console.log("Bad Request");
            component.set("v.feeShareError",true);

        }
        xmlHttp.send(null);
    }
})