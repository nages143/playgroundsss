({
	doInit : function(component, event, helper) {
		console.log('user id => '+$A.get("$SObjectType.CurrentUser.Id"));
        console.log('user => '+$A.get("$SObjectType.CurrentUser"));
        console.log('user => '+JSON.stringify($A.get("$SObjectType.CurrentUser")));
        var action = component.get('c.getCase');
        action.setCallback(this,function(response){
           var state = response.getState(response);
            
            if (state == 'SUCCESS' && response.getReturnValue() != null) {
                component.set("v.caseObj",response.getReturnValue());
                console.log('case => '+JSON.stringify(component.get('v.caseObj')));
            } else if (state == 'ERROR') {
                console.log('Error => '+response.getError()[0].getMessage);
            }
        });
        $A.enqueueAction(action);
        
        //Call method to get picklist values
        helper.getPicklistVal(component,'Case','Origin');
        helper.getPicklistVal(component,'Case','Priority');
        helper.getPicklistVal(component,'Case','GMO_ADS_Workflow_Stage__c');
        helper.getPicklistVal(component,'Case','GMO_ADS_Workflow_Status__c');
	},
    
    saveCase : function(component,event,helper){
        console.log('Inside saveCase method');
        var action = component.get("c.updateCase");
        action.setParams({
            caseRec:component.get("v.caseObj")
        });
        action.setCallback(this,function(response){
           var state = response.getState(response);
            
            if (state == 'SUCCESS') {
                alert('Case updated successfully.');
            } else if (state == 'ERROR') {
                console.log('Error => '+response.getError()[0].getMessage);
            }
        });
        $A.enqueueAction(action);
        
    }
})