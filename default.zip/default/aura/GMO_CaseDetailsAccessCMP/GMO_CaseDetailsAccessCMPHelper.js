({
    getPicklistVal : function(component,objName,fldName) {
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType: objName,
            selectedField: fldName
        });
        action.setCallback(this, function(response) {
            var pklist = response.getReturnValue();
            if(fldName == 'Origin' && objName == 'Case')
            	component.set("v.caseOrigin", pklist); 
            else if(fldName == 'Priority' && objName == 'Case')
                component.set("v.casePriority", pklist); 
            else if(fldName == 'GMO_ADS_Workflow_Stage__c' && objName == 'Case')
                component.set("v.workflowStage", pklist); 
            else if(fldName == 'GMO_ADS_Workflow_Status__c' && objName == 'Case')
                component.set("v.workflowStatus", pklist); 
        })
        
        $A.enqueueAction(action);
    }
})