({
    doInit : function(component, event, helper) {
        
    },
    
    cancelDialog : function(component, event, helper) {
        var homeEvt = $A.get("e.force:navigateToObjectHome");
        homeEvt.setParams({
            "scope": "GMO_IPMDM__c"
        });
        homeEvt.fire();
        
    },
    
    saveRecord : function(component, event, helper) {
        
    }
    
})