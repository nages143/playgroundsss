({
    init : function(component, event, helper) {
        var flow = component.find("flowData");
        flow.startFlow("GMO_Import_Request_New_Flow");
        
    }
})