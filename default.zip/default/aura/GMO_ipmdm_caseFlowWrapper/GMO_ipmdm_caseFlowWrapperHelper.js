({
    getFlowName: function (status) {

        if (status === 'Pre-Check') {
            return 'GMO_IPMDM_PreCheck_Accept_Case';
        } else if (status === 'Callback') {
            return 'bQuery_Callback_Flow'
        } else if (status === 'Processing') {
            return 'bQuery_Processing_Flow'
        } else if (status === 'Verification') {
            return 'bQuery_Verification_Flow'
        }else if (status === 'Complete') {
            return 'bQuery_QA_Flow'
        } else {
            return '';
        }
    }
})