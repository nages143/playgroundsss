({
	doInit : function(component, event, helper) {
        var action = component.get('c.getParentId');
        action.setCallback(this,function(response) {
            console.log('response===' , response.getReturnValue());
            createRecordEvent.setParams({
        "entityApiName": "Investor_Account__c",
        "defaultFieldValues": {
            "Account__c" : response.getReturnValue(),
            "Name" : "Account__c"
        }
    });
    createRecordEvent.fire();
        });
       $A.enqueueAction(action);
		var createRecordEvent = $A.get("e.force:createRecord");
    
	}
})