({  
    handleUploadFinished: function (cmp, event, helper) {
        var uploadedFiles = event.getParam("files");
        cmp.set("v.uploadedFiles", uploadedFiles);
        cmp.set("v.fileLength", uploadedFiles.length);
        cmp.set("v.firstFilename", uploadedFiles[0].name);
    },
    filesChanged: function (cmp, event, helper) {
        var value = event.getParam("value");
        var data = cmp.get("v.fileHistory");
        var fileHistory = value.concat(data);
        
        cmp.set("v.fileHistory", fileHistory);
    }
});