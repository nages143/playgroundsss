({    invoke : function(component, event, helper) {
    
    // Get the record ID attribute
    var record = component.get("v.recordId");
    
    window.location.href ="/"+record;    
}})