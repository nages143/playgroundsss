({
    init : function(cmp, event, helper) {
        // Figure out which buttons to display
        var availableActions = cmp.get('v.availableActions');
        for (var i = 0; i < availableActions.length; i++) {
            if (availableActions[i] == "PAUSE") {
                cmp.set("v.canPause", true);
            } else if (availableActions[i] == "BACK") {
                cmp.set("v.canBack", true);
            } else if (availableActions[i] == "NEXT") {
                cmp.set("v.canNext", true);
            } else if (availableActions[i] == "FINISH") {
                cmp.set("v.canFinish", true);
            }
        }
    },
    
    onButtonPressed: function(cmp, event, helper) {
        cmp.set("v.redirectOutput", false);
        var actionClicked = event.getSource().getLocalId();
        var navigate = cmp.get('v.navigateFlow');
        
        navigate(actionClicked);       
    },
    customRedirect: function(cmp,event, helper) {
        cmp.set("v.redirectOutput", true);
        var actionClicked = event.getSource().getLocalId();
        var navigate = cmp.get('v.navigateFlow');
        
        navigate(actionClicked);     
    },
    navToRecord: function(cmp, event, helper) {
        var recordId = cmp.get("v.recordId");
        var redirectEvt = $A.get("e.force:navigateToSObject");
        
        redirectEvt.setParams({
            "recordId": recordId
        }); 
        redirectEvt.fire();
    },
    navToObjHome: function(cmp, event, helper) {
        var objName = cmp.get("v.objName");  
        var redirect = $A.get("e.force:navigateToObjectHome");
       
        redirect.setParams({
            "scope": objName
        });
        redirect.fire();
    },
    closeQuickAction: function(cmp, event, helper) {
        $A.get('e.force:closeQuickAction').fire();
    }
})