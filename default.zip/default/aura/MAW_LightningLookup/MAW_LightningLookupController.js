({
    doInit: function(component, event) {
        var prevVal = component.get("v.selectedRecordId");
        event.setParam("v.selectedRecordId", defaultVal);
    },
    handleOnChange : function(component, event, helper) {
        component.set( "v.selectedRecordId", event.getParams( "fields" ).value );
    }
})