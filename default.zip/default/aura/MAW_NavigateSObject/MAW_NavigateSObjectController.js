({
    invoke: function(cmp, event, helper) {
        var objName = cmp.get("v.objName");  
        var redirect = $A.get("e.force:navigateToObjectHome");
        
        redirect.setParams({
            "scope": objName
        });
        redirect.fire();
    }
})