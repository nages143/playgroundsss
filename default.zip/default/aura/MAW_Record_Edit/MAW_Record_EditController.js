({
    init : function (component,event,helper) {
        // Find the component whose aura:id is "flowData"
        var flow = component.find("flowData");
        var recordId = component.get("v.recordId");
        var inputVariables = [
            { name : "varMAWRecordID", type : "String", value : recordId }
        ]
        // In that component, start your flow. Reference the flow's API Name.
        flow.startFlow("MAW_Marketing_Document_Record_Edit", inputVariables );
    },
})