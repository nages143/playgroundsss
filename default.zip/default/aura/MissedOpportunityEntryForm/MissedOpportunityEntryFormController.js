({
	handleSuccess : function(component, event, helper) {
		var payload = event.getParams().response;
		console.log(payload.id);
         // fire toast event
					var appEvent = $A.get("e.c:MissedOppCustomShowToastEvent");
					appEvent.setParams({
				        "duration": 6000,
				        "message": "Success",
				        "details": "Missed Opportunity Created",
				       "type": "success",
				        "mode": "dismissible"
				    });
        
				    appEvent.fire();
        			
	},

	handleOnError : function(component, event, helper) {
		var errors = event.getParams('detail'); 
        console.log("response", JSON.stringify(errors));
           
	},
    
    handleChange: function (component, event) {
        alert(event.getParam('value'));
    },
    
    handleProductChange: function (component, event, helper) {
        var product = event.getParam('value');
        helper.setDefaultByProduct(component,product);
        if(product == 'WarehouseLending') {
            component.set("v.toggleIcon","WarehouseLending");
            helper.hideAllComponents(component,"repoArea");
            helper.showAllComponents(component,"warehouseLendingArea");
        } else {
            component.set("v.toggleIcon","RepoReverseRepo");
            helper.hideAllComponents(component,"warehouseLendingArea");
            helper.showAllComponents(component,"repoArea");
        }
        
       
    },
    
    handleClientChange: function (component, event, helper) {        
        helper.setDefaultByClient(component,event,helper);
    },
 
    handleSubmit : function(component, event, helper) {
        event.preventDefault();
		var product = component.find('product').get('v.value');
        helper.setDefaultByProduct(component,product);
        
        var isAllDetailsPopulated = helper.validateForm(component,event);
        // if required fields are populated, please submit the form....    
        if(isAllDetailsPopulated) {
    		component.find("form").submit();
        }
	},
    
    handleCancel : function(component, event, helper) {
        event.preventDefault();
    	helper.openSummaryPage(component);
    },
    
    openSummaryPage: function(component, event, helper) {
		helper.openSummaryPage(component);
	},
    
    handleLoad : function(component, event, helper) {
        
		var userId = $A.get("$SObjectType.CurrentUser.Id");
		component.find('salesperson').set('v.value', userId);
        
        var today = new Date();
        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
		component.find('modate').set('v.value', date);
        
		helper.hideAllComponents(component,"warehouseLendingArea");
        helper.showAllComponents(component,"repoArea");
    },
        
    handleAttachment: function (cmp, event) {
        // This will contain the List of File uploaded data and status
        var uploadedFiles = event.getParam("files");
        alert("Files uploaded : " + uploadedFiles.length);
    },
    
    handleSaveClose : function(component,event,helper) {
        event.preventDefault();
        var product = component.find('product').get('v.value');
        helper.setDefaultByProduct(component,product);
        var isAllDetailsPopulated = helper.validateForm(component,event);
        // if required fields are populated, please submit the form and go do missed oppo page....    
        if(isAllDetailsPopulated) {
    		component.find("form").submit();
            helper.openSummaryPage(component);
        }
    },
    
    
    // handle enter key pressed
    keyCheck : function(component, event, helper){
       if (event.which == 13 ){
           event.preventDefault();
           var product = component.find('product').get('v.value');
           helper.setDefaultByProduct(component,product);
           
           var isAllDetailsPopulated = helper.validateForm(component,event);
           // if required fields are populated, please submit the form....    
           if(isAllDetailsPopulated) {
               component.find("form").submit();
           }
    	}    
      
    },
})