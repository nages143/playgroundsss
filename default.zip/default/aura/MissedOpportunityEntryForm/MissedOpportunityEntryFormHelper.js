({
	showAllComponents: function(component, aura_id) {
        component.find(aura_id).forEach(
        	area => $A.util.removeClass(area, "slds-hide")
        );
    },
    
	hideAllComponents: function(component, aura_id) {
        component.find(aura_id).forEach(
        	area => $A.util.addClass(area, "slds-hide")
        );
    },
    
    validateComponent: function(component, aura_id) {
    	var comp = component.find(aura_id).get('v.value');
    	if(comp==null || comp==''){
        	return false;
        }
        return true;
    },
    
    validateForm: function(component, event){
    	var product = component.find('product').get('v.value');
        var isAllDetailsPopulated = true;
        var errorDetails = "Please provide ";
        var errorComponents = "";
        
        if(this.validateComponent(component, 'collateral')==false){
           isAllDetailsPopulated = false;
           errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Collateral"; 
        }
        if(this.validateComponent(component, 'tenor')==false){
           isAllDetailsPopulated = false;
           errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Tenor (Months)"; 
        }
        if(this.validateComponent(component, 'currency')==false){
           isAllDetailsPopulated = false;
           errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Currency"; 
        }
        if(this.validateComponent(component, 'barclaysLevel')==false){
           isAllDetailsPopulated = false;
           errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Barclays Level (LIBOR+)"; 
        }
        if(product == 'WarehouseLending') {
            var barclaysAdvanceRateConv = component.find('barclaysAdvanceRateConv').get('v.value');
            var advanceRateAwayConv = component.find('advanceRateAwayConv').get('v.value');
            var advanceRateAwayJumbo = component.find('advanceRateAwayJumbo').get('v.value');
            if(this.validateComponent(component, 'barclaysAdvanceRateConv')==false){
               isAllDetailsPopulated = false;
               errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Barclays Advance Rate - Conv"; 
            }
            if(this.validateComponent(component, 'advanceRateAwayConv')==false){
               isAllDetailsPopulated = false;
               errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Advance Rate Away - Conv"; 
            }
            if(this.validateComponent(component, 'advanceRateAwayJumbo')==false){
               isAllDetailsPopulated = false;
               errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Advance Rate Away - Jumbo"; 
            }
        }
        else {
        	var barclaysHaircut = component.find('barclaysHaircut').get('v.value');
        	if(this.validateComponent(component, 'barclaysHaircut')==false){
               isAllDetailsPopulated = false;
               errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Barclays Haircut (%)"; 
            }
        }
        
        
        if(this.validateComponent(component, 'reasonNotTraded')==false){
           isAllDetailsPopulated = false;
           errorComponents = (errorComponents.length > 0 ? (errorComponents + ", ") : errorComponents)+"Reason Not Traded"; 
        }
        
        if(!isAllDetailsPopulated){
        // fire toast event
        
            errorDetails = errorDetails + errorComponents;
            var appEvent = $A.get("e.c:MissedOppCustomShowToastEvent");
				appEvent.setParams({
			        "duration": 6000,
			        "message": "Error",
			        "details": errorDetails,
			       "type": "Error",
			        "mode": "dismissible"
			    });
        
			    appEvent.fire();
          isAllDetailsPopulated = false;  
        }
        return isAllDetailsPopulated;
	},
    
    openSummaryPage: function(component) {
        var baseURL = window.location.hostname;
        baseURL = "https://"+baseURL+"/lightning/n/Summary1";
        window.open(baseURL,"_self")
    },
    
    showHideComponent: function(component, aura_id) {
        var comp = component.find(aura_id);
        $A.util.toggleClass(comp, "slds-hide");
    },
    
    setDefaultNumFieldValue: function(component, aura_id) {
        component.find(aura_id).set('v.value', "0");
    },
    
    setDefaultByProduct: function(component, product) {
        if(product == 'WarehouseLending') {
            this.setDefaultNumFieldValue(component,'barclaysBondPrice');
           	this.setDefaultNumFieldValue(component,'barclaysHaircut');
            this.setDefaultNumFieldValue(component,'levelAway');
            this.setDefaultNumFieldValue(component,'clientBondPrice');
            this.setDefaultNumFieldValue(component,'haircutAway');
        }
        else {
            this.setDefaultNumFieldValue(component,'barclaysAdvanceRateConv');
            this.setDefaultNumFieldValue(component,'advanceRateAwayConv');
            this.setDefaultNumFieldValue(component,'barclaysAdvanceRateJumbo');
            this.setDefaultNumFieldValue(component,'advanceRateAwayJumbo');
        }
    },
    
    setDefaultByClient : function(component,event,helper) {
       	var action = component.get("c.getAccountDetails");
        action.setParams({
        	'accountId': component.find('accountLookup').get('v.value')           
       	});
        
       	action.setCallback(this, function(response) {
       		var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue() != "null") {
                	component.find('clientClassification').set('v.value',response.getReturnValue()) ;
                }
                else {
                   	
                }
			}
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

})