({
    // =========================================
    // LOAD TREE
    // Entry : Id userId
    // Set : 
    // - USER currentUser 	: USER record of id :userId
    // - USER[] listReports 	: All reports of :userId
    // ==================================================
    loadTree : function(component, userId) {
        var useContacts = component.get("v.useContacts");
        var loadHierarchy = component.get("c.getHierarchy");
        loadHierarchy.setParams({ userid : userId, useContacts : useContacts });
        component.set("v.displayLoader",true); 
        loadHierarchy.setCallback(this, function(response) {
        var state = response.getState();
            if (state === "SUCCESS") {
                //If listReports is empty then show msg "NO records to display!"
                var isEmpty = $A.util.isEmpty(response.getReturnValue().listReports);
                var cmpTarget = component.find('error');
                if(isEmpty){
                    $A.util.removeClass(cmpTarget, 'hideErrorMsg');
                    $A.util.addClass(cmpTarget, 'showErrorMsg');
                    component.set("v.displayLoader",false);
                }else{
                    component.set("v.currentUser", response.getReturnValue().selectedUser);
                    component.set("v.listReports", response.getReturnValue().listReports); 
                    $A.util.removeClass(cmpTarget, 'showErrorMsg');
                    $A.util.addClass(cmpTarget, 'hideErrorMsg');
                    component.set("v.displayLoader",false);
                }//else if empty
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(loadHierarchy);
    },
})