({
    init : function(component, event, helper) {
        var flow = component.find("flowData");
        //Set Input parameters for flow
        var workspaceAPI = component.find("workspace");
        var demandportalId;
        alert(component.get("v.recordId"));
        workspaceAPI.getFocusedTabInfo().then(function(response) {demandportalId = response.subtabs.recordId;
                                                          alert(response);alert(demandportalId);});
        var inputVariables = [{name : "recordId", type : "String", value:demandportalId}];
      flow.startFlow("GMO_Demand_Portal_FTE_Benefits_Flow");
        
    }
})