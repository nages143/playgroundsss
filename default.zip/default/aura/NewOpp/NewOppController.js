({
    doInit : function(component, event, helper) {
        // var record = component.get("v.recordId");
        ///console.log(record);
        //console.log(component.get('v.pageReference'));
        //var accid = component.get("v.pageReference").state.additionalParams;
        //var accid1 = accid.split('=');
        //var accountid = accid1[1].replace('&','');
        //console.log(accountid);
        
        
        var today= new Date() ;
        console.log(today);
        function lastDateOfQuarter( date ){
            date.setFullYear(date.getFullYear()+1);
            if(date.getMonth()== 0 || date.getMonth()==1 || date.getMonth()==  2){
                date.setMonth(2); 
                date.setDate(31);
            }
            else if(date.getMonth()== 3 || date.getMonth()==4 || date.getMonth()==  5){
                date.setMonth(5); 
                date.setDate(30);
            }
                else if(date.getMonth()== 6 || date.getMonth()==7 || date.getMonth()==  8){
                    date.setMonth(8); 
                    date.setDate(30);
                }
                    else {
                        date.setMonth(11); 
                        date.setDate(31);
                    }
            return date;
        }
        var fdate = lastDateOfQuarter(today);
        console.log(fdate);
        component.set('v.setcloseDate',fdate.getFullYear() + "-" + (fdate.getMonth() + 1) + "-" + fdate.getDate());
        component.set('v.setDP','10%');
        
        //console.log(component.get('v.oppty.AccountId'));
        /*var values = [{ 
            type: 'Account', 
            id: "001P000001R9oF1IAJ",
            label: 'AccountName'            
            
        }]; */
        
        //component.set('v.oppty.AccountId','001P000001R9oF1IAJ');
        //component.find("aname").get("v.body")[0].updateValues();  
        //console.log(component.get("v.accRecord"));
        //console.log(value[0].id);
        //component.set('v.setaccount',value[0].id);
        //component.set('v.setRecordType','0121K000001EhokQAC');
        component.set('v.setStage','Prospecting');
        //console.log('Stage Set Done');
        component.find("forceRecord").getNewRecord(
            "Opportunity",
            null,
            false,
            $A.getCallback(function() {
                var rec = component.get("v.OppRecord");
                var error = component.get("v.recordError");
                
                if (error || (rec === null)) {
                    console.log("Error initializing record template: " + error);
                    return;
                }
            })
            
            
            
        );
        
    },
    
    
    saveplrecord: function(component,event,helper){
        var value = event.getParam("plvalue");
        var value1 = event.getParam("plvalue1");
        console.log(value1);
        component.set("v.OppRecord.BNK_Product_Name__c",value);
        component.set("v.OppRecord.BNK_Transaction_Type__c",value1);
    },
    
    saveRecord : function(component, event, helper) {
        console.log("hi");
        console.log("getvalues");
        
        var estdealsize = component.find("estdealsize");
        var exprev = component.find("exprev");
        var value = estdealsize.get("v.value");
        var value1 = exprev.get("v.value");
//        if(value<value1){
//            estdealsize.set("v.errors",[{message:"Deal Size Cannot be less than Revenue"}]);
//        }
//        else{
//            estdealsize.set("v.errors",null);
//        }
        
        component.set("v.OppRecord.Name", component.find('oppName').get("v.value"));    
        component.set("v.OppRecord.AccountId",component.find('aname').get("v.value") );
        component.set("v.OppRecord.CloseDate", component.find('closeDate').get("v.value"));
        //component.set("v.OppRecord.Probability",component.find('probability').get("v.value") );
        component.set("v.OppRecord.BNK_Deal_Probability__c",component.find('deal_probability').get("v.value") );
       // component.set("v.OppRecord.BNK_Barclays_Probability__c",component.find('barclays_probability').get("v.value") );
        component.set("v.OppRecord.StageName", component.find('Stage').get("v.value"));
        //component.set("v.OppRecord.BNK_Product_Name__c", component.find('ProCat').get("v.value"));
        component.set("v.OppRecord.DealSize__c", component.find('estdealsize').get("v.value"));
        component.set("v.OppRecord.BNK_Expected_Revenue__c", component.find('exprev').get("v.value"));
        //component.set("v.OppRecord.IsPrivate", component.find('checkbox').get("v.value"));
        //component.set("v.OppRecord.BNK_Inactive__c", component.find('bnkcheckbox').get("v.value"));
        //component.set("v.OppRecord.BNK_Transaction_Type__c", component.find('Trnsctntype').get("v.value"));
        component.set("v.OppRecord.Description", component.find('description').get("v.value"));
        
        component.set("v.OppRecord.Opportunity_Group__c", component.find('ogroup').get("v.value"));
        // component.set("v.OppRecord.BNK_Core_Number__c",component.find('corenum').get("v.value"));
        // component.set("v.OppRecord.BNK_Acct_Banker__c",component.find('abanker1').get("v.value") );
        //component.set("v.OppRecord.BNK_Acct_Banker2__c",component.find('abanker2').get("v.value") );
        
        console.log("Setting values Done");
        var tempRec = component.find("forceRecord");
        tempRec.saveRecord($A.getCallback(function(result) {
            console.log(result.state);
            var resultsToast = $A.get("e.force:showToast");
            //var name = component.find('oppName').get("v.value");
            //console.log(name);
            if (result.state === "SUCCESS") {
                resultsToast.setParams({
                    "title": "Saved",
                    "message": "Opportunity was created."
                });
                resultsToast.fire(); 
                var recId = result.recordId;
                helper.navigateTo(component, recId);
                
            } else if (result.state === "ERROR") {
                console.log('Error: ' + JSON.stringify(result.error));
                resultsToast.setParams({
                    "title": "Error",
                    "message": "There was an error saving the record: " + JSON.stringify(result.error)
                });
                resultsToast.fire();
                
            } else {
                console.log('Unknown problem, state: ' + result.state + ', error: ' + JSON.stringify(result.error));
            }
            
        }));
        
    },
    saveNewRecord: function(component, event, helper){
        /*
        var a = component.get('c.saveRecord');
        $A.enqueueAction(a);
        location.reload();*/
       console.log("hi");
        console.log("getvalues");
        
        var estdealsize = component.find("estdealsize");
        var exprev = component.find("exprev");
        var value = estdealsize.get("v.value");
        var value1 = exprev.get("v.value");
        //if(value<value1){
            //estdealsize.set("v.errors",[{message:"Deal Size Cannot be less than Revenue"}]);
        //}
       // else{
           // estdealsize.set("v.errors",null);
       // }
        
        component.set("v.OppRecord.Name", component.find('oppName').get("v.value"));    
        component.set("v.OppRecord.AccountId",component.find('aname').get("v.value") );
        component.set("v.OppRecord.CloseDate", component.find('closeDate').get("v.value"));
        //component.set("v.OppRecord.Probability",component.find('probability').get("v.value") );
        component.set("v.OppRecord.BNK_Deal_Probability__c",component.find('deal_probability').get("v.value") );
        //component.set("v.OppRecord.BNK_Barclays_Probability__c",component.find('barclays_probability').get("v.value") );
        component.set("v.OppRecord.StageName", component.find('Stage').get("v.value"));
        //component.set("v.OppRecord.BNK_Product_Name__c", component.find('ProCat').get("v.value"));
        component.set("v.OppRecord.DealSize__c", component.find('estdealsize').get("v.value"));
        component.set("v.OppRecord.BNK_Expected_Revenue__c", component.find('exprev').get("v.value"));
        //component.set("v.OppRecord.IsPrivate", component.find('checkbox').get("v.value"));
        //component.set("v.OppRecord.BNK_Inactive__c", component.find('bnkcheckbox').get("v.value"));
        //component.set("v.OppRecord.BNK_Transaction_Type__c", component.find('Trnsctntype').get("v.value"));
        component.set("v.OppRecord.Description", component.find('description').get("v.value"));
        
        component.set("v.OppRecord.Opportunity_Group__c", component.find('ogroup').get("v.value"));
        // component.set("v.OppRecord.BNK_Core_Number__c",component.find('corenum').get("v.value"));
        // component.set("v.OppRecord.BNK_Acct_Banker__c",component.find('abanker1').get("v.value") );
        //component.set("v.OppRecord.BNK_Acct_Banker2__c",component.find('abanker2').get("v.value") );
        
        console.log("Setting values Done");
        var tempRec = component.find("forceRecord");
        tempRec.saveRecord($A.getCallback(function(result) {
            console.log(result.state);
            var resultsToast = $A.get("e.force:showToast");
            //var name = component.find('oppName').get("v.value");
            //console.log(name);
            if (result.state === "SUCCESS") {
                resultsToast.setParams({
                    "title": "Saved",
                    "message": "Opportunity was created."
                });
                location.reload();
                resultsToast.fire(); 
                var recId = result.recordId;
                helper.navigateTo(component, recId);
                
            } else if (result.state === "ERROR") {
                console.log('Error: ' + JSON.stringify(result.error));
                resultsToast.setParams({
                    "title": "Error",
                    "message": "There was an error saving the record: " + JSON.stringify(result.error)
                });
                resultsToast.fire();
                
            } else {
                console.log('Unknown problem, state: ' + result.state + ', error: ' + JSON.stringify(result.error));
            }
            
        }));
         
    },
    cancelDialog : function(component, helper) {
        var homeEvt = $A.get("e.force:navigateToObjectHome");
        homeEvt.setParams({
            "scope": "Opportunity"
        });
        homeEvt.fire();
        
    }
    
    
})