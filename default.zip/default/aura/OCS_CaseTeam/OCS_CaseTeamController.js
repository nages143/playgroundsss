({
    doInit : function(component, event, helper) {
        var caseId =component.get("v.caseId");
        var action = component.get("c.getTeamRole");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.options",response.getReturnValue());
                component.set("v.userQueue",['User','Case Team']);                
                component.set("v.flag", 'true');
                component.set("v.newTeamMember.OCS_Parent_case__c",caseId);
                component.set("v.newTeamMember.OCS_Team_Member_Type__c",'User');
            }
        });
        $A.enqueueAction(action);
    },
    
    
    createCaseTeam : function(component, event) {
        debugger;
        var Name=component.get("v.selectedRecord");        
        component.set("v.newTeamMember.OCS_Team_member__c", Name.Id);
        var newTeamMember = component.get("v.newTeamMember");
        var action = component.get("c.saveCaseTeam");
        var caseId =component.get("v.caseId");
        
        action.setParams({ 
            "caseTeam": newTeamMember
        });
        
        action.setCallback(this, function(a) {
            var result =a.getReturnValue();            
            var state = a.getState();
            if (state === "SUCCESS") {          
                if(result ==$A.get("$Label.c.OCS_Success_Message")){
                    alert($A.get("$Label.c.OCS_Record_Saved_for_Case_Team"));
                    //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + caseId;
                    //  window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+'one.app#/sObject/'+ caseId +"/view", '_top');
                      //  window.location.href ='/one/one.app#/sObject/'+ caseId+"/view";
                       // window.open('/one/one.app#/sObject/'+ caseId+"/view" ,'_top');
                   // var urlEvent = $A.get("e.force:navigateToURL"); 
					//urlEvent.setParams({ 
					//"url":'/one/one.app#/sObject/'+ caseId +"/view" 
					//});
					//
					window.history.back();
                   // window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+'one.app#/sObject/'+ caseId +"/view", '_top');

                } else if(result ==$A.get("$Label.c.OCS_Failure_Message")){
                    alert($A.get("$Label.c.OCS_Please_add_mandatory_fields"));
                }else if(result ==$A.get("$Label.c.OCS_Error_Message")){
                    alert($A.get("$Label.c.OCS_Already_present_in_case_Team"));
                }
            } /*else if (state === "INCOMPLETE") {
                alert('Please Enter required Values(marked with *) ');
                  var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        alert("Error message: " + errors[0].message);
                    }
                } 
                else {
                    alert("Unknown error");
                }
            }*/
            
        });
        $A.enqueueAction(action);   
    },
    
    
    //Function to render Member Name Field based on the type (Quueue or User) 
    onMemberTypeChange:function(component, event){
        var newTeamMember = component.get("v.newTeamMember");     
        var type=newTeamMember.OCS_Team_Member_Type__c;
        var flag= 'true';
        if(type=='User'){
            flag='true';
        }else if(type=='Case Team'){
            flag='false';
            var action = component.get("c.getCaseTeams");
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.newTeamMember.OCS_Team_member__c",null);
                    component.set("v.predefinedCaseTeams",response.getReturnValue());                           
                }
            });
            $A.enqueueAction(action);            
        }
        component.set("v.flag", flag);
    },
    
    
    showAccess:function(component, event){
        var newTeamMember = component.get("v.newTeamMember"); 
        var teamMemberRole =newTeamMember.OCS_Member_Role__c;
        var roleObj =component.get("v.options");
        for (var i in roleObj) {
            if(roleObj[i].Name==teamMemberRole){
                if(roleObj[i].AccessLevel == 'Edit'){
                    component.set("v.newTeamMember.OCS_Case_Access__c", "Read/Write");                    
                }
                else {
                    component.set("v.newTeamMember.OCS_Case_Access__c", roleObj[i].AccessLevel);  
                }
            }
        }  
    },
    
    onCancel : function(component, event, helper) {
        var caseId =component.get("v.caseId");
       // window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+'one.app#/sObject/'+ caseId +"/view", '_top');
        // window.open('/one/one.app#/sObject/'+ caseId +"/view", '_top');
         window.history.back();
    },
    
    
    keyPressController : function(component, event, helper) {
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord");
        // check if getInputKeyWord size id more then 0 then open the lookup result List and 
        // call the helper 
        // else close the lookup result List part.   
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
        
    },
    
    // function for clear the Record Selaction 
    clear :function(component,event,helper){       
         
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.newTeamMember.OCS_Team_member__c",null);
        //component.set("v.selectedRecord" , null);
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
        
        // get the selected Account record from the COMPONETN event 	 
        var selectedUserGetFromEvent = event.getParam("userByEvent");
        
        component.set("v.selectedRecord" , selectedUserGetFromEvent);  
        debugger;
        console.log(selectedUserGetFromEvent);
        component.set("v.newTeamMember.OCS_Team_member__c",selectedUserGetFromEvent.Id);        
        component.set("v.newTeamMember.Name",selectedUserGetFromEvent.Name);
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },
    // automatically call when the component is done waiting for a response to a server request.  
    hideSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : false });
        evt.fire();    
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : true });
        evt.fire();    
    },
    
    
})