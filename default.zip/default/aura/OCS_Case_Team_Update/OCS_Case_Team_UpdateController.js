({
    doInit : function(component, event, helper) {
        helper.showTeamDetails(component);
        helper.showTeamRole(component);
        helper.onMemberTypeChange(component);
    },
    
    
    createCaseTeam : function(component, event) {
        var Name=component.get("v.selectedRecord");
        var newTeamMember = component.get("v.newTeamMember");
        var action = component.get("c.saveCaseTeam");
        var caseId =component.get("v.caseId");
        component.set("v.newTeamMember.OCS_Team_member__c", Name.Id);
        
        action.setParams({ 
            "caseTeam": newTeamMember
        });
        
        action.setCallback(this, function(a) {
            var result =a.getReturnValue();            
            var state = a.getState();
            if (state === "SUCCESS") {          
                if(result =='Success'){
                    alert($A.get("$Label.c.OCS_Record_Saved_for_Case_Team"));
                  //  window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + caseId+"/view";
                      window.location.href ='/one/one.app#/sObject/'+ caseId+"/view";
                } else if(result =='Fail'){
                    alert($A.get("$Label.c.OCS_Please_add_mandatory_fields"));
                }else if(result ==$A.get("$Label.c.OCS_Error_Message")){
                    alert($A.get("$Label.c.OCS_Already_present_in_case_Team"));
                }
            } 
        });
        $A.enqueueAction(action);   
    },
    
    
    
    
    showAccess:function(component, event){
        var newTeamMember = component.get("v.teamList[0]"); 
        var teamMemberRole =newTeamMember.OCS_Member_Role__c;
        var roleObj =component.get("v.options");
        for (var i in roleObj) {
            if(roleObj[i].Name==teamMemberRole){
                if(roleObj[i].AccessLevel == 'Edit'){
                    component.set("v.teamList[0].OCS_Case_Access__c", "Read/Write");                    
                }
                else {
                    component.set("v.teamList[0].OCS_Case_Access__c", roleObj[i].AccessLevel);  
                }
            }
        }  
    },
    
    onCancel : function(component, event, helper) {
        var teamdetails =component.get("v.teamList");
       // window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") + teamdetails[0].OCS_Parent_case__c+"/view";
        //window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+'one.app#/sObject/'+ teamdetails[0].OCS_Parent_case__c +"/view", '_top');
          window.open('/one/one.app#/sObject/'+ teamdetails[0].OCS_Parent_case__c+"/view", '_top');
    },
    
    
    keyPressController : function(component, event, helper) {
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord");
        // check if getInputKeyWord size id more then 0 then open the lookup result List and 
        // call the helper 
        // else close the lookup result List part.   
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
        
    },
    
    // function for clear the Record Selaction 
    clear :function(component,event,heplper){
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.teamdetails[0].OCS_Team_member__c",null);
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
        
        // get the selected User record from the COMPONETN event 	 
        var selectedUserGetFromEvent = event.getParam("userByEvent");
        
        component.set("v.selectedRecord" , selectedUserGetFromEvent); 
        component.set("v.teamdetails[0].OCS_Team_member__c",selectedUserGetFromEvent.Id);        
        component.set("v.teamdetails[0].Name",selectedUserGetFromEvent.Name);
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },
    // automatically call when the component is done waiting for a response to a server request.  
    hideSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : false });
        evt.fire();    
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : true });
        evt.fire();    
    },
    
    updateCaseTeam : function(component, event) {
        debugger;
        var Name=component.get("v.selectedRecord");       
        component.set("v.teamList[0].OCS_Team_member__c", Name.Id);
        component.set("v.teamList[0].Name", Name.Name);
        var updatedTeamMember = component.get("v.teamList[0]");
        var action = component.get("c.updateCaseTeamRec"); 
        action.setParams({ 
            "caseTeam": updatedTeamMember
        });
        
        action.setCallback(this, function(a) {
            var result =a.getReturnValue();            
            var state = a.getState();
            if (state === "SUCCESS") {
                if(result =='Success'){
                    //alert($A.get("$Label.c.OCS_Record_Saved_for_Case_Team"));
                    alert('Case Team Member Updated succesfully!');
                    //window.location.href = $A.get("$Label.c.OCS_Redirect_Page_on_Save") +updatedTeamMember.OCS_Parent_case__c+"/view";
                       window.open($A.get("$Label.c.OCS_Redirect_Page_on_Save")+'one.app#/sObject/'+ updatedTeamMember.OCS_Parent_case__c +"/view", '_top');
                } else if(result =='Fail'){
                    alert($A.get("$Label.c.OCS_Please_add_mandatory_fields"));
                }else if(result ==$A.get("$Label.c.OCS_Error_Message")){
                    alert($A.get("$Label.c.OCS_Already_present_in_case_Team"));
                }
            } 
        });
        $A.enqueueAction(action);   
    },
    
    
})