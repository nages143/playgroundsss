({
    searchHelper : function(component,event,getInputkeyWord) {
        // call the apex class method 
        var action = component.get("c.fetchUser");
        // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord
        });
        // set a callBack 
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                debugger
                console.log(storeResponse);
                // if storeResponse size is equal 0 ,display No Result Found... message on screen.
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", 'Search Result...');
                }
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        
    },
    
    
    showTeamDetails : function(component) {
        var action = component.get("c.showCaseTeam");
        action.setParams({
            "caseTeamId": component.get("v.recordId") 
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var res = response.getReturnValue();
            if (state === "SUCCESS") {  
                component.set("v.teamList",response.getReturnValue());
                debugger;
                console.log(response.getReturnValue());
                component.set("v.userQueue",['User','Case Team']);                
                component.set("v.flag", 'true');
                component.set("v.SearchKeyWord",res[0].Name);
                //component.set("v.newTeamMember.OCS_Parent_case__c",res[0].OCS_Parent_case__c);
                component.set("v.newTeamMember.OCS_Team_Member_Type__c",'User');
            }
        });
        $A.enqueueAction(action);
    },
    
    
    
    showTeamRole : function(component) {
        var caseId =component.get("v.caseId");
        var action = component.get("c.getTeamRole");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
                component.set("v.options",response.getReturnValue());
                component.set("v.userQueue",['User','Case Team']);                
                component.set("v.flag", 'true');
                component.set("v.newTeamMember.OCS_Parent_case__c",caseId);
                component.set("v.newTeamMember.OCS_Team_Member_Type__c",'User');
            }
        });
        $A.enqueueAction(action);
    },
    
    
    //Function to render Member Name Field based on the type (Quueue or User) 
    onMemberTypeChange:function(component){
        var action = component.get("c.getCaseTeams");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.newTeamMember.OCS_Team_member__c",null);
                component.set("v.predefinedCaseTeams",response.getReturnValue());                           
            }
        });
        $A.enqueueAction(action);  
    },
    
})