({
    init: function (component, event, helper) {
        helper.getOpportunityTableData(component);
    },

    getUserText: function(component, event, helper) {
        helper.getProfiles(component);
    },

    getSelectedEmployeeData: function(component, event, helper) {
        var index = event.currentTarget.dataset.record;
        helper.addSelectedUser(component, index);
    },

    saveTable: function(component, event, helper) {
        helper.saveTeamMembers(component);
    },

    onRoleChange: function(component, event, helper) {
        var index =  event.currentTarget.getAttribute("data-row");
        var data = component.get("v.opportunityTeamData");
        if(data[index].teamMemberRole["role"] == "Accountable Banker") {
            data[index].teamMemberRole["role"] = "Team";
        }
        else {
            if(data.filter(function(obj) {return obj.teamMemberRole["role"] == "Accountable Banker"}).length < 2) {
                data[index].teamMemberRole["role"] = "Accountable Banker";
            }
        }
        component.set("v.opportunityTeamData", data);
    },

    closeValidationModal: function(component) {
        component.set("v.isTableDataValidated", "default");
    },

    closeErrorModal: function(component) {
        component.set("v.isError", "default");
    }
})