({
    helperSortMethod : function(cmp, opportunityTeam) {
        opportunityTeam.forEach(function(element) {
            element.isChecked = (element.source == "accountCoverage" ?  false : true);
        });
                   
        var role_hierarchy = ["Team", "Accountable Banker"];
        var title_hierarchy = ["Analyst", "Assistant Vice President", "Vice President", "Director", "Managing Director"];
        
        function customSort(a, b) {
            if(role_hierarchy.indexOf(a['teamMemberRole']['role']) < role_hierarchy.indexOf(b['teamMemberRole']['role'])) return 1;
            if(role_hierarchy.indexOf(a['teamMemberRole']['role']) > role_hierarchy.indexOf(b['teamMemberRole']['role'])) return -1;
            
            if(title_hierarchy.indexOf(a['title']) < title_hierarchy.indexOf(b['title'])) return 1;
            if(title_hierarchy.indexOf(a['title']) > title_hierarchy.indexOf(b['title'])) return -1;
            return 0;
        }
        opportunityTeam.sort(customSort);
        cmp.set("v.opportunityTeamData", opportunityTeam);
    },

    getOpportunityTableData : function(cmp) {
        var currentOpportunityId = cmp.get("v.recordId");
        var action = cmp.get("c.getOpportunityTeam");
        action.setParams({opportunityId: currentOpportunityId});
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var opportunityTeam = response.getReturnValue();
                //console.log(opportunityTeam);
                if(opportunityTeam == null) {
                    cmp.set("v.opportunityTeamData", []);
                }
                else {
                    if(opportunityTeam[0]["source"] == "accountCoverage") {
                        cmp.set("v.isFromAccountCoverage", true);
                    }
                    this.helperSortMethod(cmp, opportunityTeam);
                }
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action);
    },

    getProfiles: function(cmp) {
        var action = cmp.get("c.getUserProfiles");
        var label = cmp.find("userInput").get("v.value");
        if(label.length > 2) {
            var opportunityTeamUserIds = cmp.get("v.opportunityTeamData").map(m => m["userId"]);
            action.setParams({label: label, opportunityTeamUserIds: opportunityTeamUserIds});
            action.setCallback(this, $A.getCallback(function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    cmp.set("v.employeeSearchData", response.getReturnValue());
                } else if (state === "ERROR") {
                    var errors = response.getError();
                    console.error(errors);
                    cmp.set("v.isError", "error");
                }
            }));
            $A.enqueueAction(action);
        }
        else {
            cmp.set("v.employeeSearchData", []);
        }

    },

    addSelectedUser: function(cmp, index) {
        var listOfSuggestions = cmp.get("v.employeeSearchData");
        var memberSelected = listOfSuggestions[index];
        var opportunityId = cmp.get("v.recordId");
        cmp.set("v.employeeSearchData", []);

        var tempObject = new Object();
        tempObject.name = memberSelected["Name"];
        tempObject.opportunityId = opportunityId;
        tempObject.teamMemberRole = {
            "options": ["Team", "Accountable Banker"],
            "role": "Team"
        };
        tempObject.title = memberSelected["BNK_Title_Desc__c"];
        tempObject.userId = memberSelected["BNK_User__c"];
        tempObject.primaryGroup = memberSelected["BNK_Group__c"];
        tempObject.opportunitylevelaccess = "Edit";
        tempObject.isChecked = true;
        
        var currentDateTime = new Date();
        tempObject.startDate = $A.localizationService.formatDateTimeUTC(currentDateTime, "yyyy-MM-dd");
		console.log(tempObject);
        var listOfTeamMembers = cmp.get("v.opportunityTeamData");
        listOfTeamMembers[listOfTeamMembers.length] = tempObject;
        cmp.set("v.opportunityTeamData", listOfTeamMembers);
        cmp.find("userInput").set("v.value", "");
    },

    saveTeamMembers: function(cmp) {
        var listOfTeamMembers = cmp.get("v.opportunityTeamData");
        var action = cmp.get("c.saveOpportunityTeamMembers");
        var currentOpportunityId = cmp.get("v.recordId");
        var checkedMembers = listOfTeamMembers.filter(function(obj) {return obj.isChecked});
        //console.log(checkedMembers);
        if(this.checkForValidation(checkedMembers)) {
            checkedMembers.forEach(function(element) {$A.localizationService.formatDateTimeUTC(element.startDate, "yyyy-MM-dd");})
            action.setParams({opportunityId: currentOpportunityId, outputData: checkedMembers});
            action.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    this.getOpportunityTableData(cmp);
                    cmp.set("v.isFromAccountCoverage", false);
                } else if (state === "ERROR") {
                    var errors = response.getError();
                    console.error(errors);
                    cmp.set("v.isError", "error");
                }
            });
            $A.enqueueAction(action);
        }
        else {
            console.log("ERROR!!");
            cmp.set("v.isTableDataValidated", "inValid");
        }
       
    },

    checkForValidation: function(checkedMembers) {
        for(var i=0; i<checkedMembers.length; i++) {
            if (checkedMembers[i]["teamMemberRole"]["role"] === "Accountable Banker") {
                if((checkedMembers[i]["title"] != "Managing Director") && (checkedMembers[i]["title"] != "Director")) {
                    return false;
                }
            }
        }

        return true;
    }

})