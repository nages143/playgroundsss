({
	getPlugin : function(component, event, helper) 
	{
		const PARAMETERS = event.getParam("arguments");
		console.log("lightning!");

		return new Promise($A.getCallback((resolve, reject) => {
			let action = component.get("c.getApexPlugin");
			action.setParams({
				FEATURE_PATH : PARAMETERS.featurePath,
				CONTEXT : PARAMETERS.context
			});
			action.setCallback(this, response =>
				resolve(JSON.parse(response.getReturnValue()))
			);
			$A.enqueueAction(action);
		}));
	}
})