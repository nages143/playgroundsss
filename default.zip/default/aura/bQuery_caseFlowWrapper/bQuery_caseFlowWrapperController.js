({
    
    handleRecordUpdated: function (component, event, helper) {

        var eventParams = event.getParams();
        console.log("event params = " + JSON.stringify(eventParams));
        if (eventParams.changeType === "LOADED" || eventParams.changeType === "CHANGED") {
            var flow = component.find("flow");
            var status = component.get("v.caseRecord").Status;
            var recordId = component.get("v.recordId");
            //component.set("v.caseStatus", status);
            console.log("here - status = " + status);
            console.log("here - recordId = " + recordId);

            var flowName = helper.getFlowName(status);
            console.log("here - flowName = " + flowName);
            if (flowName != '') {
                var flowInput = [{ name: 'recordId', type: 'String', value: recordId }];
                flow.startFlow(flowName, flowInput);
            }
        }
    },
    handleStatusChange : function (component, event) {
        console.log("event is "+JSON.stringify(event));
        
        if(event.getParam("status") === "FINISHED") {
            
            var outputVariables = event.getParam("outputVariables");
            var customFlowName = outputVariables.find( variable => variable.name === 'varFlowName' );
            console.log("flowName = "+ customFlowName );

            if(!customFlowName){
                $A.get('e.force:refreshView').fire();
            }
        }
    }
})