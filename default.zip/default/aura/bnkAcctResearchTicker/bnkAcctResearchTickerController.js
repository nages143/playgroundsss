({
	openLinks : function(component, event, helper) {
       // var link1 = "https://my.barcapint.com/BC/barcaplive?menuCode=CrResearch&amp;url=/BC/S/composite/RSL_COMPANY_NEW?ticker=" + component.get("v.accountRecord").BNK_Ticker_Symbol__c;
       // var link2 = "https://my.barcapint.com/BC/S/bcl/search?term="  +component.get("v.accountRecord").BNK_Ticker_Symbol__c ;
       // window.open (link2,'_blank');
		var link2 = component.get("v.accountRecord").Researchpagelink__c ;
        // console.log(link2);
        var tickerUrl1 = link2.split( '"' );
        // console.log(tickerUrl1);        
        var tickerUrl2 = tickerUrl1[1].split('" target=');        
        // console.log(tickerUrl2);
        window.open (tickerUrl2[0],'_blank');
	}
})