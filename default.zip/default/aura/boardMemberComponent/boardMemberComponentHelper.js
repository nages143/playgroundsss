({
    helperMethod : function() {

    },

    getBoardMemberData: function (component){
        var currentAccountId = component.get("v.recordId");
        console.log(currentAccountId);
        var action = component.get("c.getBoardMembers");
        var boardMembers = component.get("v.boardMemberData");
        var cSuiteMembers = component.get("v.cSuiteMemberData");
        component.set("v.boardMemberData", []);
        component.set("v.cSuiteMemberData" , []);

        action.setParams({accountId: currentAccountId});
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                // Filter data based on Board Members OR C-SUITE members
                // Set values for Board Members/C-Suite for respective Lists
                // Sort each List based on respective role hierarchy 
                let dataFromAPI = response.getReturnValue();
                let BoardMembersList = [];
                let CSuiteMembersList = [];
                dataFromAPI.forEach( data => {
                    if(data.IsBoardMember === true){
                        let boardMember = data;
                        // filter based on role hierarchy.
                        BoardMembersList.push(boardMember);
                    }
                })
                component.set('v.boardMemberData', BoardMembersList);
                // component.set('v.cSuiteMemberData', CSuiteMembersList);
                console.log(BoardMembersList);
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
            }
        });
        $A.enqueueAction(action);
        


        // var boardMembers = [
        //     { id: 8, role: 'AVP', address: '745 Seventh Avenue New York NY 10019, USA', phone:'+1 212 320 6747' , email: 'dexter.zhao@barclays.com', title: 'Assistant Vice President', name: 'Dexter Zhao' },
        //     { id: 6, role: 'AVP', address: '745 Seventh Avenue New York NY 10019, USA', phone:'+ 1 212 320 0966' , email: 'anurag.roy@barclays.com', title: 'Assistant Vice President', name: 'Anurag Roy' },
        //     { id: 7, role: 'VP',  address: '745 Seventh Avenue New York NY 10019, USA', phone:'+ 1 212 320 4474', secondaryphone: '+1 732 208 0006' , email: 'bhuvanrajdeepak.iyer@barclays.com', title: 'Vice President', name: 'Bhuvanraj Deepak'},
        //     { id: 9, role: 'VP',  address: '745 Seventh Avenue New York NY 10019, USA', phone:'+ 1 212 320 6757', secondaryphone: '+ 1 (1) 9176084527' , email: 'stephen.merkle@barclays.com', title: 'Vice President', name: 'Stephen Merkle'},
        //     { id: 1, role: 'CEO', address: '1 Churchill Place London, Greater London E14 5HP, United Kingdom', phone:'+ 44 (0) 207 116 6300', secondaryphone: '+1 212 526 4888' , email: 'jes.staley@barclays.com', title: 'Chief Executive Officer', name: 'Jes Staley' },
        //     { id: 4, role: 'CLO', address: '1 Churchill Place London, Greater London E14 5HP, United Kingdom', phone:'' , email: 'bob.hoyt@barclays.com', title: 'Chief Legal Officer', name: 'Bob Hoyt' },
        //     { id: 3, role: 'CFO', address: '1 Churchill Place London, Greater London E14 5HP, United Kingdom', phone:'+ 44 (0) 20-7773 7004' , email: 'steven.ewart@barclays.com', title: 'Chief Finance Officer', name: 'Steve Ewart' },
        //     { id: 5, role: 'CAO', address: '1 Churchill Place London, Greater London E14 5HP, United Kingdom', phone:'+ 44 (0) 207 116 1200' , email: 'tushar.morzaria@barclays.com', title: 'Chief Accounting Officer', name: 'Tushar Morzaria' },
        //     { id: 2, role: 'COO', address: '1 Churchill Place London, Greater London E14 5HP, United Kingdom', phone:'+ 44 (0) 207 773 1788' , email: 'mark.ashton-rigby@barclays.com', title: 'Chief Operating Officer', name: 'Mark Ashton-Rigby' }
        // ];

        // var role_hierarchy = ["AVP", "VP", "CAO", "CLO", "CFO", "COO", "CEO"];

        // function customSort(a, b) {
        //     if (role_hierarchy.indexOf(a['role']) < role_hierarchy.indexOf(b['role'])) return 1;
        //     if (role_hierarchy.indexOf(a['role']) > role_hierarchy.indexOf(b['role'])) return -1;
        //     return 0;
        // }

        // boardMembers.sort(customSort);
        // component.set("v.boardMemberData", boardMembers)
    },

    selectBoardMember: function (component, event){
        component.set("v.selectBoardMember", null);
        var boardMembers = component.get("v.boardMemberData");
        var selectedBoardMember = boardMembers[event.target.id];
        component.set("v.selectedBoardMember", selectedBoardMember);
    }
})