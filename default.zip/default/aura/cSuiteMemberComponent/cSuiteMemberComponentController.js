({
    init: function (component, event, helper) {
        helper.getBoardMemberData(component);
    },

    handleOpenModal: function (component, event, helper) {
        helper.selectBoardMember(component, event);
    },

    handleCloseModal: function (component) {
        component.set('v.selectedBoardMember', null);
    }


})