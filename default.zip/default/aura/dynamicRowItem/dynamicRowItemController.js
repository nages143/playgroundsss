({
    onPicklistChange: function(component, event, helper) {
        // get the value of select option
        //alert(event.getSource().get("v.value"));
        var surveyResponseInstance = component.get("v.surveyResponseInstance");
        component.set("v.selectedRatingValue", surveyResponseInstance.Rating__c);
        component.set("v.surveyResponseInstance.Reason__c","");
        //alert(surveyResponseInstance.Reason__c);
    },
    
    doInit : function(component, helper) {
        var ReasonMap = component.get("v.ReasonMap");
        var surveyResponseInstance = component.get("v.surveyResponseInstance");
        component.set("v.selectedRatingValue", surveyResponseInstance.Rating__c ? surveyResponseInstance.Rating__c : component.get("v.defaultRatingValue"));   
        
        if(surveyResponseInstance && ReasonMap){
            component.set("v.lstReasons", ReasonMap[surveyResponseInstance.CSAT_Survey_Question__name + surveyResponseInstance.Product__c]);
        }
        var selectedValue = surveyResponseInstance.Reason__c.split(";");
        component.set("v.selectedlstReasons",selectedValue);
    },
})