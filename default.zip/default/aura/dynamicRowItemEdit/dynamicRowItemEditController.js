({
    onPicklistChange: function(component, event, helper) {
        //alert(event.getSource().get("v.value"));
        var surveyResponseInstance = component.get("v.surveyResponseInstance");
        component.set("v.selectedRatingValue", surveyResponseInstance.Rating__c);
        component.set("v.surveyResponseInstance.Reason__c","");
    },
    
    doInit : function(component, helper) {
        var ReasonMap = component.get("v.ReasonMap");
        var surveyResponseInstance = component.get("v.surveyResponseInstance");
        component.set("v.selectedRatingValue", surveyResponseInstance.Rating__c ? surveyResponseInstance.Rating__c : component.get("v.defaultRatingValue"));   
        
        if(surveyResponseInstance && ReasonMap){
            component.set("v.lstReasons", ReasonMap[surveyResponseInstance.CSAT_Survey_Question__name + surveyResponseInstance.Product__c]);
        }
        var selectedValue = surveyResponseInstance.Reason__c.split(";");
        var lstReason = component.get("v.lstReasons");
        
        var opts = [];
        for(var i = 0, size = lstReason.length; i < size ; i++){
            opts.push({
                'class': 'optionClass',
                'label': lstReason[i],
                'value': lstReason[i],
                'selected': false
            }); 
        }
        for(var i=0; i<opts.length; i++){
        	for(var j = 0, size = selectedValue.length; j < size ; j++){
                if(opts[i].label == selectedValue[j]){
                 	opts[i].selected = true;   
                }
            }
        }
        console.log(opts);
        component.set("v.selectedlstReasons",opts);
    },
    onNpsScoreChange : function(component, event, helper){
    	
    },
})