({
    doInit : function(component, event, helper) {
        helper.getCase(component, '', []);
    },
    searchKeyChange : function(component, event, helper){ 
        debugger;
        var searchKey = event.target.value;
        helper.getCase(component, searchKey, component.get("v.selectedCases"));  
        /*var searchList = [];
        for(var cse in lstCases){
            var keys = Object.keys(lstCases[cse]);
            for(var key in keys){
                
                if(lstCases[cse][keys[key]] == true){                    
                    searchList.push(lstCases[cse]);
                    break;
                }else if(lstCases[cse][keys[key]] != false){
                    if(lstCases[cse][keys[key]].indexOf(searchKey) > -1){                  
                        searchList.push(lstCases[cse]);
                        break;
                    }
                }
                
            }
        }
        component.set("v.searchedCases", searchList); */
    },
    doSomething : function(component, event, helper) {  
            
        var lstCases = component.get("v.lstCases"); 
        var caseRecords = component.get("v.selectedCases");
        if(caseRecords.length == 2){
            if(!$A.util.isEmpty(caseRecords) && !$A.util.isUndefined(caseRecords)){           
                var action = component.get("c.performAction"); 
                action.setParams({
                    CaseRecords : caseRecords
                });
                action.setCallback(this,function(a){
                    var state = a.getState();               
                    if(state == "SUCCESS"){                   
                        var result = a.getReturnValue();
                        if(!$A.util.isEmpty(result) && !$A.util.isUndefined(result))
                            component.set("v.relatedRecords",result);
                        	console.log(result);
                    } else if(state == "ERROR"){
                        alert('Error in calling server side action');
                    }
                });      
                $A.enqueueAction(action);     
            }       
        }else{
            alert('Please select 2 cases to merge');
        }
    },
    manageCases : function(component, event, helper) {
    	debugger;
        var index = event.currentTarget.getAttribute('data-index');
        var lstCases = component.get("v.lstCases");
        var selectedCases = component.get("v.selectedCases");
        var caseId = lstCases[parseInt(index)]['CaseId'];
        if(selectedCases.indexOf(caseId) == -1)
            selectedCases.push(caseId);
        else
            selectedCases.splice(selectedCases.indexOf(caseId), 1);
		component.set("v.selectedCases", selectedCases);
    }
})