({
    getCase : function(component, searchKey, lstCaseIds) {		
        var action = component.get("c.getCaseRecords");
        action.setParams({
            searchKey : searchKey,
            lstCaseIds : lstCaseIds
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            if(state == "SUCCESS"){
                debugger;
                var result = a.getReturnValue();
                if(!$A.util.isEmpty(result) && !$A.util.isUndefined(result)){
                    //component.set("v.searchedCases", result);
                    component.set("v.lstCases", result);
                   
                }
            } else if(state == "ERROR"){
                alert('Error in calling server side action');
            }
        });      
        $A.enqueueAction(action);
    }
})