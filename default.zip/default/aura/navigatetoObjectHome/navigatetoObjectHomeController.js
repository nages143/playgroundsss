({
init : function (component, event, helper) {
    var homeEvent = $A.get("e.force:navigateToObjectHome");
    homeEvent.setParams({
        "scope": "GMO_Physical_Process__c"
    });
    homeEvent.fire();
}
})