({
    // init handler
	doInit : function(cmp, event, helper) {        
		// stop spinner
        cmp.set('v.loaded', true);	
        // set column definitions
        cmp.set('v.columns', helper.getColumnDefinitions());  
	},
    
    // cache column widths
    storeColumnWidths: function (cmp, event, helper) {
        helper.storeColumnWidths(event.getParam('columnWidths'));
    },
    
    // reset column preferences
    resetColumns: function (cmp, event, helper) {
        helper.resetLocalStorage();
        cmp.set('v.columns', helper.getColumnDefinitions());
    },
    
    // client-side controller called by the onsort event handler
    updateColumnSorting: function (cmp, event, helper) {
        cmp.set('v.isLoading', true);
        // We use the setTimeout method here to simulate the async
        // process of the sorting data, so that user will see the
        // spinner loading when the data is being sorted.
        setTimeout(function() {
            var fieldName = event.getParam('fieldName');            
            var sortDirection = event.getParam('sortDirection');
            // assign the latest attribute with the sorted column fieldName and sorted direction
            cmp.set("v.sortedBy", fieldName);
            cmp.set("v.sortedDirection", sortDirection);
            helper.sortData(cmp, fieldName, sortDirection);
            cmp.set('v.isLoading', false);
        }, 0);
    },    
    
    // row-level action event handler
    handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            // show details action    
            case 'show_details':
                // start spinner
        		cmp.set('v.loaded', false);
                helper.showDetails(cmp, row);
                break;
            // view assignment action    
            case 'view_assignment':
                helper.viewAssignment(row['accountId']);
                break;    
        }
    }, 
    
    // method to handle inline edit save action
    handleSave: function (cmp, event, helper) {
         // start spinner
         cmp.set('v.loaded', false);
         var draftValues = event.getParam('draftValues');
         helper.saveData(cmp, draftValues);
    },
    
})