({    
    // helper method to set column definitions for the data table
    getColumnDefinitions: function () {
        var columnsWidths = this.getColumnWidths();
        var actions = [
            { label: 'Show details', name: 'show_details', iconName: 'utility:table'},
            { label: 'View assignment', name: 'view_assignment', iconName: 'utility:link'}
        ]; 
        var columns = [
            {label: 'Order #', fieldName: 'orderName', type: 'text', sortable: 'true'},
            {label: 'Account Id', fieldName: 'accountId', type: 'text', sortable: 'true'},
            {label: 'Account Name', fieldName: 'accountName', type: 'text', sortable: 'true'},
            {label: 'Invoice Group', fieldName: 'invoiceGroup', type: 'text', sortable: 'true'},
            {label: 'Start Date', fieldName: 'startDate', type: 'date-local', sortable: 'true', editable: 'true'},
            {label: 'End Date', fieldName: 'endDate', type: 'date-local', sortable: 'true', editable: 'true'},
            {label: 'Status', fieldName: 'orderStatus', type: 'text', sortable: 'true'},
            {type: 'action', typeAttributes: { rowActions: actions }}
        ];

        if (columnsWidths.length === columns.length) {
            return columns.map(function (col, index) {
                return Object.assign(col, { initialWidth: columnsWidths[index] });
            });
        }
        
        return columns;
    },
    
    // helper method to sort data
    sortData: function (cmp, fieldName, sortDirection) {
        var data = cmp.get("v.data");
        var reverse = sortDirection !== 'asc';
	
        data = Object.assign([],
            data.sort(this.sortBy(fieldName, reverse ? -1 : 1))
        );
        cmp.set("v.data", data);
    },
    
    // helper method to sort the rows based on the column header that's clicked
    sortBy: function (field, reverse, primer) {
        var key = primer
            ? function(x) { return primer(x[field]) }
            : function(x) { return x[field] };
		// checks if the two rows should switch places
        return function (a, b) {
            var A = key(a);
            var B = key(b);
            return reverse * ((A > B) - (B > A));
        };
    },
    
    // helper method to cache columns widths
    storeColumnWidths: function (widths) {
        localStorage.setItem('datatable-in-action', JSON.stringify(widths));
    },
    
    // helper method to refresh cache
    resetLocalStorage: function () {
        localStorage.setItem('datatable-in-action', null);
    },
    
    // helper method to get cached column widths
    getColumnWidths: function () {
        var widths = localStorage.getItem('datatable-in-action');

        try {
            widths = JSON.parse(widths);
        } catch(e) {
            return [];
        }
        return Array.isArray(widths) ? widths : [];
    },
    
    // helper method to show details modal
    showDetails: function(cmp, row) {
        
        // get selected attributes
        var assignmentId = row['assignmentId'];
        var parentId = row['parentId'];
        var packageOrder;
        var assignmentItemOrders = [];
        
        // get assignment data set list
        var assignDataSetList = cmp.get('v.packageAssignmentDataSetList');
        
        // iterate over data set list
        for(var i=0; i<assignDataSetList.length; i++) {
            
            // assignment id match
            if(assignDataSetList[i].asgGroupInfo.Id === assignmentId) {
                
               // iterate over orders
               for(var j=0; j<assignDataSetList[i].pkgOrders.length; j++) {
                        
                   // parent id match
                   if(assignDataSetList[i].pkgOrders[j].pkgOrderInfo.ParentId__c === parentId) {
                      packageOrder = assignDataSetList[i].pkgOrders[j];
                      break;
                   }
               }   
                    
               // iterate over assignment items
               for(var k=0; k<assignDataSetList[i].asgGroupItems.length; k++) {
                        
                   // iterate over assignment item orders
                   for(var l=0; l<assignDataSetList[i].asgGroupItems[k].asgItemOrders.length; l++) {
                        	
                        // parent id match
                        if(assignDataSetList[i].asgGroupItems[k].asgItemOrders[l].orderExternalId === parentId) {
                           assignmentItemOrders.push(assignDataSetList[i].asgGroupItems[k].asgItemOrders[l]); 
                           break;
                        }
                            
                   }
                    
                }
            	break;    
            }
        }
        
        // set attributes
        cmp.set('v.packageOrder', packageOrder);
        cmp.set('v.assignmentItemOrders', assignmentItemOrders);
        
        // stop spinner
        cmp.set('v.loaded', true);
        
        // show details modal
        cmp.set('v.showDetails', true);
        
    },
    
    // helper method to link to package assignment
    viewAssignment: function(id) {
        var url = $A.get("$Label.c.PSAssignPackageLink")+id;
        var win = window.open(url, '_blank');
  		win.focus();
    },
    
    // helper method to save inline edits
    saveData : function(cmp, draftValues) {
    	
    	// get data
    	var data = cmp.get('v.data');
    	
    	// init update list
    	var updateList = [];
    	
    	// iterate over draft values
    	for(var i=0; i<draftValues.length; i++) {
    	
    		// iterate over data
    		for(var j=0; j<data.length; j++) {
    		
    			// id match
    			if(draftValues[i]['parentId']===data[j]['parentId']) {
    			
    				// init dates
    				var startDate = data[j]['startDate'];
    				var endDate = data[j]['endDate'];  
    			
    				// get start date
    				if(!$A.util.isEmpty(draftValues[i]['startDate'])) {
    					startDate=draftValues[i]['startDate'];
    				}
    				
    				// get end date
    				if(!$A.util.isEmpty(draftValues[i]['endDate'])) {
    					endDate=draftValues[i]['endDate'];
    				}
    				
    				// update data
    				data[j]['startDate'] = startDate;
    				data[j]['endDate'] = endDate;
    				
    				// load update list
    				updateList.push({
    					'assignmentId': data[j]['assignmentId'],
    					'parentId': data[j]['parentId'],
    					'startDate': startDate,
    					'endDate': endDate
    				});
    				
    				break;
    			
    			}
    		
    		}
    	
    	}
    	
    	// get assignment data set list
    	var assignDataSetList = cmp.get('v.packageAssignmentDataSetList');
    	
    	// iterate over the update list
        for(var k=0; k<updateList.length; k++) {
            
            // iterate over package assignment data set list
            for(var l=0; l<assignDataSetList.length; l++) {
                    
                // assignment id match
                if(assignDataSetList[l].asgGroupInfo.Id === updateList[k]['assignmentId']) {
                    	
                   // iterate over orders
                   for(var m=0; m<assignDataSetList[l].pkgOrders.length; m++) {
                       
                       // parent id match
                       if(assignDataSetList[l].pkgOrders[m].pkgOrderInfo.ParentId__c === updateList[k]['parentId']) {
                           // set start and end dates
                           assignDataSetList[l].pkgOrders[m].pkgOrderInfo.StartDate__c=updateList[k]['startDate'];
                           assignDataSetList[l].pkgOrders[m].pkgOrderInfo.EndDate__c=updateList[k]['endDate'];
                       }
                            
                    }
                    
                    // iterate over assignment items
                    for(var n=0; n<assignDataSetList[l].asgGroupItems.length; n++) {
                    
                    	// iterate over assignment item orders
                    	for(var o=0; o<assignDataSetList[l].asgGroupItems[n].asgItemOrders.length; o++) {
                    	
                    		// parent order match
                            if(assignDataSetList[l].asgGroupItems[n].asgItemOrders[o].orderExternalId === updateList[k]['parentId']) {
                            
                               // iterate over assignment item packages
                               for(var p=0; p<assignDataSetList[l].asgGroupItems[n].asgItemOrders[o].asgItemPkgs.length; p++) {
                               
                            	   // set commencement date
                            	   assignDataSetList[l].asgGroupItems[n].asgItemOrders[o].asgItemPkgs[p].asgItemPkgInfo.CommencementDate__c=updateList[k]['startDate'];
                            	   
                               }
                               break;
                            
                            }
                    	
                    	}
                    
                    }
                    
                    break;
                        
                }
                    
            }
            
        }
    	
    	// set attributes
    	cmp.set('v.packageAssignmentDataSetList', assignDataSetList);
    	cmp.set('v.data', data);
    	cmp.set('v.draftValues', []);
    	
    	// stop spinner
        cmp.set('v.loaded', true);
    	    
    },
    
})