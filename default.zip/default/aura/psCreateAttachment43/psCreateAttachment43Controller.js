({
    // save button click handler
	saveClicked : function(cmp, event, helper) {
	
		// validate form
		if(helper.isAllValid(cmp)) {
		
		   // submit attachment
		   helper.submitAttachment(cmp);
			
		   // close dialog
		   cmp.set('v.showCreateAttachmentDialog', false);
		}
		else {
		   
		   // fire toast event
		   var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		   appEvent.setParams({
			   "duration": 5000,
		       "message": $A.get("$Label.c.PSErrorMessage1"),
		       "details": cmp.get("v.errorDetail"),
		       "type": "error",
		       "mode": "dismissible"
		   });
		   appEvent.fire();
			
		}
		
	},
	
	// cancel button click handler
	cancelClicked : function(cmp, event, helper) {
		// close dialog
		cmp.set('v.showCreateAttachmentDialog', false);
	},
})