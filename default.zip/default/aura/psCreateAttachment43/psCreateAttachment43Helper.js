({ 
	// helper method to validate form 
    isAllValid : function(cmp) {
    
    	// init flag
    	var isAllValid=true;
    	
		// validate title
		var attTitle = cmp.get("v.attTitle");
		if($A.util.isEmpty(attTitle)) {
		   isAllValid=false;
		   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage72"));
		}
		
		return isAllValid;
    
    },
    
    // helper method to submit attachment
    submitAttachment : function(cmp) {
    	// get attachment details
    	var recordId = cmp.get('v.recordId');
    	var parentId = cmp.get('v.parentId');
    	var attTitle = cmp.get('v.attTitle');
    	var attDesc = cmp.get('v.attDescription');
    	// fire create attachment event
    	var appEvent = $A.get("e.c:psCreateAttachmentEvent43");
        appEvent.setParams({
          "recordId": recordId,
          "parentId": parentId,
    	  "attachmentTitle": attTitle,
          "attachmentDescription": attDesc,
          "renderMode": cmp.get('v.renderMode')
        });
        appEvent.fire();
    },
})