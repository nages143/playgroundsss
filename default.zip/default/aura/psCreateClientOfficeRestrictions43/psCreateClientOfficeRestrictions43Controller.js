({
	// init handler
	doInit : function(cmp, event, helper) {		
	
		// show spinner
		cmp.set('v.isLoading', true);
		
		// get client offices
		helper.getClientOffices(cmp);
		
		// load data set
		helper.loadDataSet(cmp);
		
	},
	
    // save button click handler
	saveClicked : function(cmp, event, helper) {
			helper.isValid(cmp,event,helper);
        
         if(cmp.get("v.isValid")){
			// show spinner
			cmp.set('v.isLoading', true);
			
		    // save restrictions
			helper.updateRestrictions(cmp,event,helper);
        	
       
			// close dialog
			cmp.set("v.showCORestrictions", false);
			cmp.set("v.isEditAssignment", true);
        }
			
	},
	 
     
     
	// cancel button click handler
	cancelClicked : function(cmp, event, helper) {
		
		// refresh data set
		helper.loadDataSet(cmp);
				
		// Close dialog
		cmp.set("v.showCORestrictions", false);
		
	},
    
    // handleclientOfficeChange
	handleclientOfficeChange : function(cmp, event, helper) {
        var removedRestrictions = [];
        var addedRestrictions = [];
		// get values
		var values = cmp.get('v.values');
		//alert('@@values'+values);
		// get restrictions
		var newRestrictions = cmp.get("v.newRestrictions");
		//alert('existing restriction'+JSON.stringify(newRestrictions));
		// init selected restrictions array
		var selRestrictions = [];
		
		// restrictions not empty
		if(!$A.util.isEmpty(newRestrictions)) {
			
			// iterate over restrictions
			for(var i=0; i<newRestrictions.length; i++) {
			
				// values not empty
				if(!$A.util.isEmpty(values)) {
						
					// restrictions exist in values
					if(values.indexOf(newRestrictions[i].AccountId__c) != -1) {
							
					   // add to selected restrictions
					   newRestrictions[i].IsDeleted__c=false;
					   selRestrictions.push(newRestrictions[i].AccountId__c);
							
					}
					else { // does not exist in values
							
						// delete
						if(newRestrictions[i].Id == null)
					       newRestrictions.splice(i, 1);
                        else { 
					       newRestrictions[i].IsDeleted__c=true; 
                             removedRestrictions.push(newRestrictions[i]);
                        }
							
					}
				
				}
					
				
			}
           cmp.set("v.removedRestrictions",removedRestrictions);  
      		// data validation
		   helper.getContactsAssignedtoClientoffices(cmp, event, helper);    
          
            
        }else{
          // iterate over values
			for(var j=0; j<values.length; j++) {
              addedRestrictions.push(values[j]);    
            }
          cmp.set("v.addedRestrictions",addedRestrictions); 
          helper.getContactsAssignedToPackage(cmp, event, helper);
            
        }
		
		
	},
    
})