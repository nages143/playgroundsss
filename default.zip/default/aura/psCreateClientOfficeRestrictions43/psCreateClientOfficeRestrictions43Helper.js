({
    
    //Check if Valid
    isValid :function(cmp,event,helper) { 
      if (!$A.util.isEmpty(cmp.get("v.removedclientOffchasContacts"))){
          
          // fire toast event
					var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		    		appEvent.setParams({
		        		"duration": 5000,
                        "message": $A.get("$Label.c.PSErrorMessage79")+':'+cmp.get("v.removedclientOffchasContacts"),
		        		"details": cmp.get("v.errorDetail"),
		        		"type": "error",
		        		"mode": "dismissible"
		   			 });
		    		appEvent.fire();
          
      }
       
      else if (!$A.util.isEmpty(cmp.get("v.packagehasContacts"))){
          
          // fire toast event
					var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		    		appEvent.setParams({
		        		"duration": 5000,
                        "message": $A.get("$Label.c.PSErrorMessage79")+':'+cmp.get("v.packagehasContacts"),
		        		"details": cmp.get("v.errorDetail"),
		        		"type": "error",
		        		"mode": "dismissible"
		   			 });
		    		appEvent.fire();
          
      }
        
        else{
            
            cmp.set("v.isValid",true);
        }
        
    },
    // method to get client offices
	getContactsAssignedtoClientoffices : function(cmp,event,helper) { 
        cmp.set("v.removedclientOffchasContacts",[]);
        var removedClientOffcsIds = [];
        var asgItemOrderids = [];
         var pkgGroupRestrictions = cmp.get("v.removedRestrictions");
        for(var i=0; i<pkgGroupRestrictions.length;i++){
         removedClientOffcsIds.push(pkgGroupRestrictions[i].ClientOfficeId__c);   
         asgItemOrderids.push(pkgGroupRestrictions[i].AssignmentItemOrderId__c);   
        }
       var action = cmp.get("c.validateRemovedRestrictions"); 
	   action.setParams({ "removedClientOffcs" : removedClientOffcsIds, 
                         "assItemOrderIds" : asgItemOrderids
                        });
     action.setCallback(this, function(resp) {
         // if success
            var state = resp.getState();
            if (state === "SUCCESS") { 
		    var coList = resp.getReturnValue(); 
    	   var items = [];
    	  if (!$A.util.isEmpty(coList)){
                   // fire toast event
					var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		    		appEvent.setParams({
		        		"duration": 5000,
                        "message": $A.get("$Label.c.PSErrorMessage79")+':'+coList,
		        		"details": cmp.get("v.errorDetail"),
		        		"type": "error",
		        		"mode": "dismissible"
		   			 });
		    		appEvent.fire();
              
              cmp.set("v.removedclientOffchasContacts",coList);
                }
                
                    
			 } else if (state === "INCOMPLETE") {
                // do something
               
            } else if (state === "ERROR") {
                 
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
         
           // stop spinner
           cmp.set('v.loaded', true);
       });
       $A.enqueueAction(action);         
	},
    
   // method to get contacts assigned to package
	getContactsAssignedToPackage : function(cmp,event,helper) { 
        cmp.set("v.packagehasContacts",[]);
        // get selected assignment item order
		var newSelAsgItemOrder = cmp.get("v.selectedAssignmentItemOrder");
		
        var addedClientOffcsIds = [];
        var asgItemOrderids = [];
         
         addedClientOffcsIds= cmp.get("v.addedRestrictions");
        asgItemOrderids.push(newSelAsgItemOrder.asgItemOrderInfo.Id);   
        
       var action = cmp.get("c.validateAddedRestrictions"); 
	   action.setParams({ "addedClientOffcs" : addedClientOffcsIds, 
                         "assItemOrderIds" : asgItemOrderids
                        });
     action.setCallback(this, function(resp) {
         // if success
            var state = resp.getState();
            if (state === "SUCCESS") { 
		    var coList = resp.getReturnValue(); 
           var items = [];
    	  if (!$A.util.isEmpty(coList)){
                   // fire toast event
					var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		    		appEvent.setParams({
		        		"duration": 5000,
                        "message": $A.get("$Label.c.PSErrorMessage79")+':'+coList,
		        		"details": cmp.get("v.errorDetail"),
		        		"type": "error",
		        		"mode": "dismissible"
		   			 });
		    		appEvent.fire();
              
              cmp.set("v.packagehasContacts",coList);
                }
                
                    
			 } else if (state === "INCOMPLETE") {
                // do something
               
            } else if (state === "ERROR") {
                 
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                            errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
         
           // stop spinner
           cmp.set('v.loaded', true);
       });
       $A.enqueueAction(action);         
	},
    
    
    
    
    
    
	// method to get client offices
	getClientOffices : function(cmp) {  
	   var accountId = cmp.get("v.accountId");     
       var action = cmp.get("c.getClientOffices");
       action.setParams({ "accountId" : accountId});
       action.setCallback(this, function(a) {
           var coList = a.getReturnValue();
    	   var items = [];
    	   for(var i=0; i<coList.length; i++) {
    		   var item = {
    				   "label": coList[i].Name,
    				   "value": coList[i].Id
    		   };
    		   items.push(item);
    	   }
           cmp.set("v.options", items);
           // stop spinner
           cmp.set('v.loaded', true);
       });
       $A.enqueueAction(action);         
	},
     
   
	
	// method to load data set
    loadDataSet : function(cmp) {
		
		// get assignment group item
		var selAsgItemOrder = cmp.get("v.selectedAssignmentItemOrder");
		
		// load restrictions
		var newRestrictions = [];
		var values = [];
		if(!$A.util.isEmpty(selAsgItemOrder.pkgGroupRestrictions)) {
		   newRestrictions = JSON.parse(JSON.stringify(selAsgItemOrder.pkgGroupRestrictions));
		   for(var i=0; i<newRestrictions.length; i++) {
			   values.push(newRestrictions[i].AccountId__c);
		   }
		}	
		cmp.set("v.newRestrictions", newRestrictions);
		cmp.set("v.values", values);
		
		// hide spinner
		cmp.set('v.isLoading', false);
					
    },
	
    // method to update restrictions
	updateRestrictions : function(cmp,event,helper) {
		var removedRestrictions = cmp.get("v.removedRestrictions");
		// get values
		var values = cmp.get('v.values');
		
		// get restrictions
		var newRestrictions = cmp.get("v.newRestrictions");
		
		// init selected restrictions array
		var selRestrictions = [];
		
		// restrictions not empty
		if(!$A.util.isEmpty(newRestrictions)) {
			
			// iterate over restrictions
			for(var i=0; i<newRestrictions.length; i++) {
			
				// values not empty
				if(!$A.util.isEmpty(values)) {
						
					// restrictions exist in values
					if(values.indexOf(newRestrictions[i].AccountId__c) != -1) {
							
					   // add to selected restrictions
					   newRestrictions[i].IsDeleted__c=false;
					   selRestrictions.push(newRestrictions[i].AccountId__c);
							
					}
					else { // does not exist in values
							
						// delete
						if(newRestrictions[i].Id == null)
					       newRestrictions.splice(i, 1);
                        else { 
					       newRestrictions[i].IsDeleted__c=true; 
                             removedRestrictions.push(newRestrictions[i]);
                        }
							
					}
				
				}
				else { // does not exist in values
							
						// delete
						if(newRestrictions[i].Id == null)
					       newRestrictions.splice(i, 1);
                    else { 
					       newRestrictions[i].IsDeleted__c=true; 
                         
                       // removedRestrictions.push(newRestrictions[i]); 
                    }
							
				}	
				
			}
         
           cmp.set("v.removedRestrictions",removedRestrictions);
      		    
          
            
		}
        
        
		
		// get selected assignment item
		var newSelAsgGroupItem = cmp.get("v.selectedAssignmentGroupItem");
        	
		// get selected assignment item order
		var newSelAsgItemOrder = cmp.get("v.selectedAssignmentItemOrder");
		
		// values not empty
		if(!$A.util.isEmpty(values)) {
		
			// get options
			var options = cmp.get('v.options');
			
			// iterate over values
			for(var j=0; j<values.length; j++) {
			// new record
				if($A.util.isEmpty(selRestrictions) || selRestrictions.indexOf(values[j]) == -1) {
				
				   // get account name
			       var name='';
			       for(var k=0; k<options.length; k++) {
			           if(options[k]['value']===values[j]) {
			              name=options[k]['label'];
			              break;
			           }
			       }
			       
			       // create restriction record
				   var newRestriction = {
						   'sobjectType': 'PSPackageGroupRestriction__c',
				           'Id': null,
				           'AccountId__c':values[j],
				           'AccountName__c': name,
				           'AssignmentItemId__c': newSelAsgGroupItem.asgGroupItemInfo.Id,
			               'AssignmentItemOrderId__c': newSelAsgItemOrder.asgItemOrderInfo.Id,
				           'IsDeleted__c': false
				   };
				   
				   // add to restrictions array
				   newRestrictions.push(newRestriction);
				
				}
			
			}
		
		}
		
        // check if restrictions exist 
		var isExists=false;
		for(var l=0; l<newRestrictions.length; l++) {
			if(!newRestrictions[l].IsDeleted__c) {
				isExists=true;
				break;
			}
		}
		
		// update assignment item order data set
		newSelAsgItemOrder.pkgGroupRestrictions = newRestrictions;
        newSelAsgItemOrder.asgItemOrderInfo.RestrictAssignment__c=isExists;
        cmp.set("v.selectedAssignmentItemOrder", newSelAsgItemOrder);
        
        // update selected assignment item
		var id = newSelAsgItemOrder.orderExternalId;
		for(var m=0; m<newSelAsgGroupItem.asgItemOrders.length; m++) {
			if(newSelAsgGroupItem.asgItemOrders[m].orderExternalId===id) {
			   newSelAsgGroupItem.asgItemOrders[m]=newSelAsgItemOrder;
			   break;	
			}
		}
		cmp.set("v.selectedAssignmentGroupItem", newSelAsgGroupItem);
		
		// update selected assignment group
		id = newSelAsgGroupItem.asgGroupItemInfo.ExternalId__c;
		var newSelAsgGroup = cmp.get("v.selectedAssignmentGroup");
		for(var n=0; n<newSelAsgGroup.asgGroupItems.length; n++) {
			if(newSelAsgGroup.asgGroupItems[n].asgGroupItemInfo.ExternalId__c===id) {
			   newSelAsgGroup.asgGroupItems[n]=newSelAsgGroupItem;
			   break;	
			}
		}
		cmp.set("v.selectedAssignmentGroup", newSelAsgGroup);
		
		
        
      
		
	},	
   
})