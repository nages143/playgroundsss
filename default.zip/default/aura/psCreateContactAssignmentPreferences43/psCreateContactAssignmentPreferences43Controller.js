({
	// init handler
	doInit : function(cmp, event, helper) {
		// load data set
		helper.loadDataSet(cmp);
	},
	
	// contact assignment preference radio button change handler
	contactPreferenceChanged : function(cmp, event, helper) {
	
		// get radio button attributes
		var name = event.getSource().get("v.name");
		var value = event.getSource().get("v.value");
		
		// get assignment item order attribute
		var asgItemOrder = cmp.get("v.newAsgItemOrder");
		
		// contact assignment
		if(name === 'contactAssignment') {		
		   // group	
		   if(value === 'group')
			  // set assign as group to true  
		      asgItemOrder.AssignContactsAsGroup__c=true;
		   else
			   // set assign as group to false  
		      asgItemOrder.AssignContactsAsGroup__c=false;
		}
		// auto assign
		else if(name === 'contactAutoAssign') {
			// auto	
		   if(value === 'auto') {
			  // set auto-assign to true  
		      asgItemOrder.AutoAssignContacts__c=true;
		      
		      // set client user list to false  
		      asgItemOrder.ClientUserList__c=false;
		   } else {
			  // set auto-assign to false  
		      asgItemOrder.AutoAssignContacts__c=false;
		      
		       // set client user list to true  
		      asgItemOrder.ClientUserList__c=true;
		   }   
		}
		// client user list
		else {
			// manual	
		   if(value === 'manual')
			  // set client user list to true  
		      asgItemOrder.ClientUserList__c=true;
		   else
			  // set client user list to false  
		      asgItemOrder.ClientUserList__c=false;
		}
		
		// set assignment item order attribute
		cmp.set("v.newAsgItemOrder", asgItemOrder);
        
	},
	
	// save button click handler
	saveClicked : function(cmp, event, helper) {
		
		    // update assignment item order
			helper.updateAssignmentItemOrder(cmp);
			
			// close dialog
			cmp.set("v.showContactAssignmentPreference", false);
			cmp.set("v.isEditAssignment", true);
			
	},
	
	// cancel button click handler
	cancelClicked : function(cmp, event, helper) {
		
		// refresh data set
		helper.loadDataSet(cmp);
				
		// close dialog
		cmp.set("v.showContactAssignmentPreference", false);
		
	},
})