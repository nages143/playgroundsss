({
	// method to load data set
	loadDataSet : function(cmp) {
		
		// load data from selected assignment item order
		var selAsgItemOrder = cmp.get("v.selectedAssignmentItemOrder");
		var newAsgItemOrder = cmp.get("v.newAsgItemOrder");
		newAsgItemOrder.AssignContactsAsGroup__c = selAsgItemOrder.asgItemOrderInfo.AssignContactsAsGroup__c;
		newAsgItemOrder.AutoAssignContacts__c = selAsgItemOrder.asgItemOrderInfo.AutoAssignContacts__c;	
		newAsgItemOrder.ClientUserList__c = selAsgItemOrder.asgItemOrderInfo.ClientUserList__c;	
		cmp.set("v.newAsgItemOrder", newAsgItemOrder);
					
	},
	
	// method to update assignment item order
	updateAssignmentItemOrder : function(cmp) {
	
	    // get assignment item order data set
	    var newSelAsgGroupItem = cmp.get("v.selectedAssignmentGroupItem");
        var newSelAsgItemOrder = cmp.get("v.selectedAssignmentItemOrder");
		var newAsgItemOrder = cmp.get("v.newAsgItemOrder");
		
		// update assignment item order data set
		newSelAsgItemOrder.asgItemOrderInfo.AssignContactsAsGroup__c = newAsgItemOrder.AssignContactsAsGroup__c;
		newSelAsgItemOrder.asgItemOrderInfo.AutoAssignContacts__c = newAsgItemOrder.AutoAssignContacts__c;
		newSelAsgItemOrder.asgItemOrderInfo.ClientUserList__c = newAsgItemOrder.ClientUserList__c;
		cmp.set("v.selectedAssignmentItemOrder", newSelAsgItemOrder);
		
		// update selected assignment item
		for(var i=0; i<newSelAsgGroupItem.asgItemOrders.length; i++) {
            var id = newSelAsgItemOrder.orderExternalId;
			if(newSelAsgGroupItem.asgItemOrders[i].orderExternalId === id) {
			   newSelAsgGroupItem.asgItemOrders[i]=newSelAsgItemOrder;
			   break;	
			}
		}
		cmp.set("v.selectedAssignmentGroupItem", newSelAsgGroupItem);
		
		// update selected assignment group
		var newSelAsgGroup = cmp.get("v.selectedAssignmentGroup");
        id = newSelAsgGroupItem.asgGroupItemInfo.ExternalId__c;
		for(var j=0; j<newSelAsgGroup.asgGroupItems.length; j++) {
			if(newSelAsgGroup.asgGroupItems[j].asgGroupItemInfo.ExternalId__c===id) {
			   newSelAsgGroup.asgGroupItems[j]=newSelAsgGroupItem;
			   break;	
			}
		}
		cmp.set("v.selectedAssignmentGroup", newSelAsgGroup);
		
	},	
})