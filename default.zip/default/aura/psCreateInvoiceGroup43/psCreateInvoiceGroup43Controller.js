({
	// init handler
	doInit : function(cmp, event, helper) {				
		// populate country pick list
		helper.getCountries(cmp);
		//populate legalEntityAddress
		helper.getPrimaryLegalEntityAddress(cmp);
		// refresh data set
		helper.refreshDataSet(cmp);
	},
	
	// save button click handler
	saveClicked : function(cmp, event, helper) {
	
		// validate form
		if(helper.isAllValid(cmp)) {
		
		   // get renderMode
		   var renderMode = cmp.get("v.renderMode");
		   if(renderMode == 'Edit') {
			  // Update assignment group
			  helper.updateAssignmentGroup(cmp);
		   } else {    
			  // create the new assignment group
			  helper.createAssignmentGroup(cmp);
		   }
			
		   // close dialog
		   cmp.set("v.showCreateInvoiceGroup", false);
		   cmp.set("v.isEditAssignment", true);
		}
		else {
		
			// fire toast event
			var appEvent = $A.get("e.c:psCustomShowToastEvent43");
		    appEvent.setParams({
		        "duration": 5000,
		        "message": $A.get("$Label.c.PSErrorMessage1"),
		        "details": cmp.get("v.errorDetail"),
		        "type": "error",
		        "mode": "dismissible"
		    });
		    appEvent.fire();
			
		}
		
	},
	
	// cancel button click handler
	cancelClicked : function(cmp, event, helper) {
		
		// refresh data set
		helper.refreshDataSet(cmp);
				
		// close dialog
		cmp.set("v.showCreateInvoiceGroup", false);
		
	},
	
	// check box click handler
	checkBoxClicked : function(cmp, event, helper) {
         // get renderMode
		var renderMode = cmp.get("v.renderMode");
		var checkbox = event.getSource();
		var checkboxname = checkbox.get("v.name");
		var selectedvalue = checkbox.get("v.checked");
		var invGroup = cmp.get("v.newInvoiceGroup");
        // get assignment group
	    var selAsgGroup = cmp.get("v.selectedAssignmentGroup");
        
       
        
        
		if (checkboxname == 'IsEuropeanClient') 
			invGroup.IsEuropeanClient__c = selectedvalue; 
        else if (checkboxname == 'IsUKClient')
            invGroup.IsUKClient__c = selectedvalue;
        else if (checkboxname == 'IsNA')
        	invGroup.IsNA__c = selectedvalue;
        else if (checkboxname == 'IsVATNA') {
            invGroup.IsVATNA__c = selectedvalue;
            if(selectedvalue) {
            	invGroup.VATNumber__c='';
            	checkbox.setCustomValidity("");
            	cmp.set("v.toggleErrors", false);
            	cmp.set("v.toggleErrors", true);            	
            }
        } 
            
        
        else if (checkboxname=='usePrimaryforBilling'){
              invGroup.UsePrimarySDSIDAddressforBilling__c =  selectedvalue;
            if(selectedvalue== true && renderMode!= 'Edit') {
                 cmp.set("v.noExistingOrderError",true);   
            }
            
            else if(selectedvalue== true && renderMode== 'Edit' ){
                
                if(!$A.util.isEmpty(selAsgGroup.pkgOrders) ){
                  for(var k=0;k<selAsgGroup.pkgOrders.length;k++){ 
                       if(selAsgGroup.pkgOrders[k].pkgOrderInfo.Status__c == 'Active'){
                            for(var j=0; j<selAsgGroup.pkgOrders[k].pkgOrderLegalEntities.length;j++)   { 
                               if(selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].IsPrimary__c == true) {
                                   cmp.set("v.noExistingOrderError",false);
                                  break;
                               }
                           }
                       }
                    }
                }
                else {
                    cmp.set("v.noExistingOrderError",true);
                }
             }
            else {
              		cmp.set("v.noExistingOrderError",false); 
            }
                
            cmp.set("v.newInvoiceGroup",invGroup);
            }
    
    
        else if (checkboxname=='usePrimaryforMailing'){
              invGroup.UsePrimarySDSIDAddressforMailing__c =  selectedvalue;
            
 			if(selectedvalue== true && renderMode!= 'Edit') {
                 cmp.set("v.noExistingOrderErrorMailingAdrress",true);   
            }
            
            else if(selectedvalue== true && renderMode== 'Edit' ){
                
                if(!$A.util.isEmpty(selAsgGroup.pkgOrders) ){
                    
                   for(var k=0;k<selAsgGroup.pkgOrders.length;k++){ 
                       if(selAsgGroup.pkgOrders[k].pkgOrderInfo.Status__c == 'Active'){
                            for(var j=0; j<selAsgGroup.pkgOrders[k].pkgOrderLegalEntities.length;j++)   {   
                               if(selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].IsPrimary__c == true) {
                                   cmp.set("v.noExistingOrderErrorMailingAdrress",false);
                                  break;
                               }
                           }
                       }
                    }
                }
                else {
                    cmp.set("v.noExistingOrderErrorMailingAdrress",true);
                }
             }
            else {
              		cmp.set("v.noExistingOrderErrorMailingAdrress",false); 
            }
                
            cmp.set("v.newInvoiceGroup",invGroup);
        }
        
          else if (checkboxname=='useInvoicingaddress'){
             invGroup.UseInvoicingAddressforMailing__c =  selectedvalue;  
              
          }
	},
	
	// country pick list change handler
	selectCountryChanged : function(cmp, event, helper) {
		var selectedCountry = event.getSource().get("v.value");
		var countryList = cmp.get("v.countries");
		var invGroup = cmp.get("v.newInvoiceGroup");
		invGroup.IsEuropeanClient__c = false; 
        invGroup.IsUKClient__c = false;
        invGroup.IsNA__c = false;
		for(var i = 0; i < countryList.length; i++) {
			if(countryList[i].CountryCode__c === selectedCountry) {
				if(countryList[i].IsEUCountry__c) {
					if(selectedCountry==='GB') {
						invGroup.IsUKClient__c = true;
					}
					else {
						invGroup.IsEuropeanClient__c = true;
					}
				}
				else {
					invGroup.IsNA__c = true;
				}			    
				break;
			}
		}
		cmp.set("v.newInvoiceGroup",invGroup);
	},
	
	// invoice group name on blur handler
	invoiceGroupNameOnBlur : function(cmp, event, helper) {
		
		// validate name uniqueness
		var inputCmp = cmp.find("invoiceGroupName");
		if(!helper.isInvoiceGroupNameUnique(cmp)) {
			// display error message
		    inputCmp.setCustomValidity($A.get("$Label.c.PSErrorMessage15"));
			inputCmp.focus();
		}
		else{
            inputCmp.setCustomValidity("");
        }
        inputCmp.reportValidity();
        
	},
	
})