({
	// method to get countries
	getCountries: function(cmp) {
        var action = cmp.get("c.getCountries");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set("v.countries", response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 
    },
    
    getPrimaryLegalEntityAddress : function(cmp){
        
         // get assignment group
	    var selAsgGroup = cmp.get("v.selectedAssignmentGroup");
        
         if(!$A.util.isEmpty(selAsgGroup.pkgOrders) ){
                  for(var k=0;k<selAsgGroup.pkgOrders.length;k++){ 
                       if(selAsgGroup.pkgOrders[k].pkgOrderInfo.Status__c == 'Active'){
                            for(var j=0; j<selAsgGroup.pkgOrders[k].pkgOrderLegalEntities.length;j++)   { 
                               if(selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].IsPrimary__c == true) {
                                  cmp.set("v.legalEntityRegisteredStreet",selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].RegisteredStreet__c);
                                  cmp.set("v.legalEntityCity",selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].RegisteredCity__c);
                                  cmp.set("v.legalEntityCountry",selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].RegisteredCountry__c);
                                  cmp.set("v.legalEntityPostalCode",selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].RegisteredPostalCode__c);
                                  cmp.set("v.legalEntityState",selAsgGroup.pkgOrders[k].pkgOrderLegalEntities[j].RegisteredState__c);
                                   
                                   break;
                               }
                           }
                       }
                    }
                }
        
        
    },
    
    // method to initialize data set
	initDataSet : function(cmp) {
		
		// get account details
		var accId = cmp.get("v.accountId");
		var accName = cmp.get("v.accountName");
		var bcId = cmp.get("v.clientId");
				
		// initialize assignment group data set
		var newAsgGroup = { 
							'sobjectType': 'PSPackageGroupAssignment__c',
							'Id': null,
							'AccountId__c': accId,
							'ExternalId__c': null,
							'InvoicingGroupId__c': null,
							'AccountName__c': accName,
							'BuyingCenterId__c': bcId,
							'IsDeleted__c': false,
							'Status__c': '',
							'Comments__c': '',							
							'ChangeType__c': '',
							'SpecialNotes__c': ''
						  };
							
		var newInvoiceGroup = { 
								'sobjectType': 'PSInvoicingGroup__c',
						        'Id': null,
						        'Name': '',
						        'AccountId__c': accId,
						        'ExternalId__c': null,
						        'InvoicingAddressLine1__c': '',
						        'InvoicingAddressLine2__c': '',
						        'InvoicingCity__c': '',
						        'InvoicingCountry__c': '',
						        'InvoicingEmail__c': '',
						        'InvoicingPostalCode__c': '',
						        'InvoicingState__c': '',
            					'MailingAddressLine1__c': '',
            					'MailingAddressLine2__c': '',
           						'MailingCity__c': '',
            					'MailingCountry__c': '',
            					'MailingEmail__c': '',
            					'MailingPostalCode__c': '',
            					'MailingState__c':'',
						        'IsDeleted__c': false,
						        'IsEuropeanClient__c': false,
						        'IsNA__c': false,
						        'IsUKClient__c': false,
						        'VATNumber__c': '',
						        'IsVATNA__c': false ,
            					'UseInvoicingAddressforMailing__c':true,
            					'UsePrimarySDSIDAddressforBilling__c':false,
            					'UsePrimarySDSIDAddressforMailing__c':false
            
						       };				
		cmp.set("v.newAsgGroup", newAsgGroup);
		cmp.set("v.newInvoiceGroup", newInvoiceGroup);
		
		// initialize invoice group contacts
		cmp.set("v.newInvGroupContacts", []);
		
	},
	
	// method to load data set
	loadDataSet : function(cmp) {
		
		// assignment group and invoicing group info
		var selAsg = cmp.get("v.selectedAssignmentGroup");
		var selInvg = selAsg.invGroup;
		var asgGroup = JSON.parse(JSON.stringify(selAsg.asgGroupInfo));	
		var invGroup = JSON.parse(JSON.stringify(selInvg.invGroupInfo));
		cmp.set("v.newAsgGroup", asgGroup);
		cmp.set("v.newInvoiceGroup", invGroup);
				
		// invoice group contacts		
		var invGroupContacts = [];
		if(!$A.util.isEmpty(selInvg.invGroupContacts))
		{   
		   invGroupContacts = JSON.parse(JSON.stringify(selInvg.invGroupContacts));	
		}
		cmp.set("v.newInvGroupContacts", invGroupContacts);
				
	},
	
	// refresh data set
	refreshDataSet : function(cmp) {
		// if edit load data set	
		var renderMode = cmp.get("v.renderMode");
		if(renderMode == 'Edit') 
		   this.loadDataSet(cmp);
		else
		   this.initDataSet(cmp);
	},
	
	// method to create assignment group
	createAssignmentGroup : function(cmp) {
	
	    // create assignment group data set
		var accId = cmp.get("v.accountId");
		var accName = cmp.get("v.accountName");
		var bcId = cmp.get("v.clientId");
		var newIGList = cmp.get("v.invoiceGroupList");
		var newInvoiceGroup = cmp.get("v.newInvoiceGroup");
		newInvoiceGroup.AccountId__c = accId;
		var newInvGroupContacts = cmp.get("v.newInvGroupContacts");
		var igName = newInvoiceGroup.Name;
		var id = newIGList.length.toString();			
		var newAsgGroup = { 
							'sobjectType': 'PSPackageGroupAssignment__c',
							'Id': null,
							'AccountId__c': accId,
							'ExternalId__c': id,
							'InvoicingGroupId__c': null,
							'AccountName__c': accName,
							'BuyingCenterId__c': bcId,
							'IsDeleted__c': false,
							'Status__c': '',
							'Comments__c': '',
							'ChangeType__c': '',
							'SpecialNotes__c': '' 
						  };
		
	    // create assignment group data set 
		var newSelAsgGroup = {
								'sobjectType': 'PSPackageAssignmentDataSetWrapper',
								'accountInfo': {
									 				'Id': accId,
									 				'Name': accName,
									 				'BCAP_External_ID__c': bcId
								 				},
                                'invGroup' : {
												'invGroupInfo': newInvoiceGroup,
												'invGroupContacts': newInvGroupContacts
								             },
            					'pkgOrders' : [], 
								'asgGroupInfo': newAsgGroup,
								'asgGroupItems': [],
								'currentStatus': ''
								            
						  	 };
		cmp.set("v.selectedAssignmentGroup", newSelAsgGroup);
        
        // init selected order, assignment item order and assignment item attributes
        cmp.set('v.selectedOrder', null);
        cmp.set('v.selectedAssignmentItemOrder', null);
        cmp.set('v.selectedAssignmentGroupItem', null);
        cmp.set('v.selectedOrderId', null);
        cmp.set('v.selectedAssignmentItemId', null);
        
        // init order and package group lists
        var newOrderList = [];
        newOrderList.push({
            'Id': null,
            'Name': $A.get("$Label.c.PSDefaultOrderName")
        });
        cmp.set("v.orderList", newOrderList);
		cmp.set("v.packageGroupList", []);	
		cmp.set("v.invoicePeriodList",[]);		
		// Add to invoice group list
		newIGList.push({'Id': id, 'Name': igName});	
		cmp.set("v.invoiceGroupList", newIGList);
	},
	
	// method to update assignment group
	updateAssignmentGroup : function(cmp) {
	
	    // get assignment group data set
	    var newSelAsgGroup = cmp.get("v.selectedAssignmentGroup");
		var newInvoiceGroup = cmp.get("v.newInvoiceGroup");
		var newInvGroupContacts = cmp.get("v.newInvGroupContacts");
		
		// update assignment group data set
		newSelAsgGroup.invGroup.invGroupInfo = newInvoiceGroup;
		newSelAsgGroup.invGroup.invGroupContacts = newInvGroupContacts;
		cmp.set("v.selectedAssignmentGroup", newSelAsgGroup);
	},
	
	// validate invoice group name uniqueness
	isInvoiceGroupNameUnique : function(cmp) {
		
		// get invoice group name details
		var newInvoiceGroup = cmp.get("v.newInvoiceGroup");
		var invGroupName = newInvoiceGroup.Name;
		var invGroupId = newInvoiceGroup.Id;
		
		// get package assignment data set
		var isUnique=true;
		var pkgAsgDataSet = cmp.get("v.packageAssignmentDataSetList");
		if(!$A.util.isEmpty(pkgAsgDataSet)) {
		
			// iterate over the data set
			for(var i=0; i<pkgAsgDataSet.length; i++) {
				
				// null check
				if(!$A.util.isEmpty(pkgAsgDataSet[i].invGroup) && !$A.util.isEmpty(pkgAsgDataSet[i].invGroup.invGroupInfo)) {
				
					// validate invoice group name
					var invId = pkgAsgDataSet[i].invGroup.invGroupInfo.Id;
					var invName = pkgAsgDataSet[i].invGroup.invGroupInfo.Name;
					var isDeleted = pkgAsgDataSet[i].invGroup.invGroupInfo.IsDeleted__c;
					if(!isDeleted && invId != invGroupId && invName === invGroupName) {
						isUnique=false;
						cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage15"));
						break;
					}
				
				}
			}
	    
	    }
	    return isUnique;
	     
    },		
    
    // validate all fields
	isAllValid : function(cmp) {
		
		// get invoice group info.
		var invGroupInfo = cmp.get("v.newInvoiceGroup");
		var isAllValid=true;
		cmp.set("v.errorDetail",'');
		
		// validate name
		if($A.util.isEmpty(invGroupInfo.Name)) {
			isAllValid=false;
			cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage8"));
		}	
		if(isAllValid) {
		  isAllValid = this.isInvoiceGroupNameUnique(cmp);	
		}
		
		// validate other fields
		if(isAllValid) {
		
			// get status
			var status = cmp.get("v.newAsgGroup").Status__c;
			
			// status not draft or new
			if(!$A.util.isEmpty(status) && status != 'Draft') {
			
				// check for do not invoice
				if(!this.isDoNotInvoice(cmp)) {
			
                    if(!invGroupInfo.UsePrimarySDSIDAddressforBilling__c){
					// validate address line 1
					if(isAllValid) {
						if($A.util.isEmpty(invGroupInfo.InvoicingAddressLine1__c)) { 
						   isAllValid=false;
						   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage9"));
						}	
					}
					
					// validate city
					if(isAllValid) {
					   if($A.util.isEmpty(invGroupInfo.InvoicingCity__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage10"));
					   }  
					}
						
					// validate postal code
					if(isAllValid) {
					   if($A.util.isEmpty(invGroupInfo.InvoicingPostalCode__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage11"));
					   }	  
					}
						
					// validate country
					if(isAllValid) {
						if($A.util.isEmpty(invGroupInfo.InvoicingCountry__c)) {
							isAllValid=false;
							cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage12"));
						}	
					}
					}	
					// validate VAT #
					if(isAllValid) {
					   if(!invGroupInfo.IsVATNA__c && $A.util.isEmpty(invGroupInfo.VATNumber__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage13"));
					   }  
					}
						
					// validate email
					if(isAllValid) {
					   if($A.util.isEmpty(invGroupInfo.InvoicingEmail__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage14"));
					   }	  
					}
                    
                    //Validate Mailing Address
                       if(!invGroupInfo.UsePrimarySDSIDAddressforMailing__c && !invGroupInfo.UseInvoicingAddressforMailing__c){ 
                    if(isAllValid) {
						if($A.util.isEmpty(invGroupInfo.MailingAddressLine1__c)) { 
						   isAllValid=false;
						   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage80"));
						}	
					}
					
					// validate Mailing city
					if(isAllValid) {
					   if($A.util.isEmpty(invGroupInfo.MailingCity__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage81"));
					   }  
					}
						
					// validate Mailing postal code
					if(isAllValid) {
					   if($A.util.isEmpty(invGroupInfo.MailingPostalCode__c)) {
						  isAllValid=false;
						  cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage82"));
					   }	  
					}
						
					// validate Mailing country
					if(isAllValid) {
						if($A.util.isEmpty(invGroupInfo.MailingCountry__c)) {
							isAllValid=false;
							cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage83"));
						}	
					}
                       }
                    
					
					// validate invoice group contacts
					if(isAllValid)
					   isAllValid=this.allInvoiceGroupContactsValid(cmp);
					}
				
				}
			
		
		} 
		
        return isAllValid;
	},
	
	// validate invoice group contacts
	allInvoiceGroupContactsValid : function(cmp) {
        
        // get contacts
        var invGroupContacts = cmp.get("v.newInvGroupContacts");
        
        // init flags
        var isAllValid=false;
		var isBarValid=false;
        var isBusValid=false;
        var isOpsValid=false;
        var isCliValid=false;
        
        // contacts exist
		if(!$A.util.isEmpty(invGroupContacts)) {
            
            // loop through contacts
			for(var i=0; i<invGroupContacts.length; i++) {

                // not deleted check
                if(!invGroupContacts[i].IsDeleted__c) {
			    	
                    // Barclays contact
                    if(invGroupContacts[i].Type__c==='Barclays') {
                       isBarValid=true;    
                    }
                    // Business contact
                    else if(invGroupContacts[i].Type__c==='Business') {
                       isBusValid=true;    
                    }
                    // Operations contact
                    else if(invGroupContacts[i].Type__c==='Operations') {
                       isOpsValid=true;    
                    }
                    // Client contact
                    else if(invGroupContacts[i].Type__c==='Client') {
                       isCliValid=true;    
                    }
			    	
			    }
			    
			}
		}
	
	    // validate employee
	    var isAllValid = isBarValid;
		if(!isAllValid) {
		   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage33"));
		}
		
		// validate business contacts
		if(isAllValid)
			isAllValid = isBusValid;
		if(!isAllValid) {
		   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage34"));
		}
		
		// validate invoicing contacts
		if(isAllValid)
			isAllValid = isOpsValid;
		if(!isAllValid) {
		   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage35"));
		}		
		
		// validate client contacts
		if(isAllValid)
			isAllValid = isCliValid;
		if(!isAllValid) {
		   cmp.set("v.errorDetail", $A.get("$Label.c.PSErrorMessage71"));
		}
		
		return isAllValid;	
	
	},
	
    // check for do not invoice flag
	isDoNotInvoice : function(cmp) {
		
		// get selected assignment group
		var selAsgGroup = cmp.get("v.selectedAssignmentGroup");
		
		// check if invoice order exists
		var isDoNotInvoice=true;
		if(!$A.util.isEmpty(selAsgGroup.pkgOrders)) {
			for(var i=0; i<selAsgGroup.pkgOrders.length; i++) {
				if(!$A.util.isEmpty(selAsgGroup.pkgOrders[i].pkgOrderInfo)) {
					
					if(!selAsgGroup.pkgOrders[i].pkgOrderInfo.IsDeleted__c && !selAsgGroup.pkgOrders[i].pkgOrderInfo.DoNotInvoice__c) {
							isDoNotInvoice = false;
							break;
					}
					
				}
			}
			
		}
					
	    return isDoNotInvoice;
	     
    },
 
})